import { useHotelApi } from './banner-state/api-banner/useHotelApi.js';
import { useTourApi } from './banner-state/api-banner/useTourApi.js';
import { getRatingLabel, formatRating } from './banner-state/api-banner/utils.js';

export function useApiBanner(banner, showModal, ajax) {
    const hotelApi = useHotelApi(banner, showModal, ajax);
    const tourApi = useTourApi(banner, showModal, ajax);

    return {
        ...hotelApi,
        ...tourApi,
        getRatingLabel,
        formatRating,
        ceil: Math.ceil,
    };
}