const { reactive, computed } = Vue;
import {
    createDefaultPart,
    createDefaultMobilePart,
    createDefaultDoubleBannerPart,
    createDefaultDoubleBannerMobilePart,
    createDefaultApiDesign,
    createDefaultApiMobileDesign,
    createDefaultSimplePart,
    createDefaultSimpleBannerMobilePart,
    createDefaultStickySimplePart,
    createDefaultStickySimpleMobilePart,
    createDefaultPromotionPart,
    createDefaultPromotionMobilePart,
    createDefaultHtmlPart,
    createDefaultHtmlSidebarPart,
    createDefaultTourCarouselPart,
    createDefaultHotelCarouselPart,
    createDefaultFlightTicketPart,
    createDefaultFlightTicketMobilePart,
    createDefaultWelcomePackagePart,
} from './defaults/index.js';

export function useBannerState() {
    const createDefaultBanner = () => ({
        id: null, name: '', displayMethod: 'Fixed', isActive: true, type: null,
        isMobileConfigured: false,
        displayOn: { posts: [], pages: [], categories: [] },

        single: createDefaultPart(),
        single_mobile: createDefaultMobilePart(),
        double: {
            isMobileConfigured: false,
            desktop: { left: createDefaultDoubleBannerPart(), right: createDefaultDoubleBannerPart() },
            mobile: { left: createDefaultDoubleBannerMobilePart(), right: createDefaultDoubleBannerMobilePart() }
        },
        simple: createDefaultSimplePart(),
        simple_mobile: createDefaultSimpleBannerMobilePart(),
        sticky_simple: createDefaultStickySimplePart(),
        sticky_simple_mobile: createDefaultStickySimpleMobilePart(),
        promotion: createDefaultPromotionPart(),
        promotion_mobile: createDefaultPromotionMobilePart(),
        content_html: createDefaultHtmlPart(),
        content_html_sidebar: createDefaultHtmlSidebarPart(),
        api: {
            apiType: null,
            selectedHotel: null,
            selectedTour: null,
            design: createDefaultApiDesign(),
            design_mobile: createDefaultApiMobileDesign(),
            isMobileConfigured: false,
        },
        tour_carousel: createDefaultTourCarouselPart(),
        hotel_carousel: createDefaultHotelCarouselPart(),
        
        flight_ticket: {
            ...createDefaultFlightTicketPart(),
            isMobileConfigured: false,
            design_mobile: createDefaultFlightTicketMobilePart().design,
        },

        welcome_package: createDefaultWelcomePackagePart(),
    });

    const banner = reactive(createDefaultBanner());

    const shortcode = computed(() => {
        if (!banner.type) return '';
        const base = banner.type.replace(/-/g, '')
                                .replace('contenthtmlbanner', 'contenthtml')
                                .replace('contenthtmlsidebarbanner', 'contenthtmlsidebar')
                                .replace('tourcarousel', 'tourcarousel')
                                .replace('hotelcarousel', 'hotelcarousel')
                                .replace('welcomepackagebanner', 'welcomepackage')
                                .replace('flightticket', 'flightticket');

        if (banner.displayMethod === 'Embeddable') {
            return banner.id ? `[${base} id="${banner.id}"]` : `[${base} id="..."]`;
        }
        return `[${base}_fixed]`;
    });

    const mergeWithExisting = (existingData) => {
        const deepMerge = (target, source) => {
            for (const key in source) {
                if (source.hasOwnProperty(key)) {
                    if (key in target && target[key] !== null && typeof target[key] === 'object' && !Array.isArray(target[key]) &&
                        source[key] !== null && typeof source[key] === 'object' && !Array.isArray(source[key])) {
                        deepMerge(target[key], source[key]);
                    } else if (Array.isArray(source[key]) && key in target && Array.isArray(target[key])) {
                        if (['posts', 'pages', 'categories', 'selectedTours', 'selectedHotels'].includes(key)) {
                            target[key] = [...source[key]];
                        } else if (key === 'gradientStops') {
                            target[key] = source[key].map(stop => ({...stop}));
                        }
                        else {
                            target[key] = [...source[key]];
                        }
                    } else {
                        target[key] = source[key];
                    }
                }
            }
        };

        if (existingData.id) {
            if (existingData.single) existingData.isMobileConfigured = true;
            if (existingData.double) existingData.double.isMobileConfigured = true;
            if (existingData.api) existingData.api.isMobileConfigured = true;
            if (existingData.tour_carousel) existingData.tour_carousel.isMobileConfigured = true;
            if (existingData.hotel_carousel) existingData.hotel_carousel.isMobileConfigured = true;
            if (existingData.simple) existingData.isMobileConfigured = true;
            if (existingData.sticky_simple) existingData.isMobileConfigured = true;
            if (existingData.promotion) existingData.isMobileConfigured = true;
            if (existingData.flight_ticket) existingData.flight_ticket.isMobileConfigured = true;
        }

        deepMerge(banner, existingData);

        if (!banner.displayOn) {
            banner.displayOn = { posts: [], pages: [], categories: [] };
        } else {
            if (!Array.isArray(banner.displayOn.posts)) banner.displayOn.posts = [];
            if (!Array.isArray(banner.displayOn.pages)) banner.displayOn.pages = [];
            if (!Array.isArray(banner.displayOn.categories)) banner.displayOn.categories = [];
        }

        if (banner.type === 'promotion-banner') {
            if (!banner.promotion) banner.promotion = createDefaultPromotionPart();
            if (!Array.isArray(banner.promotion.links)) banner.promotion.links = [];
        }
        if (banner.type === 'hotel-carousel') {
            if (!banner.hotel_carousel) banner.hotel_carousel = createDefaultHotelCarouselPart();
            if (!Array.isArray(banner.hotel_carousel.selectedHotels)) banner.hotel_carousel.selectedHotels = [];
        }
        if (banner.type === 'tour-carousel') {
            if (!banner.tour_carousel) banner.tour_carousel = createDefaultTourCarouselPart();
            if (!Array.isArray(banner.tour_carousel.selectedTours)) banner.tour_carousel.selectedTours = [];
        }
        if (banner.type === 'welcome-package-banner') {
            if (!banner.welcome_package) banner.welcome_package = createDefaultWelcomePackagePart();
            if (typeof banner.welcome_package.selectedKey === 'undefined') banner.welcome_package.selectedKey = null;
            if (typeof banner.welcome_package.selectedPrice === 'undefined') banner.welcome_package.selectedPrice = null;
            if (typeof banner.welcome_package.selectedOriginalPrice === 'undefined') banner.welcome_package.selectedOriginalPrice = null;
            if (typeof banner.welcome_package.html === 'undefined') banner.welcome_package.html = '';
        }
        if (banner.type === 'flight-ticket') {
            if (!banner.flight_ticket) banner.flight_ticket = createDefaultBanner().flight_ticket;
            if (!banner.flight_ticket.design_mobile) banner.flight_ticket.design_mobile = createDefaultFlightTicketMobilePart().design;
        }
    };

    const resetBannerState = () => {
        Object.assign(banner, createDefaultBanner());
    };

    return { banner, shortcode, mergeWithExisting, resetBannerState };
}
