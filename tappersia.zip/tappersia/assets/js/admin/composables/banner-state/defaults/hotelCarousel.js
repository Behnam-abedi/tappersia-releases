// tappersia/assets/js/admin/composables/banner-state/defaults/hotelCarousel.js

// Keep settings identical to Tour Carousel for now, but add card styling specifics
export const createDefaultHotelCarouselDesktopPart = () => ({
    slidesPerView: 3,
    cardWidth:295,
    loop: false,
    spaceBetween: 20,
    isDoubled: false,
    gridFill: 'column',
    direction: 'ltr',
    header: {
        text: 'Top Rated Hotel in Isfahan',
        fontSize: 24,
        fontWeight: '700',
        color: '#ffffff',
        lineColor: '#00BAA4',
        marginTop: 28,
    },
    // --- START: Added Detailed Card Styling ---
    card: {
        minHeight:357,
        bgColor: '#ffffff',
        borderWidth: 1,
        borderColor: '#E5E5E5',
        borderRadius: 16,
        padding: 9,

        imageContainer: {
            paddingX: 13,
            paddingY: 13,
        },
        image: {
            height: 176,
            radius: 14,
        },
        imageOverlay: {
            gradientStartColor: '#00000000',
            gradientEndColor: '#000000D4',
            gradientStartPercent: 38,
            gradientEndPercent: 0,
        },
        badges: {
            bestSeller: {
                textColor: '#ffffff',
                fontSize: 12,
                bgColor: '#F66A05',
                paddingX: 7,
                paddingY: 5,
                radius: 20,
            },
            discount: {
                textColor: '#ffffff',
                fontSize: 12,
                bgColor: '#FB2D51',
                paddingX: 10,
                paddingY: 5,
                radius: 20,
            },
        },
        stars: {
            shapeSize: 17,
            shapeColor: '#FCC13B',
            textSize: 12,
            textColor: '#ffffff',
        },
        bodyContent: {
            marginTop: 14,
            marginX: 19,
            textColor: '#333333',
        },
        title: {
            fontSize: 14,
            fontWeight: '600',
            color: '#333333',
            lineHeight: 1.2,
            minHeight: 31,
            // +++ ADDED +++
            marginTop: 0,
        },
        rating: {
            marginTop: 0,
            // +++ ADDED +++
            marginBottom: 0,
            gap: 6,
            boxBgColor: '#5191FA',
            boxColor: '#ffffff',
            boxFontSize: 11,
            boxPaddingX: 6,
            boxPaddingY: 2,
            boxRadius: 3,
            labelColor: '#333333',
            labelFontSize: 12,
            countColor: '#999999',
            countFontSize: 10,
        },
        tags: {
            marginTop: 7,
            gap: 5,
            fontSize: 11,
            paddingX: 6,
            paddingY: 2,
            radius: 3,
        },
        divider: {
            marginTop: 9.5,
            marginBottom: 7.5,
            color: '#EEEEEE',
        },
        price: {
            // +++ ADDED +++
            marginBottom: 0,
            fromColor: '#999999',
            fromSize: 12,
            amountColor: '#00BAA4',
            amountSize: 16,
            amountWeight: '700',
            nightColor: '#555555',
            nightSize: 13,
            originalColor: '#999999',
            originalSize: 12,
        },
    },
    // --- END: Added Detailed Card Styling ---
    autoplay: { enabled: false, delay: 3000 },
    navigation: { enabled: true },
    pagination: {
        enabled: true,
        paginationColor: '#00BAA44F',
        paginationActiveColor: '#00BAA4',
    },
});

export const createDefaultHotelCarouselMobilePart = () => {
    const mobileDefaults = createDefaultHotelCarouselDesktopPart();
    mobileDefaults.slidesPerView = 1;
    mobileDefaults.spaceBetween = 15;
    mobileDefaults.cardWidth = 295;

    return mobileDefaults;
};

export const createDefaultHotelCarouselPart = () => ({
    selectedHotels: [],
    updateCounter: 0,
    isMobileConfigured: false,
    settings: createDefaultHotelCarouselDesktopPart(),
    settings_mobile: createDefaultHotelCarouselMobilePart(),
});