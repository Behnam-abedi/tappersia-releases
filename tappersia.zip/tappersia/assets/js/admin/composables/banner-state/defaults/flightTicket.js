// tappersia/assets/js/admin/composables/banner-state/defaults/flightTicket.js

export const createDefaultFlightTicketPart = () => ({
    from: null,
    to: null,
    cheapestPrice: null,
    cheapestFlightDetails: null,
    isLoadingFlights: false,
    lastSearchError: null,
    
    design: {
        ticketLayout: 'left',
        minHeight: 150,
        borderRadius: 16,
        padding: 12,
        
        layerOrder: 'overlay-below-image',
        backgroundType: 'solid',
        bgColor: '#CEE8F6',
        gradientAngle: 90,
        gradientStops: [
            { color: '#CEE8F6', stop: 0 },
            { color: '#CEE8F6', stop: 100 }
        ],
        
        imageUrl: '',
        enableCustomImageSize: false,
        imageWidth: null,
        imageWidthUnit: 'px',
        imageHeight: null,
        imageHeightUnit: 'px',
        imagePosLeft: 0,
        imagePosBottom: 0,
        
        contentWidth: 100,
        contentWidthUnit: '%',

        content1: {
            text: 'Offering',
            color: '#555555',
            fontSize: 12,
            fontWeight: '400',
            marginTop: 0, 
            // marginBottom removed
        },
        content2: {
            text: 'BEST DEALS',
            color: '#111111',
            fontSize: 18,
            fontWeight: '700',
            marginTop: 0, 
            marginBottom: 0 
        },
        content3: {
            text: 'on Iran Domestic Flight Booking',
            color: '#333333',
            fontSize: 14,
            fontWeight: '400',
            // marginTop removed
            marginBottom: 0 
        },

        price: {
            color: '#00BAA4',
            fontSize: 17,
            fontWeight: '700',
            fromFontSize: 10, 
        },

        button: {
            bgColor: '#1EC2AF',
            BgHoverColor: '#169a8d',
            color: '#FFFFFF',
            fontSize: 13,
            fontWeight: '600',
            paddingX: 33, 
            paddingY: 10, 
            borderRadius: 8, 
        },

        fromCity: {
            color: '#000000',
            fontSize: 16,
            fontWeight: '700',
        },
        
        toCity: {
            color: '#000000',
            fontSize: 16,
            fontWeight: '700',
        }
    }
});

export const createDefaultFlightTicketMobilePart = () => {
    const mobileDefaults = createDefaultFlightTicketPart();

    mobileDefaults.design.ticketLayout = 'left'; 
    mobileDefaults.design.minHeight = 70;
    mobileDefaults.design.borderRadius = 8;
    mobileDefaults.design.padding = 5;

    mobileDefaults.design.fromCity.fontSize = 8;
    mobileDefaults.design.toCity.fontSize = 8;

    mobileDefaults.design.button.fontSize = 8;
    mobileDefaults.design.button.paddingX = 13;
    mobileDefaults.design.button.paddingY = 4;
    mobileDefaults.design.button.borderRadius = 4;

    mobileDefaults.design.price.fontSize = 8;
    mobileDefaults.design.price.fromFontSize = 5;
    
    mobileDefaults.design.contentWidth = 100;
    mobileDefaults.design.contentWidthUnit = '%';
    
    return mobileDefaults;
};