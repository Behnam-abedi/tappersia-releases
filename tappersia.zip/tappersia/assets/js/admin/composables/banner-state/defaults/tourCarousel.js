export const createDefaultTourCarouselDesktopPart = () => ({
    slidesPerView: 3,
    responsiveSlides: false, // <--- اضافه شده
    cardWidth: 295,
    loop: false,
    spaceBetween: 22,
    autoGap: false,
    rowGap: 20,
    isDoubled: false,
    gridFill: 'column',
    direction: 'ltr',
    header: {
        text: 'Top Iran Tours',
        fontSize: 24,
        fontWeight: '700',
        color: '#ffffff',
        lineColor: '#00BAA4',
        marginTop: 28,
    },
    card: {
        height: 375,
        backgroundType: 'solid',
        bgColor: '#ffffff',
        gradientAngle: 90,
        gradientStops: [{ color: '#FFFFFF', stop: 0 }, { color: '#F9F9F9', stop: 100 }],
        borderWidth: 1,
        borderColor: '#E5E5E5',
        borderRadius: 14,
        padding: 9,
        imageHeight: 204,
        province: {
            fontSize: 14,
            fontWeight: '500',
            color: '#FFFFFF',
            bgColor: 'rgba(14,14,14,0.2)',
            blur: 3,
            bottom: 9,
            side: 11
        },
        title: { 
            fontSize: 14, 
            fontWeight: '600', 
            color: '#000000ff', 
            lineHeight: 1.5,
            marginTop: 0 
        },
        infoRow: {
            marginTop: null,
            marginBottom: 10
        },
        price: { fontSize: 14, fontWeight: '500', color: '#00BAA4' },
        duration: { fontSize: 12, fontWeight: '400', color: '#757575' },
        rating: { fontSize: 13, fontWeight: '700', color: '#333333' },
        reviews: { fontSize: 12, fontWeight: '400', color: '#757575' },
        button: {
            bgColor: '#00BAA4',
            BgHoverColor: '#008a7b',
            fontSize: 13,
            fontWeight: '600',
            color: '#FFFFFF',
            arrowSize: 10,
            marginBottom: 0,
            width: 100,
            widthUnit: '%'
        }
    },
    autoplay: { enabled: false, delay: 3000 },
    navigation: { enabled: true },
    pagination: { 
        enabled: true,
        paginationColor: '#00BAA44F',
        paginationActiveColor: '#00BAA4',
    },
});

export const createDefaultTourCarouselMobilePart = () => {
    const mobileDefaults = createDefaultTourCarouselDesktopPart();
    mobileDefaults.slidesPerView = 1;
    mobileDefaults.responsiveSlides = false; // <--- اضافه شده
    mobileDefaults.cardWidth = 295;
    mobileDefaults.autoGap = false;
    mobileDefaults.rowGap = 20; 
    mobileDefaults.card.height = 375;
    mobileDefaults.card.padding = 9;
    mobileDefaults.card.borderRadius = 14;
    mobileDefaults.card.borderWidth = 1;
    mobileDefaults.card.imageHeight = 204;
    return mobileDefaults;
};


export const createDefaultTourCarouselPart = () => ({
    selectedTours: [],
    updateCounter: 0,
    isMobileConfigured: false,
    settings: createDefaultTourCarouselDesktopPart(),
    settings_mobile: createDefaultTourCarouselMobilePart(),
});