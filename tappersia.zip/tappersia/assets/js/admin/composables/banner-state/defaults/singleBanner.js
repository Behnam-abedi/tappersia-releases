// tappersia/assets/js/admin/composables/banner-state/defaults/singleBanner.js
export const createDefaultPart = () => ({
    layerOrder: 'image-below-overlay',
    alignment: 'left',
    backgroundType: 'solid',
    bgColor: '#0facf0',
    gradientAngle: 90,
    gradientStops: [
        { color: '#0CA5EACC', stop: 0 },
        { color: '#124C88CC', stop: 100 }
    ],
    titleText: 'Awesome Title',
    titleColor: '#ffffff',
    titleSize: 24,
    titleWeight: '700',
    
    // +++ START: Title Margin +++
    titleMarginTop: 0, // فیلد جدید
    // +++ END: Title Margin +++

    descText: 'A short and engaging description.',
    descColor: '#ffffff',
    descSize: 14,
    descWeight: '500',
    
    // +++ START: Description Margins (Replaces marginTopDescription) +++
    descMarginTop: 12,    // جایگزین marginTopDescription
    descMarginBottom: 0,  // فیلد جدید
    // +++ END: Description Margins +++

    buttonText: 'Learn More',
    buttonLink: '#',
    buttonBgColor: '#124C88',
    buttonTextColor: '#ffffff',
    buttonFontSize: 14,
    buttonBgHoverColor: '#10447B',
    buttonFontWeight: '500',
    imageUrl: '',
    enableCustomImageSize: false,
    imageWidth: null,
    imageWidthUnit: 'px',
    imageHeight: null,
    imageHeightUnit: 'px',
    imagePosRight: 0,
    imagePosBottom: 0,
    
    minHeight: 190,
    contentWidth: 100,
    contentWidthUnit: '%',
    
    enableBorder: false,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 16,
    
    paddingY: 34,
    paddingX: 34,
    
    buttonBorderRadius: 8,
    // marginTopDescription: 12, // <<< حذف شد (با descMarginTop جایگزین شد)
    
    buttonMarginTopAuto: true,
    buttonMarginTop: 15,
    buttonMarginBottom: 0,
    
    buttonPaddingY: 12,
    buttonPaddingX: 24,
});

export const createDefaultMobilePart = () => {
    const mobileDefaults = createDefaultPart();
    
    // Mobile specific overrides
    mobileDefaults.layerOrder = 'image-below-overlay';
    mobileDefaults.minHeight = 145;
    
    mobileDefaults.paddingY = 20;
    mobileDefaults.paddingX = 22;
    
    mobileDefaults.titleSize = 14;
    // +++ Mobile Title Margin +++
    mobileDefaults.titleMarginTop = 0; 

    mobileDefaults.descSize = 12;
    // +++ Mobile Description Margins +++
    mobileDefaults.descMarginTop = 12;
    mobileDefaults.descMarginBottom = 0;

    mobileDefaults.buttonFontSize = 11;
    
    mobileDefaults.buttonPaddingY = 10;
    mobileDefaults.buttonPaddingX = 16;
    
    mobileDefaults.buttonMarginTopAuto = true;
    mobileDefaults.buttonMarginTop = 15;
    mobileDefaults.buttonMarginBottom = 0;

    return mobileDefaults;
};