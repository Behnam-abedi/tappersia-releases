export const createDefaultApiDesign = () => ({
    imageContainerWidth: 360,
    imageContainerWidthUnit: 'px',
    width: 100,
    widthUnit: '%',
    minHeight: 150,
    layout: 'left',
    backgroundType: 'solid',
    bgColor: '#ffffff',
    gradientAngle: 90,
    gradientStops: [
        { color: '#F0F2F5FF', stop: 0 },
        { color: '#FFFFFFFF', stop: 100 }
    ],
    enableBorder: false,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 16,
    paddingY: 24,
    paddingX: 35,
    titleColor: '#000000', 
    titleSize: 20, 
    titleWeight: '700',
    
    titleMarginTop: 0,
    
    starSize: 16,
    cityColor: '#000000',
    citySize: 12,
    
    subHeaderMarginTop: 9, 
    subHeaderMarginBottom: 0, 

    ratingBoxBgColor: '#5191FA',
    ratingBoxColor: '#FFFFFF',
    ratingBoxSize: 14,
    ratingBoxWeight: '500',
    ratingTextColor: '#5191FA',
    ratingTextSize: 14,
    ratingTextWeight: '700',
    reviewColor: '#999999',
    reviewSize: 11,
    
    priceFromColor: '#999999',
    priceFromSize: 12,
    priceAmountColor: '#00BAA4',
    priceAmountSize: 16,
    priceAmountWeight: '700',
    priceNightColor: '#999999',
    priceNightSize: 10,

    bottomSectionMarginBottom: 0,

});

export const createDefaultApiMobileDesign = () => {
    const mobileDefaults = createDefaultApiDesign();
    
    mobileDefaults.minHeight = 80;
    mobileDefaults.imageContainerWidth = 140;
    mobileDefaults.imageContainerWidthUnit = 'px';

    mobileDefaults.paddingY = 12;
    mobileDefaults.paddingX = 20;

    mobileDefaults.titleSize = 16;
    mobileDefaults.starSize = 11;
    mobileDefaults.citySize = 11;
    

    mobileDefaults.subHeaderMarginTop = 4; 

    mobileDefaults.ratingBoxSize = 10;
    mobileDefaults.ratingTextSize = 10;
    mobileDefaults.reviewSize = 8;
    mobileDefaults.priceAmountSize = 12;
    mobileDefaults.priceFromSize = 9;

    return mobileDefaults;
};