// tappersia/assets/js/admin/composables/useFlightTicket.js
const { ref, reactive, computed, watch } = Vue;

export function useFlightTicket(banner, showModal, ajax) {
    const isFlightModalOpen = ref(false);
    const isAirportsLoading = ref(false);
    const airports = ref([]);
    const airportSearchQuery = ref('');
    const tempSelectedAirports = reactive({
        from: null,
        to: null,
    });

    const filteredAirports = computed(() => {
        if (!airportSearchQuery.value) {
            return airports.value;
        }
        const query = airportSearchQuery.value.toLowerCase();
        return airports.value.filter(airport => 
            airport.name.toLowerCase().includes(query) ||
            airport.city.toLowerCase().includes(query) ||
            airport.iataCode.toLowerCase().includes(query)
        );
    });

    const fetchCheapestFlight = async () => {
        if (!banner.flight_ticket.from || !banner.flight_ticket.to) {
            return;
        }
        
        banner.flight_ticket.isLoadingFlights = true;
        banner.flight_ticket.cheapestPrice = null;
        banner.flight_ticket.cheapestFlightDetails = null;
        banner.flight_ticket.lastSearchError = null;

        try {
            const params = {
                fromAirportCode: banner.flight_ticket.from.iataCode,
                fromCountryName: banner.flight_ticket.from.countryName,
                toAirportCode: banner.flight_ticket.to.iataCode,
                toCountryName: banner.flight_ticket.to.countryName,
            };

            const result = await ajax.post('yab_fetch_flight_search', params);
            
            console.log('Flight Search Result:', result);

            if (result && result.cheapestPrice !== null) {
                banner.flight_ticket.cheapestPrice = result.cheapestPrice;
                banner.flight_ticket.cheapestFlightDetails = result.cheapestFlight;
                console.log(`Found cheapest price: €${result.cheapestPrice}`);
            } else {
                 console.log('No flights found or no price available.');
                 banner.flight_ticket.lastSearchError = result.message || 'No flights found for tomorrow.';
            }

        } catch (error) {
            console.error('Error fetching flight search:', error);
            banner.flight_ticket.lastSearchError = error.message;
            showModal('Error', `Could not fetch flight data: ${error.message}`);
        } finally {
            banner.flight_ticket.isLoadingFlights = false;
        }
    };

    const bookingUrl = computed(() => {
        if (!banner.flight_ticket.from || !banner.flight_ticket.to) {
            return '#';
        }

        const tomorrow = new Date();
        console.log(tomorrow);
        
        tomorrow.setDate(tomorrow.getDate() + 1);
        const yyyy = tomorrow.getFullYear();
        const mm = String(tomorrow.getMonth() + 1).padStart(2, '0');
        const dd = String(tomorrow.getDate()).padStart(2, '0');
        const departureDate = `${yyyy}-${mm}-${dd}`;
        console.log(departureDate);
        
        const from = banner.flight_ticket.from;
        const to = banner.flight_ticket.to;

        const baseUrl = 'https://www.tappersia.com/iran-flights/';
        const fromCityPath = from.city.toLowerCase().replace(/\s+/g, '-');
        const toCityPath = to.city.toLowerCase().replace(/\s+/g, '-');
        
        const path = `${fromCityPath}/${toCityPath}`;

        const params = new URLSearchParams({
            fromCountryName: from.countryName,
            fromCityName: from.city,
            fromAirportCode: from.iataCode,
            toCountryName: to.countryName,
            toCityName: to.city,
            toAirportCode: to.iataCode,
            departureDate: departureDate,
            pageNumber: 1,
            pageSize: 10,
            sort: 'earliest_time'
        });

        return `${baseUrl}${path}?${params.toString()}`;
    });

    const openFlightModal = async () => {
        isFlightModalOpen.value = true;
        
        const findAirportByIata = (iataCode) => {
            if (!iataCode) return null;
            return airports.value.find(a => a.iataCode === iataCode) || null;
        };

        const setTempFromBanner = () => {
            tempSelectedAirports.from = findAirportByIata(banner.flight_ticket.from?.iataCode);
            tempSelectedAirports.to = findAirportByIata(banner.flight_ticket.to?.iataCode);
        };

        if (airports.value.length === 0) {
            isAirportsLoading.value = true;
            try {
                const data = await ajax.post('yab_fetch_airports_from_api');
                airports.value = data;
                setTempFromBanner();
            } catch (error) {
                showModal('Error', `Could not fetch airports: ${error.message}`);
            } finally {
                isAirportsLoading.value = false;
            }
        } else {
            setTempFromBanner();
        }
    };

    const closeFlightModal = () => {
        isFlightModalOpen.value = false;
        airportSearchQuery.value = '';
    };

    const selectAirport = (airport) => {
        if (tempSelectedAirports.from && tempSelectedAirports.from.iataCode === airport.iataCode) {
            tempSelectedAirports.from = null;
            return;
        }
        if (tempSelectedAirports.to && tempSelectedAirports.to.iataCode === airport.iataCode) {
            tempSelectedAirports.to = null;
            return;
        }

        if (!tempSelectedAirports.from) {
            tempSelectedAirports.from = airport;
        } else if (!tempSelectedAirports.to) {
            tempSelectedAirports.to = airport;
        } else {
            tempSelectedAirports.from = airport;
            tempSelectedAirports.to = null;
        }
    };
    
    const isAirportSelected = (airport) => {
        return (tempSelectedAirports.from && tempSelectedAirports.from.iataCode === airport.iataCode) || 
               (tempSelectedAirports.to && tempSelectedAirports.to.iataCode === airport.iataCode);
    };

    const confirmAirportSelection = () => {
        if (tempSelectedAirports.from && tempSelectedAirports.to) {
            banner.flight_ticket.from = {
                countryName: tempSelectedAirports.from.countryName,
                city: tempSelectedAirports.from.city,
                iataCode: tempSelectedAirports.from.iataCode
            };
            banner.flight_ticket.to = {
                countryName: tempSelectedAirports.to.countryName,
                city: tempSelectedAirports.to.city,
                iataCode: tempSelectedAirports.to.iataCode
            };
            
            closeFlightModal();
            
            fetchCheapestFlight(); 
        } else {
            showModal('Selection Incomplete', 'Please select both an origin and a destination airport.');
        }
    };

    return {
        isFlightModalOpen,
        isAirportsLoading,
        filteredAirports,
        airportSearchQuery,
        tempSelectedAirports,
        openFlightModal,
        closeFlightModal,
        selectAirport,
        isAirportSelected,
        confirmAirportSelection,
        fetchCheapestFlight,
        bookingUrl,
    };
}
