const { createApp, ref, onMounted, watch, nextTick } = Vue;

import { HotelCarouselLogic } from './composables/useHotelCarousel.js';
import { TourCarouselLogic } from './composables/useTourCarousel.js';

import { useHotelCarouselValidation } from './composables/useHotelCarouselValidation.js';
import { useHotelThumbnails } from './composables/useHotelThumbnails.js';
import { useAjax } from '../composables/useAjax.js';
import { useBannerState } from '../composables/banner-state/bannerState.js';
import { useApiBanner } from '../composables/useApiBanner.js';
import { useDisplayConditions } from '../composables/useDisplayConditions.js';
import { ImageLoader } from './components.js';
import { useAppSetup } from './composables/useAppSetup.js';
import { useBannerActions } from './composables/useBannerActions.js';
import { useBannerSync } from './composables/useBannerSync.js';
import { useBannerStyling } from './composables/useBannerStyling.js';
import { useComputedProperties } from './composables/useComputedProperties.js';
import { usePromotionBanner } from './composables/usePromotionBanner.js';
import { useTourCarouselValidation } from './composables/useTourCarouselValidation.js';
import { useTourThumbnails } from './composables/useTourThumbnails.js';
import { useFlightTicket } from '../composables/useFlightTicket.js';
import { useWelcomePackageBanner } from '../composables/useWelcomePackageBanner.js';

export function initializeApp(yabData) {
    const app = createApp({
        components: {
            'yab-modal': YabModal,
            'image-loader': ImageLoader,
            'tour-carousel-logic': TourCarouselLogic,
            'hotel-carousel-logic': HotelCarouselLogic
        },
        setup() {
            const { banner, shortcode, mergeWithExisting, resetBannerState } = useBannerState();
            const ajax = useAjax(yabData.ajax_url, yabData.nonce);

            const currentView = ref('desktop');
            const selectedDoubleBanner = ref('left');

            const { appState, isSaving, modalComponent, showModal, selectElementType, goBackToSelection, goToListPage } = useAppSetup(yabData, resetBannerState);
            const bannerActions = useBannerActions(banner, isSaving, showModal, ajax);
            const displayConditionsLogic = useDisplayConditions(banner, ajax);
            const apiBannerLogic = useApiBanner(banner, showModal, ajax);
            const promotionBannerLogic = usePromotionBanner(banner, showModal);
            const bannerStyling = useBannerStyling(banner);
            const computedProps = useComputedProperties(banner, currentView, selectedDoubleBanner);
            const flightTicketLogic = useFlightTicket(banner, showModal, ajax);
            const welcomePackageLogic = useWelcomePackageBanner(banner, showModal, ajax);
            useBannerSync(banner, currentView);

            useTourCarouselValidation(banner, showModal);
            const tourThumbnailContainerRef = ref(null);
            const { thumbnailTours, isLoadingTourThumbnails } = useTourThumbnails(banner, ajax, tourThumbnailContainerRef);

            useHotelCarouselValidation(banner, showModal);
            const hotelThumbnailContainerRef = ref(null);
            const { thumbnailHotels, isLoadingThumbnails: isLoadingHotelThumbnails } = useHotelThumbnails(banner, ajax, hotelThumbnailContainerRef);

            onMounted(() => {
                displayConditionsLogic.siteData.posts = yabData.posts || [];
                displayConditionsLogic.siteData.pages = yabData.pages || [];
                displayConditionsLogic.siteData.categories = yabData.categories || [];

                if (yabData.existing_banner) {
                    const existingBannerCopy = JSON.parse(JSON.stringify(yabData.existing_banner));
                    mergeWithExisting(existingBannerCopy);

                    if (banner.type === 'api-banner' && banner.api.selectedHotel?.id) {
                        apiBannerLogic.fetchFullHotelDetails(banner.api.selectedHotel.id);
                    }
                    if (banner.type === 'api-banner' && banner.api.selectedTour?.id) {
                        apiBannerLogic.fetchFullTourDetails(banner.api.selectedTour.id);
                    }

                    if (banner.type === 'flight-ticket' && banner.flight_ticket.from && banner.flight_ticket.to) {
                        flightTicketLogic.fetchCheapestFlight();
                    }

                    appState.value = 'editor';
                } else {
                    appState.value = 'selection';
                }
            });

            const reinitializeColoris = () => {
                if (typeof Coloris !== 'undefined') {
                    setTimeout(() => { 
                        Coloris({
                            theme: 'pill',
                            themeMode: 'dark',
                            format: 'mixed',
                            alpha: true,
                            onChange: (color, inputEl) => {
                                if (inputEl) {
                                    const event = new Event('input', { bubbles: true });
                                    inputEl.value = color;
                                    inputEl.dispatchEvent(event);

                                    const preview = inputEl.previousElementSibling;
                                    if (preview && preview.style) {
                                        preview.style.backgroundColor = color;
                                    }
                                }
                            }
                        });
                    }, 50);
                } else {
                    console.error("Coloris library is not loaded.");
                }
            };

            watch(currentView, async (newView, oldView) => {
                if (newView !== oldView) {
                    await nextTick();
                    reinitializeColoris(); 
                }
            });
            watch(selectedDoubleBanner, async (newSelection, oldSelection) => {
                if (newSelection !== oldSelection) {
                    await nextTick();
                    reinitializeColoris(); 
                }
            });

            watch(appState, async (newState, oldState) => {
                if (newState === 'editor' && oldState !== 'editor') {
                    await nextTick();
                    reinitializeColoris();
                }
            }, { immediate: true }); 

            const addGradientStop = (stopsArray) => {
                if (!Array.isArray(stopsArray)) {
                    console.error('addGradientStop expected an array.', stopsArray);
                    return;
                }
                const lastStop = stopsArray.length > 0 ? stopsArray[stopsArray.length - 1].stop : 0;
                const newStopPosition = Math.min(100, lastStop + 10);
                stopsArray.push({ color: 'rgba(255, 255, 255, 0.5)', stop: newStopPosition });
                stopsArray.sort((a, b) => a.stop - b.stop);
            };
            const removeGradientStop = (stopsArray, index) => {
                if (!Array.isArray(stopsArray)) {
                    console.error('removeGradientStop expected an array.', stopsArray);
                    return;
                }
                if (stopsArray.length > 1) {
                    stopsArray.splice(index, 1);
                } else {
                    showModal('Info', 'A gradient must have at least one color stop.');
                }
            };

            const copyPlaceholder = (placeholder) => {
                if (navigator.clipboard && window.isSecureContext) {
                    navigator.clipboard.writeText(placeholder).then(() => {
                        showModal('Copied!', `Placeholder "${placeholder}" copied to clipboard.`);
                    }).catch(err => {
                        console.error('Failed to copy placeholder: ', err);
                        showModal('Error', 'Could not copy placeholder.');
                    });
                } else {
                    try {
                        const textArea = document.createElement("textarea");
                        textArea.value = placeholder;
                        textArea.style.position = "absolute"; textArea.style.left = "-9999px";
                        document.body.appendChild(textArea);
                        textArea.select(); document.execCommand('copy');
                        document.body.removeChild(textArea);
                        showModal('Copied!', `Placeholder "${placeholder}" copied to clipboard.`);
                    } catch (err) {
                        console.error('Fallback copy failed: ', err);
                        showModal('Error', 'Could not copy placeholder.');
                    }
                }
            };

            return {
                appState, isSaving, banner, shortcode, modalComponent, currentView, selectedDoubleBanner,
                selectElementType: (type) => { banner.type = selectElementType(type) },
                goBackToSelection, goToListPage,
                ...bannerActions,
                ajax,
                ...apiBannerLogic,
                ...displayConditionsLogic,
                ...promotionBannerLogic,
                ...bannerStyling,
                ...computedProps, 
                ...flightTicketLogic,
                ...welcomePackageLogic,
                addGradientStop, removeGradientStop,
                copyPlaceholder,
                tourThumbnailContainerRef,
                thumbnailTours,
                isLoadingTourThumbnails,
                hotelThumbnailContainerRef,
                thumbnailHotels,
                isLoadingHotelThumbnails,
            };
        }
    });

    app.mount('#yab-app');
}
