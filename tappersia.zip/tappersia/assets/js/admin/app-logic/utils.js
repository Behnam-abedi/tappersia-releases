// tappersia/assets/js/admin/app-logic/utils.js
export const bannerStyles = (b) => {
    if (!b) return '';
    if (b.backgroundType === 'gradient') {
        if (!b.gradientStops || b.gradientStops.length === 0) {
            return 'transparent';
        }
        const sortedStops = [...b.gradientStops].sort((a, b) => a.stop - b.stop);
        const stopsString = sortedStops.map(s => `${s.color} ${s.stop}%`).join(', ');
        return `linear-gradient(${b.gradientAngle || 90}deg, ${stopsString})`;
    }
    return b.bgColor;
};

export const contentAlignment = (align) => align === 'right' ? 'flex-end' : (align === 'center' ? 'center' : 'flex-start');

export const imageStyleObject = (b) => {
    const style = { 
        position: 'absolute', 
        objectFit: 'cover', // Always cover
        bottom: `${b.imagePosBottom||0}px`,
        // --- START FIX: Prioritize Left, default to Right if neither is properly set in legacy data ---
        right: 'auto', // Reset right by default
        left: 'auto'
    };

    if (b.imagePosLeft !== undefined) {
        // Use Left position if it exists (Flight Ticket / New Single)
        style.left = `${b.imagePosLeft || 0}px`;
        style.right = 'auto';
    } else {
        // Use Right position for legacy/default Single Banner behavior
        style.right = `${b.imagePosRight || 0}px`;
        style.left = 'auto';
    }
    // --- END FIX ---

    if (b.enableCustomImageSize) {
        // Use custom values if they exist, otherwise fallback to default
        style.width = (b.imageWidth !== null && b.imageWidth !== '') ? `${b.imageWidth}${b.imageWidthUnit}` : 'auto';
        style.height = (b.imageHeight !== null && b.imageHeight !== '') ? `${b.imageHeight}${b.imageHeightUnit}` : '100%';
    } else {
        // Default behavior
        style.width = 'auto';
        style.height = '100%';
    }
    return style;
};

// START: NEW FUNCTIONS FOR API BANNER
export const getApiBannerStyles = (view, banner) => {
    const settings = view === 'desktop' ? banner.api.design : banner.api.design_mobile;
    
    return {
        background: bannerStyles(settings),
        border: `${settings.enableBorder ? settings.borderWidth : 0}px solid ${settings.borderColor}`,
        borderRadius: `${settings.borderRadius}px`,
        width: `${settings.width}${settings.widthUnit}`, // *** 2. تغییر کرد ***
        minHeight: `${settings.minHeight}px`, // *** 2. تغییر کرد ***
        height: 'auto',
        flexDirection: settings.layout === 'right' ? 'row-reverse' : 'row',
        overflow: 'hidden',
        position: 'relative',
    };
};

export const getApiContentStyles = (view, banner) => {
    const settings = view === 'desktop' ? banner.api.design : banner.api.design_mobile;
    
    return {
        padding: `${settings.paddingY}px ${settings.paddingX}px`, // *** 3. تغییر کرد ***
        textAlign: settings.layout === 'right' ? 'right' : 'left',
        justifyContent: 'space-between'
    };
};
// END: NEW FUNCTIONS FOR API BANNER