export const bannerStyles = (b) => {
    if (!b) return '';
    if (b.backgroundType === 'gradient') {
        if (!b.gradientStops || b.gradientStops.length === 0) {
            return 'transparent';
        }
        const sortedStops = [...b.gradientStops].sort((a, b) => a.stop - b.stop);
        const stopsString = sortedStops.map(s => `${s.color} ${s.stop}%`).join(', ');
        return `linear-gradient(${b.gradientAngle || 90}deg, ${stopsString})`;
    }
    return b.bgColor;
};

export const contentAlignment = (align) => align === 'right' ? 'flex-end' : (align === 'center' ? 'center' : 'flex-start');

export const imageStyleObject = (b) => {
    const style = { 
        position: 'absolute', 
        objectFit: 'cover',
        bottom: `${b.imagePosBottom||0}px`,
        right: 'auto',
        left: 'auto'
    };

    if (b.imagePosLeft !== undefined) {
        style.left = `${b.imagePosLeft || 0}px`;
        style.right = 'auto';
    } else {
        style.right = `${b.imagePosRight || 0}px`;
        style.left = 'auto';
    }

    if (b.enableCustomImageSize) {
        style.width = (b.imageWidth !== null && b.imageWidth !== '') ? `${b.imageWidth}${b.imageWidthUnit}` : 'auto';
        style.height = (b.imageHeight !== null && b.imageHeight !== '') ? `${b.imageHeight}${b.imageHeightUnit}` : '100%';
    } else {
        style.width = 'auto';
        style.height = '100%';
    }
    return style;
};

export const getApiBannerStyles = (view, banner) => {
    const settings = view === 'desktop' ? banner.api.design : banner.api.design_mobile;
    
    return {
        background: bannerStyles(settings),
        border: `${settings.enableBorder ? settings.borderWidth : 0}px solid ${settings.borderColor}`,
        borderRadius: `${settings.borderRadius}px`,
        width: `${settings.width}${settings.widthUnit}`,
        minHeight: `${settings.minHeight}px`,
        height: 'auto',
        flexDirection: settings.layout === 'right' ? 'row-reverse' : 'row',
        overflow: 'hidden',
        position: 'relative',
    };
};

export const getApiContentStyles = (view, banner) => {
    const settings = view === 'desktop' ? banner.api.design : banner.api.design_mobile;
    
    return {
        padding: `${settings.paddingY}px ${settings.paddingX}px`,
        textAlign: settings.layout === 'right' ? 'right' : 'left',
        justifyContent: 'space-between'
    };
};
