export function useBannerActions(banner, isSaving, showModal, ajax) {
    const saveBanner = async () => {
        if (!banner.name) {
            return showModal('Input Required', 'Please enter a name for the banner.');
        }
        isSaving.value = true;
        try {
            const data = await ajax.post('yab_save_banner', {
                banner_data: JSON.stringify(banner),
                banner_type: banner.type,
            });
            if (data.banner_id) {
                banner.id = data.banner_id;
            }
            showModal('Success!', 'Banner saved successfully!');
        } catch (error) {
            showModal('Error', error.message);
        } finally {
            isSaving.value = false;
        }
    };

    const openMediaUploader = (targetKey) => {
        const uploader = wp.media({ title: 'Select Image', button: { text: 'Use this Image' }, multiple: false });
        uploader.on('select', () => {
            const attachment = uploader.state().get('selection').first().toJSON();
            
            if (targetKey === 'promotion') {
                banner.promotion.iconUrl = attachment.url;
                return;
            }
            
            if (targetKey === 'flight_ticket_design') {
                banner.flight_ticket.design.imageUrl = attachment.url;
                return;
            }

            let targetObject = banner;
            const keys = targetKey.split('_');
            
            keys.forEach(key => {
                if (targetObject && typeof targetObject[key] !== 'undefined') {
                    targetObject = targetObject[key];
                }
            });
            
            if (targetObject && typeof targetObject === 'object') {
                targetObject.imageUrl = attachment.url;

                if (keys[0] === 'single') {
                    banner.single_mobile.imageUrl = attachment.url;
                } else if (keys[0] === 'double' && keys[1] === 'desktop') {
                    const position = keys[2];
                    banner.double.mobile[position].imageUrl = attachment.url;
                }
            }
        });
        uploader.open();
    };
    
    const removeImage = (targetKey) => { 
        if (targetKey === 'promotion') {
            banner.promotion.iconUrl = '';
            return;
        }

        if (targetKey === 'flight_ticket_design') {
            banner.flight_ticket.design.imageUrl = '';
            return;
        }

        let targetObject = banner;
        const keys = targetKey.split('_');

        keys.forEach(key => {
            if (targetObject && typeof targetObject[key] !== 'undefined') {
                targetObject = targetObject[key];
            }
        });

        if (targetObject && typeof targetObject === 'object') {
            targetObject.imageUrl = '';
             if (keys[0] === 'single') {
                banner.single_mobile.imageUrl = '';
            } else if (keys[0] === 'double' && keys[1] === 'desktop') {
                const position = keys[2];
                banner.double.mobile[position].imageUrl = '';
            }
        }
    };
    
const copyShortcode = (input) => {
        // ۱. بررسی می‌کنیم که آیا بنر ذخیره شده است یا خیر
        // (نکته: دسترسی به banner.id و banner.displayMethod در اینجا فرض بر این است که متغیر banner در دسترس است)
        if ((!banner.id || banner.id === 0) && banner.displayMethod === 'Embeddable') {
            return showModal('Info', 'Please save the banner first to generate the shortcode.');
        }

        // ۲. تشخیص متن برای کپی کردن
        let textToCopy = '';

        if (typeof input === 'string') {
            // حالت اول: فراخوانی به صورت copyShortcode(shortcode) -> استفاده در هدر
            textToCopy = input;
        } else if (input && input.target && input.target.value) {
            // حالت دوم: فراخوانی به صورت ایونت @click="copyShortcode" -> استفاده در اینپوت‌های لیست
            textToCopy = input.target.value;
        }

        if (!textToCopy) {
            console.error('No text found to copy.');
            return;
        }
    
        // ۳. کپی در کلیپ‌بورد
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(textToCopy).then(() => {
                showModal('Success', 'Shortcode copied to clipboard!');
            }).catch(err => {
                console.error('Failed to copy with navigator.clipboard: ', err);
                showModal('Error', 'Could not copy the shortcode.');
            });
        } else {
            // ۴. فال‌بک قدیمی (برای مرورگرهای خاص یا محیط‌های غیر Secure)
            // چون ممکن است المان ما div باشد، باید یک textarea موقت بسازیم
            try {
                const textArea = document.createElement("textarea");
                textArea.value = textToCopy;
                
                // مخفی کردن textarea از دید کاربر
                textArea.style.position = "fixed";
                textArea.style.left = "-9999px";
                document.body.appendChild(textArea);
                
                textArea.focus();
                textArea.select();
                
                const successful = document.execCommand('copy');
                document.body.removeChild(textArea);
                
                if (successful) {
                    showModal('Success', 'Shortcode copied to clipboard!');
                } else {
                    throw new Error('execCommand copy failed');
                }
            } catch (err) {
                console.error('Fallback copy failed: ', err);
                showModal('Error', 'Could not copy the shortcode. Please copy it manually.');
            }
        }
    };

    return { saveBanner, openMediaUploader, removeImage, copyShortcode };
}
