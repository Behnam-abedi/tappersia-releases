const { watch, nextTick } = Vue;

export function useTourCarouselValidation(banner, showModal) {
    watch(
        () => ({
            loop: banner.tour_carousel.settings.loop,
            isDoubled: banner.tour_carousel.settings.isDoubled,
            slidesPerView: banner.tour_carousel.settings.slidesPerView,
            tourCount: banner.tour_carousel.selectedTours.length
        }),
        (newVal, oldVal) => {
            const { loop, isDoubled, slidesPerView, tourCount } = newVal;
            
            if (banner.type !== 'tour-carousel' || tourCount === 0) {
                return;
            }

            if (isDoubled) {
                if (tourCount % 2 !== 0) {
                    nextTick(() => {
                        banner.tour_carousel.settings.isDoubled = false;
                        showModal(
                            'Double Carousel Disabled',
                            'The number of selected tours must be an even number to use the Double Carousel. Please add or remove a tour.'
                        );
                    });
                    return;
                }
                
                if (!loop) {
                    let maxSlides = 4;
                    if (tourCount < 8) {
                        maxSlides = tourCount / 2;
                    }

                    if (slidesPerView > maxSlides) {
                        nextTick(() => {
                            banner.tour_carousel.settings.slidesPerView = maxSlides;
                            showModal(
                                'Adjustment',
                                `With ${tourCount} tours in a Double Carousel, the maximum 'Slides Per View' is ${maxSlides}. It has been adjusted automatically.`
                            );
                        });
                        return;
                    }
                }
            }

            if (!isDoubled && !loop) {
                if (tourCount < slidesPerView) {
                    if (newVal.slidesPerView !== oldVal.slidesPerView) {
                        nextTick(() => {
                            banner.tour_carousel.settings.slidesPerView = tourCount;
                            showModal(
                                'Adjustment',
                                `Slides Per View was adjusted to ${tourCount} because you only have ${tourCount} tour(s) selected.`
                            );
                        });
                    }
                }
            }
        },
        { deep: true, immediate: true }
    );
}
