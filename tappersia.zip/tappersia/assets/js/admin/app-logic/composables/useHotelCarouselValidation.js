const { watch, nextTick } = Vue;

export function useHotelCarouselValidation(banner, showModal) {

    watch(
        () => ({
            loop: banner.hotel_carousel?.settings?.loop,
            isDoubled: banner.hotel_carousel?.settings?.isDoubled,
            slidesPerView: banner.hotel_carousel?.settings?.slidesPerView,
            hotelCount: banner.hotel_carousel?.selectedHotels?.length ?? 0
        }),
        (newVal, oldVal) => {
            if (!newVal || newVal.loop === undefined) return;

            const { loop, isDoubled, slidesPerView, hotelCount } = newVal;

            if (banner.type !== 'hotel-carousel' || hotelCount === 0) {
                return;
            }

            if (isDoubled) {
                if (hotelCount % 2 !== 0) {
                    nextTick(() => {
                        banner.hotel_carousel.settings.isDoubled = false;
                        showModal(
                            'Double Carousel Disabled',
                            'The number of selected hotels must be an even number to use the Double Carousel.'
                        );
                    });
                    return;
                }
                if (!loop) {
                    let maxSlides = Math.min(4, Math.floor(hotelCount / 2));
                    if (slidesPerView > maxSlides) {
                        nextTick(() => {
                            banner.hotel_carousel.settings.slidesPerView = maxSlides;
                            showModal(
                                'Adjustment',
                                `With ${hotelCount} hotels in a Double Carousel, max 'Slides Per View' is ${maxSlides}. Adjusted automatically.`
                            );
                        });
                        return;
                    }
                }
            }

            if (!isDoubled && !loop) {
                if (hotelCount < slidesPerView) {
                    if (newVal.slidesPerView !== oldVal?.slidesPerView) {
                        nextTick(() => {
                            banner.hotel_carousel.settings.slidesPerView = hotelCount;
                            showModal(
                                'Adjustment',
                                `Slides Per View adjusted to ${hotelCount} (you only have ${hotelCount} hotel(s) selected).`
                            );
                        });
                    }
                }
            }
        },
        { deep: true, immediate: true }
    );
}
