const { watch } = Vue;

import { 
    createDefaultPart, createDefaultMobilePart,
    createDefaultHotelCarouselDesktopPart, createDefaultHotelCarouselMobilePart,
    createDefaultTourCarouselDesktopPart, createDefaultTourCarouselMobilePart,
    createDefaultSimplePart, createDefaultSimpleBannerMobilePart,
    createDefaultStickySimplePart, createDefaultStickySimpleMobilePart,
    createDefaultDoubleBannerPart, createDefaultDoubleBannerMobilePart,
    createDefaultApiDesign, createDefaultApiMobileDesign,
    createDefaultPromotionPart, createDefaultPromotionMobilePart,
    createDefaultFlightTicketPart, createDefaultFlightTicketMobilePart
} from '../../composables/banner-state/defaults/index.js';

export function useBannerSync(banner, currentView) {

    const defaults = {
        single: { desktop: createDefaultPart(), mobile: createDefaultMobilePart() },
        simple: { desktop: createDefaultSimplePart(), mobile: createDefaultSimpleBannerMobilePart() },
        sticky: { desktop: createDefaultStickySimplePart(), mobile: createDefaultStickySimpleMobilePart() },
        double: { desktop: createDefaultDoubleBannerPart(), mobile: createDefaultDoubleBannerMobilePart() },
        promotion: { desktop: createDefaultPromotionPart(), mobile: createDefaultPromotionMobilePart() },
        api: { desktop: createDefaultApiDesign(), mobile: createDefaultApiMobileDesign() },
        tour: { desktop: createDefaultTourCarouselDesktopPart(), mobile: createDefaultTourCarouselMobilePart() },
        hotel: { desktop: createDefaultHotelCarouselDesktopPart(), mobile: createDefaultHotelCarouselMobilePart() },
        flight: { desktop: createDefaultFlightTicketPart().design, mobile: createDefaultFlightTicketMobilePart().design }
    };

    /**
     * تابع کمکی همگام‌سازی
     */
    const syncFields = (desktopState, mobileState, desktopDefs, mobileDefs, fields) => {
        fields.forEach(key => {
            if (desktopState[key] === undefined || desktopDefs[key] === undefined) return;

            const currentDesktopVal = desktopState[key];
            const defaultDesktopVal = desktopDefs[key];

            const isModified = JSON.stringify(currentDesktopVal) !== JSON.stringify(defaultDesktopVal);

            if (isModified) {
                mobileState[key] = JSON.parse(JSON.stringify(currentDesktopVal));
            } else {
                mobileState[key] = JSON.parse(JSON.stringify(mobileDefs[key]));
            }
        });
    };

    // =========================================================================
    // 1. Single Banner Logic
    // =========================================================================
    watch(() => banner.single, (newDesktop) => {
        if (banner.type !== 'single-banner') return;

        const globalFields = [
            'backgroundType', 'bgColor', 'gradientAngle', 'gradientStops',
            'titleText', 'titleColor', 'titleWeight',
            'descText', 'descColor', 'descWeight',
            'buttonText', 'buttonLink', 'buttonBgColor', 'buttonTextColor', 'buttonBgHoverColor', 'buttonFontWeight',
            'imageUrl', 'enableBorder', 'borderColor', 'layerOrder', 'alignment'
        ];

        const responsiveFields = [
            'titleSize', 'titleMarginTop',
            'descSize', 'descMarginTop', 'descMarginBottom',
            'buttonFontSize', 'buttonBorderRadius', 'buttonPaddingY', 'buttonPaddingX', 'buttonMarginTopAuto', 'buttonMarginTop', 'buttonMarginBottom',
            'enableCustomImageSize', 'imageWidth', 'imageWidthUnit', 'imageHeight', 'imageHeightUnit',
            'imagePosRight', 'imagePosBottom', 'imagePosLeft',
            'borderWidth', 'borderRadius'
        ];

        syncFields(newDesktop, banner.single_mobile, defaults.single.desktop, defaults.single.mobile, globalFields);

        if (!banner.isMobileConfigured) {
            syncFields(newDesktop, banner.single_mobile, defaults.single.desktop, defaults.single.mobile, responsiveFields);
        }
    }, { deep: true });


    // =========================================================================
    // 2. Simple Banner Logic
    // =========================================================================
    watch(() => banner.simple, (newDesktop) => {
        if (banner.type !== 'simple-banner') return;

        const globalFields = [
            'backgroundType', 'bgColor', 'gradientAngle', 'gradientStops', 
            'text', 'textColor', 'textWeight',
            'buttonText', 'buttonLink', 'buttonBgColor', 'buttonTextColor', 'buttonBgHoverColor', 
            'buttonFontWeight', 'enableBorder', 'borderColor', 'direction'
        ];
        
        const responsiveFields = [
            'textSize', 
            'buttonFontSize', 'buttonBorderRadius', 'buttonPaddingY', 'buttonPaddingX', 'buttonMinWidth',
            'borderWidth', 'borderRadius',
            'minHeight', 'contentWidth', 'contentWidthUnit', 'paddingY', 'paddingX', 'paddingXUnit'
        ];

        syncFields(newDesktop, banner.simple_mobile, defaults.simple.desktop, defaults.simple.mobile, globalFields);

        if (!banner.isMobileConfigured) {
            syncFields(newDesktop, banner.simple_mobile, defaults.simple.desktop, defaults.simple.mobile, responsiveFields);
        }
    }, { deep: true });


    // =========================================================================
    // 3. Sticky Simple Banner Logic
    // =========================================================================
    watch(() => banner.sticky_simple, (newDesktop) => {
        if (banner.type !== 'sticky-simple-banner') return;

        const globalFields = [
            'backgroundType', 'bgColor', 'gradientAngle', 'gradientStops', 
            'text', 'textColor', 'textWeight',
            'buttonText', 'buttonLink', 'buttonBgColor', 'buttonTextColor', 'buttonBgHoverColor', 
            'buttonFontWeight', 'enableBorder', 'borderColor', 'direction'
        ];
        
        const responsiveFields = [
            'textSize', 
            'buttonFontSize', 'buttonBorderRadius', 'buttonPaddingY', 'buttonPaddingX', 'buttonMinWidth',
            'borderWidth', 'borderRadius',
            'minHeight', 'contentWidth', 'contentWidthUnit', 'paddingY', 'paddingX', 'paddingXUnit'
        ];

        syncFields(newDesktop, banner.sticky_simple_mobile, defaults.sticky.desktop, defaults.sticky.mobile, globalFields);

        if (!banner.isMobileConfigured) {
            syncFields(newDesktop, banner.sticky_simple_mobile, defaults.sticky.desktop, defaults.sticky.mobile, responsiveFields);
        }
    }, { deep: true });


    // =========================================================================
    // 4. Promotion Banner Logic
    // =========================================================================
    watch(() => banner.promotion, (newDesktop) => {
        if (banner.type !== 'promotion-banner') return;

        const globalFields = [
            'enableBorder', 'borderColor', 'direction',
            'headerBackgroundType', 'headerBgColor', 'headerGradientAngle', 'headerGradientStops',
            'iconUrl', 'headerText', 'headerTextColor', 'headerFontWeight',
            'bodyBackgroundType', 'bodyBgColor', 'bodyGradientAngle', 'bodyGradientStops',
            'bodyText', 'bodyTextColor', 'bodyFontWeight',
            'links'
        ];

        const responsiveFields = [
            'borderWidth', 'borderRadius',
            'iconSize', 'headerPaddingX', 'headerPaddingY', 'headerFontSize',
            'bodyPaddingX', 'bodyPaddingY', 'bodyFontSize', 'bodyLineHeight'
        ];

        syncFields(newDesktop, banner.promotion_mobile, defaults.promotion.desktop, defaults.promotion.mobile, globalFields);

        if (!banner.isMobileConfigured) {
            syncFields(newDesktop, banner.promotion_mobile, defaults.promotion.desktop, defaults.promotion.mobile, responsiveFields);
        }
    }, { deep: true });


    // =========================================================================
    // 5. Double Banner Logic
    // =========================================================================
    watch(() => banner.double.desktop, (newDesktop) => {
        if (banner.type !== 'double-banner') return;

        const globalFields = [
            'imageUrl', 'layerOrder', 'backgroundType', 'bgColor', 'gradientAngle', 'gradientStops',
            'enableBorder', 'borderColor', 
            'titleText', 'titleColor', 'titleWeight',
            'descText', 'descColor', 'descWeight',
            'buttonText', 'buttonLink', 'buttonBgColor', 'buttonTextColor', 'buttonBgHoverColor',
            'buttonFontWeight',
            'alignment', 'imagePosRight', 'imagePosBottom'
        ];

        const responsiveFields = [
            'borderWidth', 'borderRadius',
            'titleSize', 'titleMarginTop',
            'descSize', 'marginTopDescription', 'descMarginBottom',
            'buttonFontSize', 'buttonBorderRadius', 'buttonPaddingY', 'buttonPaddingX', 'buttonMarginBottom',
            'enableCustomImageSize', 'imageWidth', 'imageWidthUnit', 'imageHeight', 'imageHeightUnit', 
            'paddingY', 'paddingX', 'minHeight', 'contentWidth', 'contentWidthUnit'
        ];

        ['left', 'right'].forEach(pos => {
            syncFields(newDesktop[pos], banner.double.mobile[pos], defaults.double.desktop, defaults.double.mobile, globalFields);
            
            if (!banner.double.isMobileConfigured) {
                syncFields(newDesktop[pos], banner.double.mobile[pos], defaults.double.desktop, defaults.double.mobile, responsiveFields);
            }
        });
    }, { deep: true });


    // =========================================================================
    // 6. API Banner Logic
    // =========================================================================
    watch(() => banner.api.design, (newDesktop) => {
        if (banner.type !== 'api-banner') return;

        const globalFields = [
            'layout', 'backgroundType', 'bgColor', 'gradientAngle', 'gradientStops',
            'enableBorder', 'borderColor',
            'titleColor', 'titleWeight',
            'cityColor',
            'ratingBoxBgColor', 'ratingBoxColor', 'ratingBoxWeight',
            'ratingTextColor', 'ratingTextWeight', 'reviewColor',
            'priceFromColor', 'priceAmountColor', 'priceAmountWeight', 'priceNightColor'
        ];

        const responsiveFields = [
            'width', 'widthUnit', 'minHeight', 'imageContainerWidth', 'imageContainerWidthUnit',
            'borderWidth', 'borderRadius', 'paddingY', 'paddingX',
            'titleSize', 'titleMarginTop',
            'subHeaderMarginTop', 'subHeaderMarginBottom', 'bottomSectionMarginBottom',
            'starSize', 'citySize',
            'ratingBoxSize', 'ratingTextSize', 'reviewSize',
            'priceFromSize', 'priceAmountSize', 'priceNightSize'
        ];

        syncFields(newDesktop, banner.api.design_mobile, defaults.api.desktop, defaults.api.mobile, globalFields);

        if (!banner.api.isMobileConfigured) {
            syncFields(newDesktop, banner.api.design_mobile, defaults.api.desktop, defaults.api.mobile, responsiveFields);
        }
    }, { deep: true });


    // =========================================================================
    // 7. Tour Carousel Logic
    // =========================================================================
    watch(() => banner.tour_carousel.settings, (newDesktop) => {
        if (banner.type !== 'tour-carousel') return;

        // Root Settings
        const topGlobal = ['loop', 'isDoubled', 'gridFill', 'direction'];
        const topResponsive = ['slidesPerView', 'cardWidth', 'spaceBetween', 'responsiveSlides', 'autoGap', 'rowGap'];
        syncFields(newDesktop, banner.tour_carousel.settings_mobile, defaults.tour.desktop, defaults.tour.mobile, topGlobal);
        
        if (!banner.tour_carousel.isMobileConfigured) {
            syncFields(newDesktop, banner.tour_carousel.settings_mobile, defaults.tour.desktop, defaults.tour.mobile, topResponsive);
        }

        // Header
        const headerGlobal = ['text', 'fontWeight', 'color', 'lineColor'];
        const headerResponsive = ['fontSize', 'marginTop'];
        syncFields(newDesktop.header, banner.tour_carousel.settings_mobile.header, defaults.tour.desktop.header, defaults.tour.mobile.header, headerGlobal);
        
        if (!banner.tour_carousel.isMobileConfigured) {
             syncFields(newDesktop.header, banner.tour_carousel.settings_mobile.header, defaults.tour.desktop.header, defaults.tour.mobile.header, headerResponsive);
        }

        // Card Root
        const cardGlobal = ['backgroundType', 'bgColor', 'gradientAngle', 'gradientStops', 'borderColor'];
        const cardResponsive = ['height', 'borderWidth', 'borderRadius', 'padding', 'imageHeight'];
        syncFields(newDesktop.card, banner.tour_carousel.settings_mobile.card, defaults.tour.desktop.card, defaults.tour.mobile.card, cardGlobal);
        
        if (!banner.tour_carousel.isMobileConfigured) {
             syncFields(newDesktop.card, banner.tour_carousel.settings_mobile.card, defaults.tour.desktop.card, defaults.tour.mobile.card, cardResponsive);
        }

        // Card Sub Objects
        const subObjects = ['province', 'title', 'infoRow', 'price', 'duration', 'rating', 'reviews', 'button'];
        subObjects.forEach(obj => {
            const allKeys = Object.keys(defaults.tour.desktop.card[obj]);
            const globalSub = allKeys.filter(k => 
                k.toLowerCase().includes('color') || 
                k.toLowerCase().includes('weight') || 
                k.toLowerCase().includes('align') ||
                k.toLowerCase().includes('blur')
            );
            const responsiveSub = allKeys.filter(k => !globalSub.includes(k));

            syncFields(newDesktop.card[obj], banner.tour_carousel.settings_mobile.card[obj], defaults.tour.desktop.card[obj], defaults.tour.mobile.card[obj], globalSub);
            
            if (!banner.tour_carousel.isMobileConfigured) {
                syncFields(newDesktop.card[obj], banner.tour_carousel.settings_mobile.card[obj], defaults.tour.desktop.card[obj], defaults.tour.mobile.card[obj], responsiveSub);
            }
        });

        // Autoplay
        syncFields(newDesktop.autoplay, banner.tour_carousel.settings_mobile.autoplay, defaults.tour.desktop.autoplay, defaults.tour.mobile.autoplay, ['enabled', 'delay']);
        
    }, { deep: true });


    // =========================================================================
    // 8. Hotel Carousel Logic
    // =========================================================================
    watch(() => banner.hotel_carousel.settings, (newDesktop) => {
        if (banner.type !== 'hotel-carousel') return;

        // Root
        const topGlobal = ['loop', 'isDoubled', 'gridFill', 'direction'];
        const topResponsive = ['slidesPerView', 'cardWidth', 'spaceBetween', 'responsiveSlides', 'autoGap', 'rowGap'];
        syncFields(newDesktop, banner.hotel_carousel.settings_mobile, defaults.hotel.desktop, defaults.hotel.mobile, topGlobal);
        
        if(!banner.hotel_carousel.isMobileConfigured) {
            syncFields(newDesktop, banner.hotel_carousel.settings_mobile, defaults.hotel.desktop, defaults.hotel.mobile, topResponsive);
        }

        // Header
        const headerGlobal = ['text', 'fontWeight', 'color', 'lineColor'];
        const headerResponsive = ['fontSize', 'marginTop'];
        syncFields(newDesktop.header, banner.hotel_carousel.settings_mobile.header, defaults.hotel.desktop.header, defaults.hotel.mobile.header, headerGlobal);
        
        if(!banner.hotel_carousel.isMobileConfigured) {
            syncFields(newDesktop.header, banner.hotel_carousel.settings_mobile.header, defaults.hotel.desktop.header, defaults.hotel.mobile.header, headerResponsive);
        }

        // Card Root
        const cardGlobal = ['bgColor', 'borderColor'];
        const cardResponsive = ['minHeight', 'padding', 'borderWidth', 'borderRadius'];
        syncFields(newDesktop.card, banner.hotel_carousel.settings_mobile.card, defaults.hotel.desktop.card, defaults.hotel.mobile.card, cardGlobal);
        
        if(!banner.hotel_carousel.isMobileConfigured) {
            syncFields(newDesktop.card, banner.hotel_carousel.settings_mobile.card, defaults.hotel.desktop.card, defaults.hotel.mobile.card, cardResponsive);
        }

        // Sub Objects
        const subObjects = ['image', 'imageContainer', 'imageOverlay', 'stars', 'bodyContent', 'title', 'rating', 'tags', 'divider', 'price'];
        subObjects.forEach(obj => {
            const allKeys = Object.keys(defaults.hotel.desktop.card[obj]);
            const globalSub = allKeys.filter(k => 
                k.toLowerCase().includes('color') || 
                k.toLowerCase().includes('weight') ||
                k.toLowerCase().includes('gradient')
            );
            const responsiveSub = allKeys.filter(k => !globalSub.includes(k));

            syncFields(newDesktop.card[obj], banner.hotel_carousel.settings_mobile.card[obj], defaults.hotel.desktop.card[obj], defaults.hotel.mobile.card[obj], globalSub);
            
            if(!banner.hotel_carousel.isMobileConfigured) {
                syncFields(newDesktop.card[obj], banner.hotel_carousel.settings_mobile.card[obj], defaults.hotel.desktop.card[obj], defaults.hotel.mobile.card[obj], responsiveSub);
            }
        });

        // Badges
        ['bestSeller', 'discount'].forEach(badge => {
             const allKeys = Object.keys(defaults.hotel.desktop.card.badges[badge]);
             const globalSub = allKeys.filter(k => k.toLowerCase().includes('color'));
             const responsiveSub = allKeys.filter(k => !globalSub.includes(k));

             syncFields(newDesktop.card.badges[badge], banner.hotel_carousel.settings_mobile.card.badges[badge], defaults.hotel.desktop.card.badges[badge], defaults.hotel.mobile.card.badges[badge], globalSub);
             
             if(!banner.hotel_carousel.isMobileConfigured) {
                syncFields(newDesktop.card.badges[badge], banner.hotel_carousel.settings_mobile.card.badges[badge], defaults.hotel.desktop.card.badges[badge], defaults.hotel.mobile.card.badges[badge], responsiveSub);
             }
        });

        // Autoplay
        syncFields(newDesktop.autoplay, banner.hotel_carousel.settings_mobile.autoplay, defaults.hotel.desktop.autoplay, defaults.hotel.mobile.autoplay, ['enabled', 'delay']);

    }, { deep: true });


    // =========================================================================
    // 9. Flight Ticket Logic
    // =========================================================================
    watch(() => banner.flight_ticket.design, (newDesktop) => {
        if (banner.type !== 'flight-ticket') return;

        const rootGlobal = [
            'layerOrder', 'backgroundType', 'bgColor', 'gradientAngle', 'gradientStops', 
            'imageUrl', 'enableCustomImageSize'
        ];
        const rootResponsive = [
            'ticketLayout', 'minHeight', 'borderRadius', 'padding', 
            'imageWidth', 'imageWidthUnit', 'imageHeight', 'imageHeightUnit', 
            'imagePosLeft', 'imagePosBottom', 'contentWidth', 'contentWidthUnit'
        ];
        
        syncFields(newDesktop, banner.flight_ticket.design_mobile, defaults.flight.desktop, defaults.flight.mobile, rootGlobal);
        
        if(!banner.flight_ticket.isMobileConfigured) {
            syncFields(newDesktop, banner.flight_ticket.design_mobile, defaults.flight.desktop, defaults.flight.mobile, rootResponsive);
        }

        const subObjects = ['content1', 'content2', 'content3', 'price', 'button', 'fromCity', 'toCity'];
        subObjects.forEach(obj => {
             const allKeys = Object.keys(defaults.flight.desktop[obj]);
             const globalSub = allKeys.filter(k => 
                k.toLowerCase().includes('text') || 
                k.toLowerCase().includes('color') || 
                k.toLowerCase().includes('weight')
            ).filter(k => !k.includes('Size'));

             const responsiveSub = allKeys.filter(k => !globalSub.includes(k));
             
             syncFields(newDesktop[obj], banner.flight_ticket.design_mobile[obj], defaults.flight.desktop[obj], defaults.flight.mobile[obj], globalSub);
             
             if(!banner.flight_ticket.isMobileConfigured) {
                 syncFields(newDesktop[obj], banner.flight_ticket.design_mobile[obj], defaults.flight.desktop[obj], defaults.flight.mobile[obj], responsiveSub);
             }
        });

    }, { deep: true });


    // =========================================================================
    // 10. Lock Logic (قفل کردن سینک هنگام تغییر دستی در موبایل)
    // =========================================================================
    
    // اگر کاربر در نمای موبایل، دیتای موبایل را تغییر دهد، فلگ isMobileConfigured روشن می‌شود.
    // این یعنی "من موبایل را دستی تنظیم کردم، لطفا از دسکتاپ کپی نکن".

    // گروه ۱: بنرهایی که از banner.isMobileConfigured استفاده می‌کنند
    watch([
        () => banner.single_mobile,
        () => banner.simple_mobile,
        () => banner.sticky_simple_mobile,
        () => banner.promotion_mobile
    ], () => {
        if (currentView.value === 'mobile') {
            banner.isMobileConfigured = true;
        }
    }, { deep: true });

    // گروه ۲: بنر دوبل
    watch(() => banner.double.mobile, () => {
        if (currentView.value === 'mobile') {
            banner.double.isMobileConfigured = true;
        }
    }, { deep: true });

    // گروه ۳: API Banner
    watch(() => banner.api.design_mobile, () => {
        if (currentView.value === 'mobile') {
            banner.api.isMobileConfigured = true;
        }
    }, { deep: true });

    // گروه ۴: Tour Carousel
    watch(() => banner.tour_carousel.settings_mobile, () => {
        if (currentView.value === 'mobile') {
            banner.tour_carousel.isMobileConfigured = true;
        }
    }, { deep: true });

    // گروه ۵: Hotel Carousel
    watch(() => banner.hotel_carousel.settings_mobile, () => {
        if (currentView.value === 'mobile') {
            banner.hotel_carousel.isMobileConfigured = true;
        }
    }, { deep: true });

    // گروه ۶: Flight Ticket
    watch(() => banner.flight_ticket.design_mobile, () => {
        if (currentView.value === 'mobile') {
            banner.flight_ticket.isMobileConfigured = true;
        }
    }, { deep: true });

}