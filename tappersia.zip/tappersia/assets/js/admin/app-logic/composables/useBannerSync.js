const { watch } = Vue;

import { 
    createDefaultPart, createDefaultMobilePart ,
    createDefaultHotelCarouselMobilePart,createDefaultTourCarouselMobilePart,
    createDefaultSimplePart, createDefaultSimpleBannerMobilePart,
    createDefaultStickySimplePart, createDefaultStickySimpleMobilePart,
    createDefaultDoubleBannerPart, createDefaultDoubleBannerMobilePart,
    createDefaultApiDesign, createDefaultApiMobileDesign 
} from '../../composables/banner-state/defaults/index.js';

export function useBannerSync(banner, currentView) {
    
    const singleDesktopDefaults = createDefaultPart();
    const singleMobileDefaults = createDefaultMobilePart();
    const simpleDesktopDefaults = createDefaultSimplePart();
    const simpleMobileDefaults = createDefaultSimpleBannerMobilePart();
    const stickyDesktopDefaults = createDefaultStickySimplePart();
    const stickyMobileDefaults = createDefaultStickySimpleMobilePart();
    const doubleDesktopDefaults = createDefaultDoubleBannerPart();
    const doubleMobileDefaults = createDefaultDoubleBannerMobilePart();
    const apiDesktopDefaults = createDefaultApiDesign();
    const apiMobileDefaults = createDefaultApiMobileDesign();

    watch(currentView, (newView) => {
        
        if (banner.type === 'simple-banner' && newView === 'mobile' && !banner.isMobileConfigured) {
            banner.isMobileConfigured = true;
            
            const desktop = banner.simple;
            const mobile = banner.simple_mobile;
            const propertiesToSync = [
                'backgroundType', 'bgColor', 'gradientAngle', 'gradientStops', 'text', 'textColor', 'textWeight',
                'buttonText', 'buttonLink', 'buttonBgColor', 'buttonTextColor', 'buttonBgHoverColor', 'buttonFontWeight',
                'enableBorder', 'borderColor', 'direction'
            ];
            
            for (const prop of propertiesToSync) {
                const desktopVal = desktop[prop];
                const desktopDefault = simpleDesktopDefaults[prop];
                
                let isDesktopDefault;
                if (typeof desktopVal === 'object' && desktopVal !== null) {
                    isDesktopDefault = JSON.stringify(desktopVal) === JSON.stringify(desktopDefault);
                } else {
                    isDesktopDefault = desktopVal === desktopDefault;
                }

                if (!isDesktopDefault) {
                    if (typeof desktopVal === 'object' && desktopVal !== null) {
                        mobile[prop] = JSON.parse(JSON.stringify(desktopVal));
                    } else {
                        mobile[prop] = desktopVal;
                    }
                }
            }
        }
        
         if (banner.type === 'sticky-simple-banner' && newView === 'mobile' && !banner.isMobileConfigured) {
            banner.isMobileConfigured = true;
            
            const desktop = banner.sticky_simple;
            const mobile = banner.sticky_simple_mobile;
            const propertiesToSync = [
                'backgroundType', 'bgColor', 'gradientAngle', 'gradientStops', 'text', 'textColor', 'textWeight',
                'buttonText', 'buttonLink', 'buttonBgColor', 'buttonTextColor', 'buttonBgHoverColor', 'buttonFontWeight',
                'enableBorder', 'borderColor', 'direction'
            ];
            
            for (const prop of propertiesToSync) {
                const desktopVal = desktop[prop];
                const desktopDefault = stickyDesktopDefaults[prop]; 
                
                let isDesktopDefault;
                if (typeof desktopVal === 'object' && desktopVal !== null) {
                    isDesktopDefault = JSON.stringify(desktopVal) === JSON.stringify(desktopDefault);
                } else {
                    isDesktopDefault = desktopVal === desktopDefault;
                }

                if (!isDesktopDefault) {
                    if (typeof desktopVal === 'object' && desktopVal !== null) {
                        mobile[prop] = JSON.parse(JSON.stringify(desktopVal));
                    } else {
                        mobile[prop] = desktopVal;
                    }
                }
            }
         }
         
        if (banner.type === 'single-banner' && newView === 'mobile' && !banner.isMobileConfigured) {
            banner.isMobileConfigured = true;
            const desktop = banner.single;
            const mobile = banner.single_mobile;
            const propertiesToSync = [
                'backgroundType', 'bgColor', 'gradientAngle', 'gradientStops',
                'titleWeight', 'descWeight',
                'buttonMarginTopAuto', 'buttonMarginTop', 'buttonMarginBottom',
                'titleMarginTop', 'descMarginTop', 'descMarginBottom'
            ];
            for (const prop of propertiesToSync) {
                const desktopVal = desktop[prop];
                const desktopDefault = singleDesktopDefaults[prop];
                let isDesktopDefault;
                if (typeof desktopVal === 'object' && desktopVal !== null) {
                    isDesktopDefault = JSON.stringify(desktopVal) === JSON.stringify(desktopDefault);
                } else {
                    isDesktopDefault = desktopVal === desktopDefault;
                }
                if (!isDesktopDefault) {
                    if (typeof desktopVal === 'object' && desktopVal !== null) {
                        mobile[prop] = JSON.parse(JSON.stringify(desktopVal));
                    } else {
                        mobile[prop] = desktopVal;
                    }
                }
            }
        }
        if (banner.type === 'promotion-banner' && newView === 'mobile' && !banner.isMobileConfigured) {
            banner.promotion_mobile = JSON.parse(JSON.stringify(banner.promotion));
            banner.promotion_mobile.headerPaddingX = 15; banner.promotion_mobile.headerPaddingY = 10; banner.promotion_mobile.headerFontSize = 14;
            banner.promotion_mobile.iconSize = 24; banner.promotion_mobile.bodyPaddingX = 15; banner.promotion_mobile.bodyPaddingY = 15;
            banner.promotion_mobile.bodyFontSize = 12; banner.promotion_mobile.bodyLineHeight = '22px';
            banner.isMobileConfigured = true;
        }

        if (banner.type === 'double-banner' && newView === 'mobile' && !banner.double.isMobileConfigured) {
            banner.double.mobile.left = JSON.parse(JSON.stringify(banner.double.desktop.left));
            banner.double.mobile.right = JSON.parse(JSON.stringify(banner.double.desktop.right));
            
            ['left', 'right'].forEach(pos => {
                const mob = banner.double.mobile[pos];
                mob.minHeight = 150; mob.paddingY = 20; mob.paddingX = 20;
                mob.titleSize = 14; 
                mob.titleMarginTop = 0;
                mob.descSize = 12; mob.marginTopDescription = 8;
                mob.descMarginBottom = 0;
                mob.contentWidth = 100; mob.contentWidthUnit = '%';
                mob.buttonFontSize = 11; 
                mob.buttonMarginBottom = 0;
                mob.buttonPaddingY = 10; mob.buttonPaddingX = 16;
            });

            banner.double.isMobileConfigured = true;
        }

        if (banner.type === 'api-banner' && newView === 'mobile' && !banner.api.isMobileConfigured) {
            banner.api.design_mobile = JSON.parse(JSON.stringify(banner.api.design));
            banner.api.design_mobile.minHeight = 80; banner.api.design_mobile.imageContainerWidth = 140; banner.api.design_mobile.imageContainerWidthUnit = 'px';
            banner.api.design_mobile.paddingY = 12; banner.api.design_mobile.paddingX = 20;
            delete banner.api.design_mobile.paddingTop; delete banner.api.design_mobile.paddingBottom; delete banner.api.design_mobile.paddingLeft; delete banner.api.design_mobile.paddingRight;
            banner.api.design_mobile.titleSize = 16; banner.api.design_mobile.starSize = 11; banner.api.design_mobile.citySize = 11;
            banner.api.design_mobile.subHeaderMarginTop = 4;
            banner.api.design_mobile.ratingBoxSize = 10; banner.api.design_mobile.ratingTextSize = 10; banner.api.design_mobile.reviewSize = 8;
            banner.api.design_mobile.priceAmountSize = 12; banner.api.design_mobile.priceFromSize = 9;
            banner.api.isMobileConfigured = true;
        }
        if (banner.type === 'tour-carousel' && newView === 'mobile' && !banner.tour_carousel.isMobileConfigured) {
            const desktop = banner.tour_carousel.settings; const mobile = banner.tour_carousel.settings_mobile;
            const mobileDefaultCardWidth = createDefaultTourCarouselMobilePart().cardWidth;
            const desktopSettingsCopy = JSON.parse(JSON.stringify(desktop));
            Object.assign(mobile, desktopSettingsCopy);
            mobile.slidesPerView = 1; mobile.spaceBetween = 15; mobile.cardWidth = mobileDefaultCardWidth;
            mobile.card.height = 375; mobile.card.padding = 9; mobile.card.borderRadius = 14;
            mobile.card.borderWidth = 1; mobile.card.imageHeight = 204;
            banner.tour_carousel.isMobileConfigured = true;
        }
        if (banner.type === 'hotel-carousel' && newView === 'mobile' && !banner.hotel_carousel.isMobileConfigured) {
            const desktop = banner.hotel_carousel.settings; const mobile = banner.hotel_carousel.settings_mobile;
            const mobileDefaultCardWidth = createDefaultHotelCarouselMobilePart().cardWidth;
            const desktopSettingsCopy = JSON.parse(JSON.stringify(desktop));
            Object.assign(mobile, desktopSettingsCopy);
            mobile.slidesPerView = 1; mobile.spaceBetween = 15; mobile.cardWidth = mobileDefaultCardWidth;
            mobile.card.minHeight = desktop.card.minHeight; mobile.card.padding = desktop.card.padding;
            mobile.card.borderRadius = desktop.card.borderRadius; mobile.card.borderWidth = desktop.card.borderWidth;
            mobile.card.image.height = desktop.card.image.height; mobile.card.image.radius = desktop.card.image.radius;
            banner.hotel_carousel.isMobileConfigured = true;
        }
        if (banner.type === 'flight-ticket' && newView === 'mobile' && !banner.flight_ticket.isMobileConfigured) {
            const desktop = banner.flight_ticket.design; const mobile = banner.flight_ticket.design_mobile;
            mobile.layerOrder = desktop.layerOrder; mobile.backgroundType = desktop.backgroundType; mobile.bgColor = desktop.bgColor;
            mobile.gradientAngle = desktop.gradientAngle; mobile.gradientStops = JSON.parse(JSON.stringify(desktop.gradientStops));
            mobile.imageUrl = desktop.imageUrl;
            
            mobile.content1.text = desktop.content1.text; mobile.content1.color = desktop.content1.color;
            mobile.content2.text = desktop.content2.text; mobile.content2.color = desktop.content2.color;
            mobile.content3.text = desktop.content3.text; mobile.content3.color = desktop.content3.color;
            
            mobile.content1.marginTop = desktop.content1.marginTop;
            mobile.content2.marginTop = desktop.content2.marginTop;
            mobile.content2.marginBottom = desktop.content2.marginBottom;
            mobile.content3.marginBottom = desktop.content3.marginBottom;

            mobile.price.color = desktop.price.color; mobile.button.bgColor = desktop.button.bgColor;
            mobile.button.BgHoverColor = desktop.button.BgHoverColor; mobile.button.color = desktop.button.color;
            mobile.fromCity.color = desktop.fromCity.color; mobile.toCity.color = desktop.toCity.color;
            banner.flight_ticket.isMobileConfigured = true;
        }

    });

    const runContinuousSyncDebug = (bannerType, mobileState, mobileDefaults, desktopDefaults, newDesktop, oldDesktop, propertiesToSync) => {
        
        for (const propName of propertiesToSync) {
            const newDeskVal = newDesktop[propName];
            const oldDeskVal = oldDesktop ? oldDesktop[propName] : undefined;
    
            let deskValChanged;
            if (typeof newDeskVal === 'object' && newDeskVal !== null) {
                deskValChanged = JSON.stringify(newDeskVal) !== JSON.stringify(oldDeskVal);
            } else {
                deskValChanged = newDeskVal !== oldDeskVal;
            }
    
            if (!deskValChanged) continue;
    
            const mobileVal = mobileState[propName];
            const mobileDefaultVal = mobileDefaults[propName];
            const desktopDefaultVal = desktopDefaults[propName];
    
            let isMobileLikeOldDesktop;
            let isMobileLikeDefault;
    
            if (typeof mobileVal === 'object' && mobileVal !== null) {
                isMobileLikeOldDesktop = JSON.stringify(mobileVal) === JSON.stringify(oldDeskVal);
                isMobileLikeDefault = JSON.stringify(mobileVal) === JSON.stringify(mobileDefaultVal);
            } else {
                isMobileLikeOldDesktop = mobileVal === oldDeskVal;
                isMobileLikeDefault = mobileVal === mobileDefaultVal;
            }
    
            const isMobileManuallyEdited = !isMobileLikeOldDesktop && !isMobileLikeDefault;
    
            if (isMobileManuallyEdited) continue;

            let isNewDesktopDefault;
            if (typeof newDeskVal === 'object' && newDeskVal !== null) {
                isNewDesktopDefault = JSON.stringify(newDeskVal) === JSON.stringify(desktopDefaultVal);
            } else {
                isNewDesktopDefault = newDeskVal === desktopDefaultVal;
            }

            if (isNewDesktopDefault) {
                if (typeof mobileDefaultVal === 'object' && mobileDefaultVal !== null) {
                    mobileState[propName] = JSON.parse(JSON.stringify(mobileDefaultVal));
                } else {
                    mobileState[propName] = mobileDefaultVal;
                }
            } else {
                if (typeof newDeskVal === 'object' && newDeskVal !== null) {
                    mobileState[propName] = JSON.parse(JSON.stringify(newDeskVal));
                } else {
                    mobileState[propName] = newDeskVal;
                }
            }
        }
    };

    watch(() => (banner.value && banner.value.type === 'single-banner') ? banner.value.single : null, (newDesktop, oldDesktop) => {
        if (!newDesktop || !oldDesktop) return;
        if (!banner.value || banner.value.type !== 'single-banner') return; 
        
        const propertiesToSync = [
            'backgroundType', 'bgColor', 'gradientAngle', 'gradientStops',
            'titleWeight', 'descWeight',
            'buttonMarginTopAuto', 'buttonMarginTop', 'buttonMarginBottom',
            'titleMarginTop', 'descMarginTop', 'descMarginBottom'
        ];
        
        runContinuousSyncDebug(
            'single-banner',
            banner.value.single_mobile,
            singleMobileDefaults,
            singleDesktopDefaults,
            newDesktop,
            oldDesktop,
            propertiesToSync
        );

    }, { deep: true });

    watch(() => banner.simple, (newDesktop, oldDesktop) => {
        if (banner.type !== 'simple-banner') return;
        const propertiesToSync = [
            'backgroundType', 'bgColor', 'gradientAngle', 'gradientStops',
            'text', 'textColor', 'textWeight',
            'buttonText', 'buttonLink', 'buttonBgColor', 'buttonTextColor', 'buttonBgHoverColor', 'buttonFontWeight',
            'enableBorder', 'borderColor', 'direction'
        ];
         runContinuousSyncDebug('simple-banner', banner.simple_mobile, simpleMobileDefaults,simpleDesktopDefaults, newDesktop, oldDesktop, propertiesToSync);
     }, { deep: true });

    watch(() => banner.sticky_simple, (newDesktop, oldDesktop) => {
        if (banner.type !== 'sticky-simple-banner') return;
        const propertiesToSync = [
            'backgroundType', 'bgColor', 'gradientAngle', 'gradientStops',
            'text', 'textColor', 'textWeight',
            'buttonText', 'buttonLink', 'buttonBgColor', 'buttonTextColor', 'buttonBgHoverColor', 'buttonFontWeight',
            'enableBorder', 'borderColor', 'direction'
        ];
        runContinuousSyncDebug('sticky-simple-banner', banner.sticky_simple_mobile, stickyMobileDefaults, stickyDesktopDefaults,newDesktop, oldDesktop, propertiesToSync);
     }, { deep: true });

     watch(() => banner.promotion, (newDesktop) => {
        if (banner.type !== 'promotion-banner' || !banner.isMobileConfigured) return;
        const mobile = banner.promotion_mobile;
         mobile.direction = newDesktop.direction; mobile.headerText = newDesktop.headerText; mobile.headerTextColor = newDesktop.headerTextColor;
         mobile.bodyText = newDesktop.bodyText; mobile.bodyTextColor = newDesktop.bodyTextColor;
         mobile.links = JSON.parse(JSON.stringify(newDesktop.links));
         mobile.borderColor = newDesktop.borderColor; mobile.iconUrl = newDesktop.iconUrl; mobile.enableBorder = newDesktop.enableBorder;
     }, { deep: true });
    
    watch(() => banner.double.desktop, (newDesktop, oldDesktop) => {
        if (banner.type !== 'double-banner') return; 
        
        const propertiesToSync = [
            'imageUrl', 'layerOrder', 
            'backgroundType', 'bgColor', 'gradientAngle', 'gradientStops',
            'enableBorder', 'borderColor', 'borderWidth', 'borderRadius',
            'titleText', 'titleColor', 'titleWeight', 'titleSize', 
            'titleMarginTop', 
            'descText', 'descColor', 'descWeight', 'descSize', 
            'marginTopDescription', 'descMarginBottom', 
            'buttonText', 'buttonLink', 'buttonBgColor', 'buttonTextColor', 'buttonBgHoverColor',
            'buttonFontWeight', 'buttonFontSize', 'buttonBorderRadius',
            'buttonPaddingY', 'buttonPaddingX', 'buttonMarginBottom',
            'alignment', 'enableCustomImageSize', 
            'imageWidth', 'imageWidthUnit', 'imageHeight', 'imageHeightUnit', 
            'imagePosRight', 'imagePosBottom'
        ];

        ['left', 'right'].forEach(position => {
            const oldDeskPos = oldDesktop && oldDesktop[position] ? oldDesktop[position] : undefined;
            if (!oldDeskPos) return;

            runContinuousSyncDebug(
                'double-banner',
                banner.double.mobile[position], 
                doubleMobileDefaults,          
                doubleDesktopDefaults,          
                newDesktop[position],           
                oldDeskPos,                     
                propertiesToSync
            );
         });
    }, { deep: true });

    watch(() => banner.tour_carousel.settings, (newDesktopSettings) => {
        if (banner.type !== 'tour-carousel' || !banner.tour_carousel.isMobileConfigured) return;
        const mobile = banner.tour_carousel.settings_mobile;
        mobile.direction = newDesktopSettings.direction; mobile.autoplay = JSON.parse(JSON.stringify(newDesktopSettings.autoplay));
        mobile.header.text = newDesktopSettings.header.text; mobile.header.color = newDesktopSettings.header.color; mobile.header.lineColor = newDesktopSettings.header.lineColor;
        mobile.card.backgroundType = newDesktopSettings.card.backgroundType; mobile.card.bgColor = newDesktopSettings.card.bgColor;
        mobile.card.gradientAngle = newDesktopSettings.card.gradientAngle; mobile.card.gradientStops = JSON.parse(JSON.stringify(newDesktopSettings.card.gradientStops));
        mobile.card.borderColor = newDesktopSettings.card.borderColor; mobile.card.province.color = newDesktopSettings.card.province.color;
        mobile.card.province.bgColor = newDesktopSettings.card.province.bgColor; mobile.card.title.color = newDesktopSettings.card.title.color;
        mobile.card.price.color = newDesktopSettings.card.price.color; mobile.card.duration.color = newDesktopSettings.card.duration.color;
        mobile.card.rating.color = newDesktopSettings.card.rating.color; mobile.card.reviews.color = newDesktopSettings.card.reviews.color;
        mobile.card.button.color = newDesktopSettings.card.button.color; mobile.card.button.bgColor = newDesktopSettings.card.button.bgColor;
        mobile.card.button.BgHoverColor = newDesktopSettings.card.button.BgHoverColor;
    }, { deep: true });
    watch(() => banner.hotel_carousel.settings, (newDesktopSettings) => {
        if (banner.type !== 'hotel-carousel' || !banner.hotel_carousel.isMobileConfigured) return;
        const mobile = banner.hotel_carousel.settings_mobile;
        mobile.direction = newDesktopSettings.direction; mobile.autoplay = JSON.parse(JSON.stringify(newDesktopSettings.autoplay));
        mobile.header.text = newDesktopSettings.header.text; mobile.header.color = newDesktopSettings.header.color; mobile.header.lineColor = newDesktopSettings.header.lineColor;
        mobile.card.bgColor = newDesktopSettings.card.bgColor; mobile.card.borderColor = newDesktopSettings.card.borderColor;
        mobile.card.imageOverlay.gradientStartColor = newDesktopSettings.card.imageOverlay.gradientStartColor; mobile.card.imageOverlay.gradientEndColor = newDesktopSettings.card.imageOverlay.gradientEndColor;
        mobile.card.badges.bestSeller.textColor = newDesktopSettings.card.badges.bestSeller.textColor; mobile.card.badges.bestSeller.bgColor = newDesktopSettings.card.badges.bestSeller.bgColor;
        mobile.card.badges.discount.textColor = newDesktopSettings.card.badges.discount.textColor; mobile.card.badges.discount.bgColor = newDesktopSettings.card.badges.discount.bgColor;
        mobile.card.stars.shapeColor = newDesktopSettings.card.stars.shapeColor; mobile.card.stars.textColor = newDesktopSettings.card.stars.textColor;
        mobile.card.bodyContent.textColor = newDesktopSettings.card.bodyContent.textColor; mobile.card.title.color = newDesktopSettings.card.title.color;
        mobile.card.rating.boxBgColor = newDesktopSettings.card.rating.boxBgColor; mobile.card.rating.boxColor = newDesktopSettings.card.rating.boxColor;
        mobile.card.rating.labelColor = newDesktopSettings.card.rating.labelColor; mobile.card.rating.countColor = newDesktopSettings.card.rating.countColor;
        mobile.card.divider.color = newDesktopSettings.card.divider.color; mobile.card.price.fromColor = newDesktopSettings.card.price.fromColor;
        mobile.card.price.amountColor = newDesktopSettings.card.price.amountColor; mobile.card.price.nightColor = newDesktopSettings.card.price.nightColor;
        mobile.card.price.originalColor = newDesktopSettings.card.price.originalColor;
    }, { deep: true });
    
    watch(() => banner.flight_ticket.design, (newDesktopSettings) => {
        if (banner.type !== 'flight-ticket' || !banner.isMobileConfigured) return;
        const mobile = banner.flight_ticket.design_mobile;
        
        mobile.layerOrder = newDesktopSettings.layerOrder; 
        mobile.backgroundType = newDesktopSettings.backgroundType; 
        mobile.bgColor = newDesktopSettings.bgColor;
        
        if (newDesktopSettings.gradientStops && Array.isArray(newDesktopSettings.gradientStops)) {
            const newMobileStops = [];
            newDesktopSettings.gradientStops.forEach((desktopStop, index) => {
                const existingMobileStop = (mobile.gradientStops && mobile.gradientStops[index]) ? mobile.gradientStops[index] : null;
                newMobileStops.push({
                    color: desktopStop.color,
                    stop: existingMobileStop ? existingMobileStop.stop : desktopStop.stop
                });
            });
            mobile.gradientStops = newMobileStops;
        }
        mobile.imageUrl = newDesktopSettings.imageUrl;
        
        mobile.content1.text = newDesktopSettings.content1.text; 
        mobile.content1.color = newDesktopSettings.content1.color;
        mobile.content1.marginTop = newDesktopSettings.content1.marginTop;

        mobile.content2.text = newDesktopSettings.content2.text; 
        mobile.content2.color = newDesktopSettings.content2.color;
        mobile.content2.marginTop = newDesktopSettings.content2.marginTop;
        mobile.content2.marginBottom = newDesktopSettings.content2.marginBottom;

        mobile.content3.text = newDesktopSettings.content3.text; 
        mobile.content3.color = newDesktopSettings.content3.color;
        mobile.content3.marginBottom = newDesktopSettings.content3.marginBottom;

        mobile.price.color = newDesktopSettings.price.color; 
        mobile.button.bgColor = newDesktopSettings.button.bgColor;
        mobile.button.BgHoverColor = newDesktopSettings.button.BgHoverColor; 
        mobile.button.color = newDesktopSettings.button.color;
        mobile.fromCity.color = newDesktopSettings.fromCity.color; 
        mobile.toCity.color = newDesktopSettings.toCity.color;
    }, { deep: true });

    watch(() => (banner.value && banner.value.type === 'api-banner') ? banner.value.api.design : null, (newDesktop, oldDesktop) => {
        if (!newDesktop || !oldDesktop) return;
        if (!banner.value || banner.value.type !== 'api-banner' || !banner.value.api.isMobileConfigured) return;

        const propertiesToSync = [
            'width', 'widthUnit', 'minHeight', 'imageContainerWidth', 'imageContainerWidthUnit',
            'layout', 'backgroundType', 'bgColor', 'gradientAngle', 'gradientStops',
            'enableBorder', 'borderWidth', 'borderColor', 'borderRadius',
            'paddingY', 'paddingX',
            'titleColor', 'titleSize', 'titleWeight',
            'titleMarginTop', 
            'subHeaderMarginTop', 'subHeaderMarginBottom', 
            'bottomSectionMarginBottom',
            'starSize', 'cityColor', 'citySize',
            'ratingBoxBgColor', 'ratingBoxColor', 'ratingBoxSize', 'ratingBoxWeight',
            'ratingTextColor', 'ratingTextSize', 'ratingTextWeight',
            'reviewColor', 'reviewSize',
            'priceFromColor', 'priceFromSize', 'priceAmountColor', 'priceAmountSize', 'priceAmountWeight',
            'priceNightColor', 'priceNightSize'
        ];

        runContinuousSyncDebug(
            'api-banner',
            banner.value.api.design_mobile,
            apiMobileDefaults,
            apiDesktopDefaults,
            newDesktop,
            oldDesktop,
            propertiesToSync
        );
    }, { deep: true });
}
