const { watch } = Vue;

import { 
    createDefaultPart, createDefaultMobilePart,
    createDefaultHotelCarouselDesktopPart, createDefaultHotelCarouselMobilePart,
    createDefaultTourCarouselDesktopPart, createDefaultTourCarouselMobilePart,
    createDefaultSimplePart, createDefaultSimpleBannerMobilePart,
    createDefaultStickySimplePart, createDefaultStickySimpleMobilePart,
    createDefaultDoubleBannerPart, createDefaultDoubleBannerMobilePart,
    createDefaultApiDesign, createDefaultApiMobileDesign,
    createDefaultPromotionPart, createDefaultPromotionMobilePart,
    createDefaultFlightTicketPart, createDefaultFlightTicketMobilePart
} from '../../composables/banner-state/defaults/index.js';

export function useBannerSync(banner, currentView) {

    const defaults = {
        single: { 
            desktop: createDefaultPart(), 
            mobile: createDefaultMobilePart() 
        },
        simple: { 
            desktop: createDefaultSimplePart(), 
            mobile: createDefaultSimpleBannerMobilePart() 
        },
        sticky: { 
            desktop: createDefaultStickySimplePart(), 
            mobile: createDefaultStickySimpleMobilePart() 
        },
        double: { 
            desktop: createDefaultDoubleBannerPart(), 
            mobile: createDefaultDoubleBannerMobilePart() 
        },
        promotion: {
            desktop: createDefaultPromotionPart(),
            mobile: createDefaultPromotionMobilePart()
        },
        api: { 
            desktop: createDefaultApiDesign(), 
            mobile: createDefaultApiMobileDesign() 
        },
        tour: { 
            desktop: createDefaultTourCarouselDesktopPart(), 
            mobile: createDefaultTourCarouselMobilePart() 
        },
        hotel: { 
            desktop: createDefaultHotelCarouselDesktopPart(), 
            mobile: createDefaultHotelCarouselMobilePart() 
        },
        flight: { 
            desktop: createDefaultFlightTicketPart().design, 
            mobile: createDefaultFlightTicketMobilePart().design 
        }
    };


    const syncFields = (desktopState, mobileState, desktopDefs, mobileDefs, fields) => {
        fields.forEach(key => {
            if (desktopState[key] === undefined || desktopDefs[key] === undefined) return;

            const currentDesktopVal = desktopState[key];
            const defaultDesktopVal = desktopDefs[key];

            const isModified = JSON.stringify(currentDesktopVal) !== JSON.stringify(defaultDesktopVal);

            if (isModified) {
                mobileState[key] = JSON.parse(JSON.stringify(currentDesktopVal));
            } else {

                mobileState[key] = JSON.parse(JSON.stringify(mobileDefs[key]));
            }
        });
    };

    watch(() => banner.single, (newDesktop) => {
        if (banner.type !== 'single-banner' || banner.isMobileConfigured) return;

        const fields = [
            'backgroundType', 'bgColor', 'gradientAngle', 'gradientStops',
            'titleText', 'titleColor', 'titleWeight', 'titleSize', 'titleMarginTop',
            'descText', 'descColor', 'descSize', 'descWeight', 'descMarginTop', 'descMarginBottom',
            'buttonText', 'buttonLink', 'buttonBgColor', 'buttonTextColor', 'buttonBgHoverColor',
            'buttonFontSize', 'buttonFontWeight', 'buttonBorderRadius', 
            'buttonPaddingY', 'buttonPaddingX', 'buttonMarginTopAuto', 'buttonMarginTop', 'buttonMarginBottom',
            'imageUrl', 'enableCustomImageSize', 'imageWidth', 'imageWidthUnit', 'imageHeight', 'imageHeightUnit',
            'imagePosRight', 'imagePosBottom', 'imagePosLeft',
            'enableBorder', 'borderWidth', 'borderColor', 'borderRadius', 'layerOrder', 'alignment'
        ];

        syncFields(newDesktop, banner.single_mobile, defaults.single.desktop, defaults.single.mobile, fields);
    }, { deep: true });


    watch(() => banner.simple, (newDesktop) => {
        if (banner.type !== 'simple-banner' || banner.isMobileConfigured) return;

        const fields = [
            'backgroundType', 'bgColor', 'gradientAngle', 'gradientStops', 
            'text', 'textColor', 'textSize', 'textWeight',
            'buttonText', 'buttonLink', 'buttonBgColor', 'buttonTextColor', 'buttonBgHoverColor', 
            'buttonFontWeight', 'buttonFontSize', 'buttonBorderRadius', 'buttonPaddingY', 'buttonPaddingX', 'buttonMinWidth',
            'enableBorder', 'borderColor', 'borderWidth', 'borderRadius', 'direction',
            'minHeight', 'contentWidth', 'contentWidthUnit', 'paddingY', 'paddingX', 'paddingXUnit'
        ];

        syncFields(newDesktop, banner.simple_mobile, defaults.simple.desktop, defaults.simple.mobile, fields);
    }, { deep: true });


    watch(() => banner.sticky_simple, (newDesktop) => {
        if (banner.type !== 'sticky-simple-banner' || banner.isMobileConfigured) return;

        const fields = [
            'backgroundType', 'bgColor', 'gradientAngle', 'gradientStops', 
            'text', 'textColor', 'textSize', 'textWeight',
            'buttonText', 'buttonLink', 'buttonBgColor', 'buttonTextColor', 'buttonBgHoverColor', 
            'buttonFontWeight', 'buttonFontSize', 'buttonBorderRadius', 'buttonPaddingY', 'buttonPaddingX', 'buttonMinWidth',
            'enableBorder', 'borderColor', 'borderWidth', 'borderRadius', 'direction',
            'minHeight', 'contentWidth', 'contentWidthUnit', 'paddingY', 'paddingX', 'paddingXUnit'
        ];

        syncFields(newDesktop, banner.sticky_simple_mobile, defaults.sticky.desktop, defaults.sticky.mobile, fields);
    }, { deep: true });


    watch(() => banner.promotion, (newDesktop) => {
        if (banner.type !== 'promotion-banner' || banner.isMobileConfigured) return;

        const fields = [
            'enableBorder', 'borderWidth', 'borderColor', 'borderRadius', 'direction',
            'headerBackgroundType', 'headerBgColor', 'headerGradientAngle', 'headerGradientStops',
            'iconUrl', 'iconSize', 'headerPaddingX', 'headerPaddingY',
            'headerText', 'headerTextColor', 'headerFontSize', 'headerFontWeight',
            'bodyBackgroundType', 'bodyBgColor', 'bodyGradientAngle', 'bodyGradientStops',
            'bodyPaddingX', 'bodyPaddingY', 'bodyText', 'bodyTextColor', 'bodyFontSize', 'bodyFontWeight', 'bodyLineHeight',
            'links'
        ];

        syncFields(newDesktop, banner.promotion_mobile, defaults.promotion.desktop, defaults.promotion.mobile, fields);
    }, { deep: true });


    watch(() => banner.double.desktop, (newDesktop) => {
        if (banner.type !== 'double-banner' || banner.double.isMobileConfigured) return;

        const fields = [
            'imageUrl', 'layerOrder', 'backgroundType', 'bgColor', 'gradientAngle', 'gradientStops',
            'enableBorder', 'borderColor', 'borderWidth', 'borderRadius',
            'titleText', 'titleColor', 'titleWeight', 'titleSize', 'titleMarginTop',
            'descText', 'descColor', 'descWeight', 'descSize', 'marginTopDescription', 'descMarginBottom',
            'buttonText', 'buttonLink', 'buttonBgColor', 'buttonTextColor', 'buttonBgHoverColor',
            'buttonFontWeight', 'buttonFontSize', 'buttonBorderRadius', 'buttonPaddingY', 'buttonPaddingX', 'buttonMarginBottom',
            'alignment', 'enableCustomImageSize', 'imageWidth', 'imageWidthUnit', 'imageHeight', 'imageHeightUnit', 
            'imagePosRight', 'imagePosBottom', 'paddingY', 'paddingX', 'minHeight', 'contentWidth', 'contentWidthUnit'
        ];

        ['left', 'right'].forEach(pos => {
            syncFields(newDesktop[pos], banner.double.mobile[pos], defaults.double.desktop, defaults.double.mobile, fields);
        });
    }, { deep: true });


    watch(() => banner.api.design, (newDesktop) => {
        if (banner.type !== 'api-banner' || banner.api.isMobileConfigured) return;

        const fields = [
            'width', 'widthUnit', 'minHeight', 'imageContainerWidth', 'imageContainerWidthUnit',
            'layout', 'backgroundType', 'bgColor', 'gradientAngle', 'gradientStops',
            'enableBorder', 'borderWidth', 'borderColor', 'borderRadius',
            'paddingY', 'paddingX',
            'titleColor', 'titleSize', 'titleWeight', 'titleMarginTop',
            'subHeaderMarginTop', 'subHeaderMarginBottom', 'bottomSectionMarginBottom',
            'starSize', 'cityColor', 'citySize',
            'ratingBoxBgColor', 'ratingBoxColor', 'ratingBoxSize', 'ratingBoxWeight',
            'ratingTextColor', 'ratingTextSize', 'ratingTextWeight', 'reviewColor', 'reviewSize',
            'priceFromColor', 'priceFromSize', 'priceAmountColor', 'priceAmountSize', 'priceAmountWeight',
            'priceNightColor', 'priceNightSize'
        ];

        syncFields(newDesktop, banner.api.design_mobile, defaults.api.desktop, defaults.api.mobile, fields);
    }, { deep: true });


    watch(() => banner.tour_carousel.settings, (newDesktop) => {
        if (banner.type !== 'tour-carousel' || banner.tour_carousel.isMobileConfigured) return;


        const topFields = ['slidesPerView', 'cardWidth', 'loop', 'spaceBetween', 'isDoubled', 'gridFill', 'direction'];
        syncFields(newDesktop, banner.tour_carousel.settings_mobile, defaults.tour.desktop, defaults.tour.mobile, topFields);


        syncFields(newDesktop.header, banner.tour_carousel.settings_mobile.header, defaults.tour.desktop.header, defaults.tour.mobile.header, ['text', 'fontSize', 'fontWeight', 'color', 'lineColor', 'marginTop']);


        const cardFields = ['height', 'backgroundType', 'bgColor', 'gradientAngle', 'borderWidth', 'borderColor', 'borderRadius', 'padding', 'imageHeight'];
        syncFields(newDesktop.card, banner.tour_carousel.settings_mobile.card, defaults.tour.desktop.card, defaults.tour.mobile.card, cardFields);
        

        if (JSON.stringify(newDesktop.card.gradientStops) !== JSON.stringify(defaults.tour.desktop.card.gradientStops)) {
            banner.tour_carousel.settings_mobile.card.gradientStops = JSON.parse(JSON.stringify(newDesktop.card.gradientStops));
        }


        const subObjects = ['province', 'title', 'infoRow', 'price', 'duration', 'rating', 'reviews', 'button'];
        subObjects.forEach(obj => {
            syncFields(newDesktop.card[obj], banner.tour_carousel.settings_mobile.card[obj], defaults.tour.desktop.card[obj], defaults.tour.mobile.card[obj], Object.keys(defaults.tour.desktop.card[obj]));
        });


        syncFields(newDesktop.autoplay, banner.tour_carousel.settings_mobile.autoplay, defaults.tour.desktop.autoplay, defaults.tour.mobile.autoplay, ['enabled', 'delay']);
        
    }, { deep: true });


    watch(() => banner.hotel_carousel.settings, (newDesktop) => {
        if (banner.type !== 'hotel-carousel' || banner.hotel_carousel.isMobileConfigured) return;

        const topFields = ['slidesPerView', 'cardWidth', 'loop', 'spaceBetween', 'isDoubled', 'gridFill', 'direction'];
        syncFields(newDesktop, banner.hotel_carousel.settings_mobile, defaults.hotel.desktop, defaults.hotel.mobile, topFields);


        syncFields(newDesktop.header, banner.hotel_carousel.settings_mobile.header, defaults.hotel.desktop.header, defaults.hotel.mobile.header, ['text', 'fontSize', 'fontWeight', 'color', 'lineColor', 'marginTop']);


        const cardFields = ['minHeight', 'padding', 'borderWidth', 'borderColor', 'borderRadius', 'bgColor'];
        syncFields(newDesktop.card, banner.hotel_carousel.settings_mobile.card, defaults.hotel.desktop.card, defaults.hotel.mobile.card, cardFields);


        const subObjects = ['image', 'imageContainer', 'imageOverlay', 'stars', 'bodyContent', 'title', 'rating', 'tags', 'divider', 'price'];
        subObjects.forEach(obj => {
             syncFields(newDesktop.card[obj], banner.hotel_carousel.settings_mobile.card[obj], defaults.hotel.desktop.card[obj], defaults.hotel.mobile.card[obj], Object.keys(defaults.hotel.desktop.card[obj]));
        });
        

        ['bestSeller', 'discount'].forEach(badge => {
             syncFields(newDesktop.card.badges[badge], banner.hotel_carousel.settings_mobile.card.badges[badge], defaults.hotel.desktop.card.badges[badge], defaults.hotel.mobile.card.badges[badge], Object.keys(defaults.hotel.desktop.card.badges[badge]));
        });

        syncFields(newDesktop.autoplay, banner.hotel_carousel.settings_mobile.autoplay, defaults.hotel.desktop.autoplay, defaults.hotel.mobile.autoplay, ['enabled', 'delay']);

    }, { deep: true });


    watch(() => banner.flight_ticket.design, (newDesktop) => {
        if (banner.type !== 'flight-ticket' || banner.flight_ticket.isMobileConfigured) return;

        const rootFields = [
            'ticketLayout', 'minHeight', 'borderRadius', 'padding', 'layerOrder', 
            'backgroundType', 'bgColor', 'gradientAngle', 'imageUrl', 
            'enableCustomImageSize', 'imageWidth', 'imageWidthUnit', 'imageHeight', 'imageHeightUnit', 
            'imagePosLeft', 'imagePosBottom', 'contentWidth', 'contentWidthUnit'
        ];
        syncFields(newDesktop, banner.flight_ticket.design_mobile, defaults.flight.desktop, defaults.flight.mobile, rootFields);


        if (JSON.stringify(newDesktop.gradientStops) !== JSON.stringify(defaults.flight.desktop.gradientStops)) {
            banner.flight_ticket.design_mobile.gradientStops = JSON.parse(JSON.stringify(newDesktop.gradientStops));
        }

        const subObjects = ['content1', 'content2', 'content3', 'price', 'button', 'fromCity', 'toCity'];
        subObjects.forEach(obj => {
            syncFields(newDesktop[obj], banner.flight_ticket.design_mobile[obj], defaults.flight.desktop[obj], defaults.flight.mobile[obj], Object.keys(defaults.flight.desktop[obj]));
        });

    }, { deep: true });

    watch(currentView, (newView) => {
        if (newView === 'mobile') {
            if (banner.type === 'single-banner' || banner.type === 'simple-banner' || banner.type === 'sticky-simple-banner' || banner.type === 'promotion-banner') {
                if (!banner.isMobileConfigured) banner.isMobileConfigured = true;
            } 
            else if (banner.type === 'double-banner') {
                if (!banner.double.isMobileConfigured) banner.double.isMobileConfigured = true;
            }
            else if (banner.type === 'api-banner') {
                if (!banner.api.isMobileConfigured) banner.api.isMobileConfigured = true;
            }
            else if (banner.type === 'tour-carousel') {
                if (!banner.tour_carousel.isMobileConfigured) banner.tour_carousel.isMobileConfigured = true;
            }
            else if (banner.type === 'hotel-carousel') {
                if (!banner.hotel_carousel.isMobileConfigured) banner.hotel_carousel.isMobileConfigured = true;
            }
            else if (banner.type === 'flight-ticket') {
                if (!banner.flight_ticket.isMobileConfigured) banner.flight_ticket.isMobileConfigured = true;
            }
        }
    });
}