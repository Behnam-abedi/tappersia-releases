const { ref, watch, onMounted } = Vue;

export function useHotelThumbnails(banner, ajax, thumbnailContainerRef) {
    const thumbnailHotels = ref([]);
    const isLoadingThumbnails = ref(false);
    let sortableInstance = null;

    const fetchThumbnailHotels = async () => {
        const ids = banner.hotel_carousel.selectedHotels;
        if (!ids || ids.length === 0) {
            thumbnailHotels.value = [];
            return;
        }

        isLoadingThumbnails.value = true;
        try {
            const hotelsData = await ajax.post('yab_fetch_hotel_details_by_ids', { hotel_ids: ids });
            thumbnailHotels.value = ids.map(id => hotelsData.find(h => h.id === id)).filter(Boolean);
        } catch (error) {
            console.error('Could not fetch hotel thumbnails:', error);
            thumbnailHotels.value = [];
        } finally {
            isLoadingThumbnails.value = false;
        }
    };

    const initSortable = () => {
        if (thumbnailContainerRef.value) {
            if (sortableInstance) {
                sortableInstance.destroy();
            }
            sortableInstance = new Sortable(thumbnailContainerRef.value, {
                animation: 150,
                ghostClass: 'yab-sortable-ghost',
                onEnd: (evt) => {
                    const newOrderIds = Array.from(evt.target.children).map(child => parseInt(child.dataset.id, 10));

                    if (JSON.stringify(banner.hotel_carousel.selectedHotels) !== JSON.stringify(newOrderIds)) {
                        banner.hotel_carousel.selectedHotels = newOrderIds;
                    }
                }
            });
        }
    };

    watch(() => banner.hotel_carousel.selectedHotels, () => {
        fetchThumbnailHotels();
    }, {
        immediate: true,
        deep: true
    });

    onMounted(() => {
        watch(thumbnailContainerRef, (newEl) => {
            if (newEl) {
                initSortable();
            }
        }, { immediate: true });
    });

    return {
        thumbnailHotels,
        isLoadingThumbnails
    };
}
