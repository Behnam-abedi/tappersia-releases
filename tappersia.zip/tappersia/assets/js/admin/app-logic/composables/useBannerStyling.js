import { bannerStyles, contentAlignment, imageStyleObject, getApiBannerStyles, getApiContentStyles } from '../utils.js';

export function useBannerStyling(banner) {
    const getBannerContainerStyles = (view) => {
        const settings = view === 'desktop' ? banner.single : banner.single_mobile;
        if (!settings) return {};
        return {
            width: '100%',
            height: 'auto',
            minHeight: `${settings.minHeight}px`,
            border: settings.enableBorder ? `${settings.borderWidth}px solid ${banner.single.borderColor}` : 'none',
            borderRadius: `${settings.borderRadius}px`,
            fontFamily: 'Roboto, sans-serif'
        };
    };
    
    const getDynamicStyles = (view) => {
        if (view === 'desktop') {
            const settings = banner.single;
            if (!settings) return {};
            return {
                contentStyles: {
                    alignItems: contentAlignment(settings.alignment),
                    textAlign: settings.alignment,
                    padding: `${settings.paddingY}px ${settings.paddingX}px`,
                    width: `${settings.contentWidth}${settings.contentWidthUnit}`,
                    minHeight: `${settings.minHeight}px`,
                    flexGrow: 1,
                    display: 'flex', 
                    flexDirection: 'column', 
                    zIndex: 3,
                    position: 'relative',
                    boxSizing: 'border-box'
                },
                titleStyles: {
                    color: settings.titleColor,
                    fontSize: `${settings.titleSize}px`,
                    fontWeight: settings.titleWeight,
                    lineHeight: 1,
                    margin: 0,
                    marginTop: `${settings.titleMarginTop ?? 0}px`
                },
                descriptionStyles: {
                    color: settings.descColor,
                    fontSize: `${settings.descSize}px`,
                    fontWeight: settings.descWeight,
                    whiteSpace: 'pre-wrap',
                    marginTop: `${settings.descMarginTop ?? settings.marginTopDescription ?? 12}px`,
                    marginBottom: `${settings.descMarginBottom ?? 0}px`,
                    lineHeight: 1.5,
                    wordWrap: 'break-word'
                },
                buttonStyles: {
                    backgroundColor: settings.buttonBgColor,
                    color: settings.buttonTextColor,
                    fontSize: `${settings.buttonFontSize}px`,
                    fontWeight: settings.buttonFontWeight,
                    alignSelf: settings.alignment === 'center' ? 'center' : (settings.alignment === 'right' ? 'flex-end' : 'flex-start'),
                    borderRadius: `${settings.buttonBorderRadius}px`,
                    padding: `${settings.buttonPaddingY}px ${settings.buttonPaddingX}px`,
                    display: 'inline-flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    textDecoration: 'none',
                    lineHeight: 1,
                    marginTop: settings.buttonMarginTopAuto ? 'auto' : `${settings.buttonMarginTop}px`,
                    marginBottom: `${settings.buttonMarginBottom}px`
                }
            };
        } else {
            const mobileSettings = banner.single_mobile;
            const desktopSettings = banner.single; 
            if (!mobileSettings || !desktopSettings) return {};

            const mobileAlignment = contentAlignment(desktopSettings.alignment); 

            return {
                contentStyles: {
                    alignItems: mobileAlignment,
                    textAlign: desktopSettings.alignment, 
                    padding: `${mobileSettings.paddingY}px ${mobileSettings.paddingX}px`, 
                    width: `${mobileSettings.contentWidth}${mobileSettings.contentWidthUnit}`, 
                    minHeight: `${mobileSettings.minHeight}px`, 
                    flexGrow: 1,
                    display: 'flex', 
                    flexDirection: 'column', 
                    zIndex: 3,
                    position: 'relative',
                    boxSizing: 'border-box'
                },
                titleStyles: {
                    color: desktopSettings.titleColor, 
                    fontSize: `${mobileSettings.titleSize}px`, 
                    fontWeight: mobileSettings.titleWeight, 
                    lineHeight: 1,
                    margin: 0,
                    marginTop: `${mobileSettings.titleMarginTop ?? 0}px`
                },
                descriptionStyles: {
                    color: desktopSettings.descColor, 
                    fontSize: `${mobileSettings.descSize}px`, 
                    fontWeight: mobileSettings.descWeight, 
                    whiteSpace: 'pre-wrap',
                    marginTop: `${mobileSettings.descMarginTop ?? mobileSettings.marginTopDescription ?? 12}px`, 
                    marginBottom: `${mobileSettings.descMarginBottom ?? 0}px`,
                    lineHeight: 1.5,
                    wordWrap: 'break-word'
                },
                buttonStyles: {
                    backgroundColor: desktopSettings.buttonBgColor, 
                    color: desktopSettings.buttonTextColor, 
                    fontSize: `${mobileSettings.buttonFontSize}px`, 
                    fontWeight: desktopSettings.buttonFontWeight, 
                    alignSelf: desktopSettings.alignment === 'center' ? 'center' : (desktopSettings.alignment === 'right' ? 'flex-end' : 'flex-start'), 
                    borderRadius: `${mobileSettings.buttonBorderRadius}px`, 
                    padding: `${mobileSettings.buttonPaddingY}px ${mobileSettings.buttonPaddingX}px`, 
                    display: 'inline-flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    textDecoration: 'none',
                    lineHeight: 1,
                    marginTop: mobileSettings.buttonMarginTopAuto ? 'auto' : `${mobileSettings.buttonMarginTop}px`, 
                    marginBottom: `${mobileSettings.buttonMarginBottom}px` 
                }
            };
        }
    };

    const getContentStyles = (view) => getDynamicStyles(view).contentStyles;
    const getTitleStyles = (view) => getDynamicStyles(view).titleStyles;
    const getDescriptionStyles = (view) => getDynamicStyles(view).descriptionStyles;
    const getButtonStyles = (view) => getDynamicStyles(view).buttonStyles;

    const getPromoBackgroundStyle = (promo, section) => {
        if (!promo) return 'transparent'; 

        const prefix = section; 
        const typeKey = `${prefix}BackgroundType`;
        const stopsKey = `${prefix}GradientStops`;
        const angleKey = `${prefix}GradientAngle`;
        const colorKey = `${prefix}BgColor`;

        if (promo[typeKey] === 'gradient') {
             if (!promo[stopsKey] || promo[stopsKey].length === 0) {
                return 'transparent';
            }
            const sortedStops = [...promo[stopsKey]].sort((a, b) => a.stop - b.stop);
            const stopsString = sortedStops.map(s => `${s.color} ${s.stop}%`).join(', ');
            return `linear-gradient(${promo[angleKey] || 90}deg, ${stopsString})`;
        }

        return promo[colorKey] || '#ffffff';
    };

    return {
        bannerStyles,
        contentAlignment,
        imageStyleObject,
        getApiBannerStyles,
        getApiContentStyles,
        getBannerContainerStyles,
        getContentStyles,
        getTitleStyles,
        getDescriptionStyles,
        getButtonStyles,
        getPromoBackgroundStyle,
    };
}
