import { initializeApp } from './app-logic/main.js';

if (window.yab_data) {
    initializeApp(window.yab_data);
} else {
    console.error("YAB Data object not found.");
}