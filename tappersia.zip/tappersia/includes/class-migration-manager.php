<?php
/**
 * tappersia/includes/class-migration-manager.php
 */

class Yab_Migration_Manager {

    /**
     * لیست بنرهایی که تصویر استاتیک دارند و باید در فایل زیپ قرار بگیرند.
     */
    private $static_image_banners = [
        'single-banner',
        'double-banner',
        'promotion-banner',
        'flight-ticket',
        'simple-banner',
        'sticky-simple-banner',
        'welcome-package-banner',
        'content-html-banner',
        'content-html-sidebar-banner'
    ];

    // نگاشت نوع بنر به کلید تنظیمات آن در دیتابیس برای پاکسازی
    private $type_mapping = [
        'single-banner' => 'single',
        'double-banner' => 'double',
        'simple-banner' => 'simple',
        'sticky-simple-banner' => 'stickySimple',
        'promotion-banner' => 'promotion',
        'flight-ticket' => 'flight',
        'tour-carousel' => 'tour',
        'hotel-carousel' => 'hotel',
        'welcome-package-banner' => ['welcomePackage', 'welcome_package'], // پشتیبانی از هر دو حالت نامگذاری
        'content-html-banner' => 'contentHtml',
        'content-html-sidebar-banner' => 'contentHtmlSidebar',
        'api-banner' => 'api'
    ];

    private $image_meta_keys = [
        'imageUrl', 
        'leftImageUrl', 
        'rightImageUrl', 
        'logoUrl', 
        'backgroundImage',
        'iconUrl',
        'mobileBackgroundImage',
        'desktopBackgroundImage'
    ];

    public function export_banners($banner_ids) {
        set_time_limit(0);
        ini_set('memory_limit', '512M');

        if (!class_exists('ZipArchive')) {
            return new WP_Error('zip_error', 'ماژول ZipArchive روی سرور فعال نیست.');
        }

        $upload_dir = wp_upload_dir();
        $temp_dir = $upload_dir['basedir'] . '/yab_export_' . time();
        $images_dir = $temp_dir . '/images';

        if (!wp_mkdir_p($images_dir)) {
            return new WP_Error('fs_error', 'خطا در ایجاد پوشه موقت.');
        }

        $export_data = [];
        $processed_images = []; 

        foreach ($banner_ids as $id) {
            $post = get_post($id);
            if (!$post) continue;

            $meta = get_post_meta($id, '_yab_banner_data', true);
            $type = get_post_meta($id, '_yab_banner_type', true);
            
            // 1. پاکسازی دیتای عمومی
            if (isset($meta['id'])) unset($meta['id']);
            $meta['displayOn'] = ['posts' => [], 'pages' => [], 'categories' => []];
            $meta['isActive'] = false;

            // 2. پاکسازی اختصاصی: حذف تنظیمات اضافی مربوط به بقیه بنرها
            $meta = $this->cleanup_settings_by_type($meta, $type);

            // 3. پردازش تصاویر (فقط برای انواع استاتیک)
            if (in_array($type, $this->static_image_banners)) {
                $meta = $this->process_image_export($meta, $images_dir, $processed_images);
            }

            $export_data[] = [
                'title' => $post->post_title,
                'type'  => $type,
                'display_method' => get_post_meta($id, '_yab_display_method', true),
                'settings' => $meta
            ];
        }

        file_put_contents($temp_dir . '/banners.json', json_encode($export_data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

        $zip_name = 'tappersia-banners-' . date('Y-m-d-His') . '.zip';
        $zip_path = $upload_dir['basedir'] . '/' . $zip_name;
        $zip_url = $upload_dir['baseurl'] . '/' . $zip_name;

        $zip = new ZipArchive();
        if ($zip->open($zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
            $zip->addFile($temp_dir . '/banners.json', 'banners.json');
            
            if (is_dir($images_dir)) {
                $files = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($images_dir, RecursiveDirectoryIterator::SKIP_DOTS),
                    RecursiveIteratorIterator::LEAVES_ONLY
                );

                foreach ($files as $file) {
                    if (!$file->isDir()) {
                        // نام فایل در زیپ دقیقا همان نام فایل ذخیره شده (هش شده) خواهد بود
                        $zip->addFile($file->getRealPath(), 'images/' . $file->getFilename());
                    }
                }
            }
            $zip->close();
        } else {
            return new WP_Error('zip_create_fail', 'خطا در ساخت فایل فشرده.');
        }

        $this->recursive_rmdir($temp_dir);

        return $zip_url;
    }

    /**
     * حذف کلیدهای تنظیمات مربوط به سایر بنرها برای تمیز شدن JSON
     */
    private function cleanup_settings_by_type($settings, $type) {
        if (!isset($this->type_mapping[$type])) {
            return $settings;
        }

        $target_key = $this->type_mapping[$type];
        
        // لیستی از تمام کلیدهای احتمالی تنظیمات بنرها
        $all_config_keys = [];
        foreach ($this->type_mapping as $t => $k) {
            if (is_array($k)) {
                $all_config_keys = array_merge($all_config_keys, $k);
            } else {
                $all_config_keys[] = $k;
            }
        }

        // کلیدهایی که باید حفظ شوند (کلید هدف + کلیدهای عمومی مثل displayOn)
        $valid_keys = is_array($target_key) ? $target_key : [$target_key];
        
        foreach ($all_config_keys as $key) {
            // اگر این کلید جزء کلیدهای بنر فعلی نیست، حذفش کن
            if (isset($settings[$key]) && !in_array($key, $valid_keys)) {
                unset($settings[$key]);
            }
        }

        return $settings;
    }

    private function process_image_export($data, $save_dir, &$processed) {
        if (!is_array($data)) return $data;

        foreach ($data as $key => &$value) {
            if (is_array($value)) {
                $value = $this->process_image_export($value, $save_dir, $processed);
            } 
            elseif (in_array($key, $this->image_meta_keys) && is_string($value) && !empty($value)) {
                
                $url = $value;
                
                // حل مشکل نام طولانی ویندوز: استفاده از هش MD5 برای نام فایل
                $extension = pathinfo(parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION);
                if (empty($extension)) $extension = 'jpg'; // پیش‌فرض اگر اکستنشن پیدا نشد
                
                // نام فایل در زیپ = md5(url).ext
                $hashed_name = md5($url) . '.' . $extension;
                
                if (!isset($processed[$hashed_name])) {
                    $base_url = content_url();
                    $base_path = WP_CONTENT_DIR;
                    
                    $local_path = str_replace($base_url, $base_path, $url);
                    
                    if (!file_exists($local_path)) {
                         $url_no_protocol = preg_replace('#^https?://#', '', $url);
                         $base_url_no_protocol = preg_replace('#^https?://#', '', $base_url);
                         $local_path = str_replace($base_url_no_protocol, $base_path, $url_no_protocol);
                    }

                    if (file_exists($local_path)) {
                        copy($local_path, $save_dir . '/' . $hashed_name);
                        $processed[$hashed_name] = true;
                    } else {
                        $response = wp_safe_remote_get($url, ['timeout' => 10, 'sslverify' => false]);
                        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
                            file_put_contents($save_dir . '/' . $hashed_name, wp_remote_retrieve_body($response));
                            $processed[$hashed_name] = true;
                        }
                    }
                }
                
                if (isset($processed[$hashed_name])) {
                    // ذخیره مسیر نسبی با نام کوتاه شده در JSON
                    $value = 'images/' . $hashed_name;
                }
            }
        }
        return $data;
    }

    // --- بخش ایمپورت ---

    public function import_banners($zip_file_path) {
        set_time_limit(0);
        ini_set('memory_limit', '512M');

        $upload_dir = wp_upload_dir();
        $extract_path = $upload_dir['basedir'] . '/yab_import_' . time();
        
        WP_Filesystem();
        if (is_wp_error(unzip_file($zip_file_path, $extract_path))) {
            return new WP_Error('unzip_error', 'فایل زیپ خراب است یا قابل باز شدن نیست.');
        }

        $json_file = $extract_path . '/banners.json';
        if (!file_exists($json_file)) {
            $this->recursive_rmdir($extract_path);
            return new WP_Error('invalid_zip', 'فایل banners.json در فایل زیپ پیدا نشد.');
        }

        $banners = json_decode(file_get_contents($json_file), true);
        if (!$banners) return new WP_Error('json_invalid', 'فرمت فایل JSON نامعتبر است.');

        $count = 0;
        foreach ($banners as $banner) {
            if (isset($banner['settings'])) {
                $banner['settings'] = $this->process_image_import($banner['settings'], $extract_path);
            }

            $post_id = wp_insert_post([
                'post_title'  => $banner['title'] . ' (Imported)',
                'post_type'   => 'yab_banner',
                'post_status' => 'publish'
            ]);

            if ($post_id && !is_wp_error($post_id)) {
                update_post_meta($post_id, '_yab_banner_type', sanitize_text_field($banner['type']));
                update_post_meta($post_id, '_yab_display_method', sanitize_text_field($banner['display_method']));
                update_post_meta($post_id, '_yab_is_active', 0);
                update_post_meta($post_id, '_yab_banner_data', $banner['settings']);
                $count++;
            }
        }

        $this->recursive_rmdir($extract_path);
        return $count;
    }

    private function process_image_import($data, $base_extract_path) {
        if (!is_array($data)) return $data;

        foreach ($data as $key => &$value) {
            if (is_array($value)) {
                $value = $this->process_image_import($value, $base_extract_path);
            }
            elseif (in_array($key, $this->image_meta_keys) && is_string($value)) {
                if (strpos($value, 'images/') === 0) {
                    $filename = basename($value);
                    $source_path = $base_extract_path . '/images/' . $filename;

                    if (file_exists($source_path)) {
                        $attach_id = $this->sideload_image($source_path, $filename);
                        if ($attach_id) {
                            $value = wp_get_attachment_url($attach_id);
                        }
                    }
                }
            }
        }
        return $data;
    }

    private function sideload_image($file_path, $filename) {
        global $wpdb;

        // جستجوی فایل تکراری بر اساس نام هش شده (که یونیک است)
        // اگر قبلاً ایمپورت شده باشد، نامش در post_title یا guid موجود است اما 
        // چک کردن متای _wp_attached_file مطمئن‌ترین راه است
        $existing_id = $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_wp_attached_file' AND meta_value LIKE %s LIMIT 1",
            '%' . $wpdb->esc_like($filename)
        ));
        
        if ($existing_id) return $existing_id;

        $file_content = file_get_contents($file_path);
        $upload = wp_upload_bits($filename, null, $file_content);
        if ($upload['error']) return false;

        $attachment = [
            'post_mime_type' => wp_check_filetype($filename)['type'],
            'post_title'     => $filename, // نام فایل هش شده به عنوان تایتل
            'post_status'    => 'inherit'
        ];
        
        $attach_id = wp_insert_attachment($attachment, $upload['file']);
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        wp_update_attachment_metadata($attach_id, wp_generate_attachment_metadata($attach_id, $upload['file']));

        return $attach_id;
    }

    private function recursive_rmdir($dir) {
        if (!is_dir($dir)) return;
        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach($it as $file) {
            $file->isDir() ? rmdir($file->getRealPath()) : unlink($file->getRealPath());
        }
        rmdir($dir);
    }
}