<?php
/**
 * tappersia/includes/class-migration-manager.php
 */

class Yab_Migration_Manager {

    /**
     * List of banners that have static images.
     */
    private $static_image_banners = [
        'single-banner',
        'double-banner',
        'promotion-banner',
        'flight-ticket',
        'simple-banner',
        'sticky-simple-banner',
        'welcome-package-banner',
        'content-html-banner',
        'content-html-sidebar-banner'
    ];

    /**
     * Map banner types to their settings keys to clean up extra data during export.
     */
    private $type_mapping = [
        'single-banner' => 'single',
        'double-banner' => 'double',
        'simple-banner' => 'simple',
        'sticky-simple-banner' => 'stickySimple',
        'promotion-banner' => 'promotion',
        'flight-ticket' => 'flight',
        'tour-carousel' => 'tour',
        'hotel-carousel' => 'hotel',
        'welcome-package-banner' => ['welcomePackage', 'welcome_package'],
        'content-html-banner' => 'contentHtml',
        'content-html-sidebar-banner' => 'contentHtmlSidebar',
        'api-banner' => 'api'
    ];

    /**
     * Keys that contain image URLs in the database.
     */
    private $image_meta_keys = [
        'imageUrl', 
        'leftImageUrl', 
        'rightImageUrl', 
        'logoUrl', 
        'backgroundImage',
        'iconUrl',
        'mobileBackgroundImage',
        'desktopBackgroundImage'
    ];

    /**
     * Allowed mime types for security (Allowlist).
     */
    private $allowed_mime_types = [
        'jpg|jpeg|jpe' => 'image/jpeg',
        'png'          => 'image/png',
        'gif'          => 'image/gif',
        'webp'         => 'image/webp',
        'svg'          => 'image/svg+xml'
    ];

    // =========================================================================
    // EXPORT SECTION
    // =========================================================================

    public function export_banners($banner_ids) {
        set_time_limit(0);
        ini_set('memory_limit', '512M');

        if (!class_exists('ZipArchive')) {
            return new WP_Error('zip_error', 'The ZipArchive module is not enabled on the server.');
        }

        $upload_dir = wp_upload_dir();
        $temp_dir = $upload_dir['basedir'] . '/yab_export_' . time();
        $images_dir = $temp_dir . '/images';

        if (!wp_mkdir_p($images_dir)) {
            return new WP_Error('fs_error', 'Error creating temporary directory.');
        }

        $export_data = [];
        $processed_images = []; 

        foreach ($banner_ids as $id) {
            $post = get_post($id);
            if (!$post) continue;

            $meta = get_post_meta($id, '_yab_banner_data', true);
            $type = get_post_meta($id, '_yab_banner_type', true);
            
            // Clean up general data
            if (isset($meta['id'])) unset($meta['id']);
            $meta['displayOn'] = ['posts' => [], 'pages' => [], 'categories' => []];
            $meta['isActive'] = false;

            // Clean up extra settings related to other banner types
            $meta = $this->cleanup_settings_by_type($meta, $type);

            // Process images (only for static types)
            if (in_array($type, $this->static_image_banners)) {
                $meta = $this->process_image_export($meta, $images_dir, $processed_images);
            }

            $export_data[] = [
                'title' => $post->post_title,
                'type'  => $type,
                'display_method' => get_post_meta($id, '_yab_display_method', true),
                'settings' => $meta
            ];
        }

        file_put_contents($temp_dir . '/banners.json', json_encode($export_data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

        $zip_name = 'tappersia-banners-' . date('Y-m-d-His') . '.zip';
        $zip_path = $upload_dir['basedir'] . '/' . $zip_name;
        $zip_url = $upload_dir['baseurl'] . '/' . $zip_name;

        $zip = new ZipArchive();
        if ($zip->open($zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
            $zip->addFile($temp_dir . '/banners.json', 'banners.json');
            
            if (is_dir($images_dir)) {
                $files = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($images_dir, RecursiveDirectoryIterator::SKIP_DOTS),
                    RecursiveIteratorIterator::LEAVES_ONLY
                );

                foreach ($files as $file) {
                    if (!$file->isDir()) {
                        $zip->addFile($file->getRealPath(), 'images/' . $file->getFilename());
                    }
                }
            }
            $zip->close();
        } else {
            return new WP_Error('zip_create_fail', 'Error creating zip file.');
        }

        $this->recursive_rmdir($temp_dir);

        return $zip_url;
    }

    private function cleanup_settings_by_type($settings, $type) {
        if (!isset($this->type_mapping[$type])) {
            return $settings;
        }

        $target_key = $this->type_mapping[$type];
        
        $all_config_keys = [];
        foreach ($this->type_mapping as $t => $k) {
            if (is_array($k)) {
                $all_config_keys = array_merge($all_config_keys, $k);
            } else {
                $all_config_keys[] = $k;
            }
        }

        $valid_keys = is_array($target_key) ? $target_key : [$target_key];
        
        foreach ($all_config_keys as $key) {
            if (isset($settings[$key]) && !in_array($key, $valid_keys)) {
                unset($settings[$key]);
            }
        }

        return $settings;
    }

    private function process_image_export($data, $save_dir, &$processed) {
        if (!is_array($data)) return $data;

        foreach ($data as $key => &$value) {
            if (is_array($value)) {
                $value = $this->process_image_export($value, $save_dir, $processed);
            } 
            elseif (in_array($key, $this->image_meta_keys) && is_string($value) && !empty($value)) {
                
                $url = $value;
                $extension = pathinfo(parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION);
                if (empty($extension)) $extension = 'jpg';
                
                // Use MD5 hash for filename to prevent long filename issues on Windows
                $hashed_name = md5($url) . '.' . $extension;
                
                if (!isset($processed[$hashed_name])) {
                    $base_url = content_url();
                    $base_path = WP_CONTENT_DIR;
                    
                    $local_path = str_replace($base_url, $base_path, $url);
                    
                    // Attempt to find file in case of http/https mismatch
                    if (!file_exists($local_path)) {
                         $url_no_protocol = preg_replace('#^https?://#', '', $url);
                         $base_url_no_protocol = preg_replace('#^https?://#', '', $base_url);
                         $local_path = str_replace($base_url_no_protocol, $base_path, $url_no_protocol);
                    }

                    if (file_exists($local_path)) {
                        copy($local_path, $save_dir . '/' . $hashed_name);
                        $processed[$hashed_name] = true;
                    } else {
                        // Download file if not local
                        $response = wp_safe_remote_get($url, ['timeout' => 10, 'sslverify' => false]);
                        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
                            file_put_contents($save_dir . '/' . $hashed_name, wp_remote_retrieve_body($response));
                            $processed[$hashed_name] = true;
                        }
                    }
                }
                
                if (isset($processed[$hashed_name])) {
                    $value = 'images/' . $hashed_name;
                }
            }
        }
        return $data;
    }

    // =========================================================================
    // IMPORT SECTION (SECURED)
    // =========================================================================

    public function import_banners($zip_file_path) {
        set_time_limit(0);
        ini_set('memory_limit', '512M');

        // 1. Security check of zip contents *before* any extraction
        $validation_result = $this->validate_zip_contents($zip_file_path);
        if (is_wp_error($validation_result)) {
            return $validation_result;
        }

        $upload_dir = wp_upload_dir();
        $extract_path = $upload_dir['basedir'] . '/yab_import_' . time();
        
        // Create clean directory
        if (!wp_mkdir_p($extract_path)) {
            return new WP_Error('fs_error', 'Error creating temporary directory.');
        }

        // 2. Manual and controlled extraction
        $zip = new ZipArchive();
        if ($zip->open($zip_file_path) === TRUE) {
            $zip->extractTo($extract_path);
            $zip->close();
        } else {
            return new WP_Error('zip_open_fail', 'Failed to open zip file.');
        }

        // 3. Smart find of JSON file (even in nested folders)
        $json_file = $this->find_banners_json($extract_path);
        
        if (!$json_file) {
            $this->recursive_rmdir($extract_path);
            return new WP_Error('invalid_zip', 'banners.json not found in the zip file.');
        }

        $actual_base_path = dirname($json_file);
        $json_content = file_get_contents($json_file);
        $banners = json_decode($json_content, true);

        if (!$banners) {
            $this->recursive_rmdir($extract_path);
            return new WP_Error('json_invalid', 'Invalid JSON file format.');
        }

        $count = 0;
        foreach ($banners as $banner) {
            // Recursive settings sanitization
            $clean_settings = isset($banner['settings']) ? $this->sanitize_settings_recursive($banner['settings']) : [];
            
            // Process and import images
            $clean_settings = $this->process_image_import($clean_settings, $actual_base_path);

            $safe_title = sanitize_text_field($banner['title']);
            $safe_type = sanitize_text_field($banner['type']);
            $safe_display = sanitize_text_field($banner['display_method'] ?? '');

            $post_id = wp_insert_post([
                'post_title'  => $safe_title . ' (Imported)',
                'post_type'   => 'yab_banner',
                'post_status' => 'publish'
            ]);

            if ($post_id && !is_wp_error($post_id)) {
                update_post_meta($post_id, '_yab_banner_type', $safe_type);
                update_post_meta($post_id, '_yab_display_method', $safe_display);
                update_post_meta($post_id, '_yab_is_active', 0);
                update_post_meta($post_id, '_yab_banner_data', $clean_settings);
                $count++;
            }
        }

        $this->recursive_rmdir($extract_path);
        return $count;
    }

    /**
     * Security check of zip file contents before extraction.
     * Only allow json and image files.
     */
    private function validate_zip_contents($zip_path) {
        $zip = new ZipArchive();
        if ($zip->open($zip_path) !== TRUE) {
            return new WP_Error('zip_error', 'Invalid zip file.');
        }

        // Allowed extensions list (White List)
        $allowed_extensions = ['json', 'jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];

        for ($i = 0; $i < $zip->numFiles; $i++) {
            $stat = $zip->statIndex($i);
            $filename = $stat['name'];

            // Ignore directories
            if (substr($filename, -1) === '/') continue;

            // 1. Prevent Path Traversal
            if (strpos($filename, '../') !== false || strpos($filename, '..\\') !== false) {
                $zip->close();
                return new WP_Error('security_violation', 'Unauthorized zip file structure.');
            }

            // 2. Check file extension
            $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            
            // Ignore Mac OS hidden files (not dangerous)
            if (strpos($filename, '__MACOSX') !== false || strpos($filename, '.DS_Store') !== false) {
                continue;
            }

            if (!in_array($ext, $allowed_extensions)) {
                $zip->close();
                return new WP_Error('security_violation', "Unauthorized file detected in the package (.$ext). Operation aborted for security reasons.");
            }
        }

        $zip->close();
        return true;
    }

    /**
     * Find banners.json recursively.
     */
    private function find_banners_json($dir) {
        if (file_exists($dir . '/banners.json')) {
            return $dir . '/banners.json';
        }

        if (is_dir($dir)) {
            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::SELF_FIRST
            );

            foreach ($iterator as $file) {
                if ($file->isFile() && $file->getFilename() === 'banners.json') {
                    return $file->getRealPath();
                }
            }
        }

        return false;
    }

    private function sanitize_settings_recursive($data) {
        if (is_array($data)) {
            foreach ($data as $key => &$value) {
                $value = $this->sanitize_settings_recursive($value);
            }
            return $data;
        }
        return is_string($data) ? wp_kses_post($data) : $data;
    }

    private function process_image_import($data, $base_extract_path) {
        if (!is_array($data)) return $data;

        foreach ($data as $key => &$value) {
            if (is_array($value)) {
                $value = $this->process_image_import($value, $base_extract_path);
            }
            elseif (in_array($key, $this->image_meta_keys) && is_string($value)) {
                if (strpos($value, 'images/') === 0) {
                    $filename = basename($value);
                    $source_path = $base_extract_path . '/images/' . $filename;

                    // Only upload if file exists and is secure
                    if (file_exists($source_path) && $this->is_safe_image($source_path)) {
                        $attach_id = $this->sideload_image($source_path, $filename);
                        if ($attach_id) {
                            $value = wp_get_attachment_url($attach_id);
                        }
                    }
                }
            }
        }
        return $data;
    }

    private function is_safe_image($file_path) {
        $filetype = wp_check_filetype($file_path, $this->allowed_mime_types);
        if (!$filetype['ext'] || !$filetype['type']) {
            return false;
        }
        return true;
    }

    private function sideload_image($file_path, $filename) {
        global $wpdb;

        $existing_id = $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_wp_attached_file' AND meta_value LIKE %s LIMIT 1",
            '%' . $wpdb->esc_like($filename)
        ));
        
        if ($existing_id) return $existing_id;

        $file_content = file_get_contents($file_path);
        $upload = wp_upload_bits($filename, null, $file_content);
        if ($upload['error']) return false;

        $attachment = [
            'post_mime_type' => wp_check_filetype($filename, $this->allowed_mime_types)['type'],
            'post_title'     => $filename,
            'post_status'    => 'inherit'
        ];
        
        $attach_id = wp_insert_attachment($attachment, $upload['file']);
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        wp_update_attachment_metadata($attach_id, wp_generate_attachment_metadata($attach_id, $upload['file']));

        return $attach_id;
    }

    private function recursive_rmdir($dir) {
        if (!is_dir($dir)) return;
        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach($it as $file) {
            $file->isDir() ? rmdir($file->getRealPath()) : unlink($file->getRealPath());
        }
        rmdir($dir);
    }
}