<?php
/**
 * tappersia/includes/class-main.php
 */

class Yab_Main {

    protected $plugin_name;
    protected $version;
    protected $plugin_file;
    private $updater;

    private $license_manager;
    private $settings_page_handler;
    private $admin_menu;
    
    // متغیری برای نگهداری کلاس تنظیمات سراسری و Migration
    private $global_settings;

    public function __construct( $plugin_file ) {
        $this->plugin_file = $plugin_file;
        $this->plugin_name = 'tappersia';
        $this->version = YAB_VERSION;
        $this->load_dependencies();

        require_once YAB_PLUGIN_DIR . 'includes/license/class-yab-license-manager.php';
        $this->license_manager = new Yab_License_Manager();

        require_once YAB_PLUGIN_DIR . 'admin/class-yab-settings-page.php';
        $this->settings_page_handler = new Yab_Settings_Page($this->license_manager);
        
        // لود کردن کلاس تنظیمات سراسری و Import/Export
        require_once YAB_PLUGIN_DIR . 'admin/class-yab-global-settings.php';
        $this->global_settings = new Yab_Global_Settings();

        $this->admin_menu = new Yab_Admin_Menu( $this->get_plugin_name(), $this->get_version() );
    }

    private function load_dependencies() {
        require_once YAB_PLUGIN_DIR . 'admin/class-admin-menu.php';
        require_once YAB_PLUGIN_DIR . 'admin/class-ajax-handler.php';
        require_once YAB_PLUGIN_DIR . 'public/class-shortcode-handler.php';
        require_once YAB_PLUGIN_DIR . 'includes/updater/class-yab-updater-factory.php';
        
        // لود کردن منیجر اصلی مدیریت جابجایی (Migration)
        require_once YAB_PLUGIN_DIR . 'includes/class-migration-manager.php';

        if (file_exists(YAB_PLUGIN_DIR . 'includes/utils/class-yab-display-validator.php')) {
            require_once YAB_PLUGIN_DIR . 'includes/utils/class-yab-display-validator.php';
        }

        if (file_exists(YAB_PLUGIN_DIR . 'public/class-yab-content-injector.php')) {
            require_once YAB_PLUGIN_DIR . 'public/class-yab-content-injector.php';
        }
    }

    public function run() {
        
        add_action('yab_daily_license_check_event', array($this->license_manager, 'run_automated_check'));

        if (is_admin()) {
            add_action( 'admin_enqueue_scripts', array( $this->admin_menu, 'enqueue_styles_and_scripts' ) );

            // بارگذاری استایل‌های ادمین برای صفحات تپ‌پرشیا
            add_action('admin_enqueue_scripts', function($hook) {
                if (isset($_GET['page']) && strpos($_GET['page'], 'tappersia') !== false) {
                     wp_enqueue_style( 'yab-admin-style-forced', YAB_PLUGIN_URL . 'assets/css/admin-style.css', array(), YAB_VERSION, 'all' );
                     wp_enqueue_style( 'yab-admin-global-forced', YAB_PLUGIN_URL . 'assets/css/admin-global.css', array(), YAB_VERSION, 'all' );
                }
            });
        }

        $is_dev_mode = false; 

        if ($is_dev_mode || $this->license_manager->is_license_valid()) {
            $this->define_cpt();
            $this->define_admin_hooks();
            $this->define_public_hooks();
        } else {
            if (is_admin()) {
                $this->define_activation_hooks();
            }
        }
    }

    private function define_cpt() {
        add_action('init', array($this, 'register_banner_cpt'));
    }

    private function define_admin_hooks() {
        add_action( 'admin_menu', array( $this->admin_menu, 'add_plugin_admin_menu' ) );
        
        $this->settings_page_handler->init();
        
        // اجرای متد init تنظیمات سراسری برای ثبت منوی Import/Export و هوک‌های Ajax
        $this->global_settings->init();

        new Yab_Ajax_Handler();
        
        add_action('admin_post_yab_deactivate_license', [$this, 'handle_deactivate_license']);

        $this->updater = Yab_Updater_Factory::build(
            $this->plugin_file,
            $this->version,
            'https://raw.githubusercontent.com/Behnam-abedi/tappersia-releases/main/update-info.json'
        );
        $this->updater->init();

        add_action('wp_ajax_yab_ajax_check_for_updates', [$this, 'ajax_check_for_updates']);
        add_action('wp_ajax_yab_ajax_install_update', [$this, 'ajax_install_update']);
    }

    public function ajax_check_for_updates() {
        check_ajax_referer('yab_update_nonce', 'nonce');
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Permission denied.' ] );
        }

        if ( $this->updater ) {
            $this->updater->force_check();
        }
        delete_site_transient( 'update_plugins' );
        wp_update_plugins();

        $transient = get_site_transient( 'update_plugins' );
        $slug = $this->updater->get_plugin_slug();

        if ( ! empty( $transient->response[ $slug ] ) ) {
            $update_data = $transient->response[ $slug ];
            wp_send_json_success( [
                'update_available' => true,
                'new_version' => $update_data->new_version,
            ] );
        } else {
            wp_send_json_success( [
                'update_available' => false,
            ] );
        }
    }

    public function ajax_install_update() {
        check_ajax_referer('yab_update_nonce', 'nonce');
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Permission denied.' ] );
        }

        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/misc.php';
        require_once YAB_PLUGIN_DIR . 'includes/updater/class-yab-silent-upgrader-skin.php';

        $slug = $this->updater->get_plugin_slug();
        $skin = new Yab_Silent_Upgrader_Skin();
        $upgrader = new Plugin_Upgrader( $skin );

        $result = $upgrader->upgrade( $slug );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( [ 'message' => 'Upgrade error: ' . $result->get_error_message() ] );
        } elseif ( $skin->get_errors() ) {
            wp_send_json_error( [ 'message' => 'Upgrade skin error: ' . implode( ', ', $skin->get_errors() ) ] );
        } elseif ( $result === null ) {
            wp_send_json_error( [ 'message' => 'Installation failed. File permissions might be incorrect.' ] );
        }

        activate_plugin( $slug );
        
        wp_send_json_success( [
            'reload' => true,
            'message' => 'Update installed successfully.',
        ] );
    }

    private function define_activation_hooks() {
        add_action('admin_menu', array($this, 'register_activation_page'));
        add_action('admin_init', array($this, 'redirect_to_activation_page'));
        add_action('admin_notices', array($this, 'show_activation_notice'));
        add_action('network_admin_notices', array($this, 'show_activation_notice'));
        add_action('admin_init', array($this->settings_page_handler, 'process_activation_submission'));
    }

    public function register_activation_page() {
        $logo_url = YAB_PLUGIN_URL . 'assets/image/logo.png';
        
        add_menu_page(
            'Activate Tappersia',
            'Tappersia',
            'manage_options',
            'tappersia-activate',
            array($this->settings_page_handler, 'render_activation_page'),
            $logo_url,
            25
        );
    }

    public function redirect_to_activation_page() {
        $option_name = $this->license_manager->get_activation_option_name();

        if (get_option($option_name, false) &&
            (!isset($_GET['page']) || $_GET['page'] !== 'tappersia-activate'))
        {
            if (isset($_POST['yab_activate_license'])) {
                return;
            }
            
            wp_safe_redirect(admin_url('admin.php?page=tappersia-activate'));
            exit;
        }
    }

    public function show_activation_notice() {
        if (isset($_GET['page']) && $_GET['page'] === 'tappersia-activate') {
            return;
        }
        
        $activation_url = esc_url(admin_url('admin.php?page=tappersia-activate'));
        echo '<div class="notice notice-error is-dismissible">
            <p><strong>Tappersia Plugin is not active.</strong> Please <a href="' . $activation_url . '">enter your API key</a> to activate the plugin.</p>
        </div>';
    }
    
    public function handle_deactivate_license() {
        if (!isset($_POST['yab_nonce']) || !wp_verify_nonce(sanitize_text_field($_POST['yab_nonce']), 'yab_deactivate_license_nonce')) {
            wp_die('Security check failed.');
        }
        if (!current_user_can('manage_options')) {
            wp_die('You do not have permission to do this.');
        }

        $this->license_manager->deactivate_license();
        
        update_option($this->license_manager->get_activation_option_name(), true);

        wp_safe_redirect(admin_url('admin.php?page=tappersia-activate'));
        exit;
    }

    private function define_public_hooks() {
        $shortcode_handler = new Yab_Shortcode_Handler();
        add_action('init', array($shortcode_handler, 'register_shortcodes'));
        
        add_action('wp_enqueue_scripts', array($this, 'enqueue_public_styles_and_scripts'));
        
        add_action('wp_footer', array($this, 'display_sticky_banner_in_footer'));

        if (class_exists('Yab_Content_Injector')) {
            $injector = new Yab_Content_Injector();
            $injector->init();
        }
    }
    
    public function display_sticky_banner_in_footer() {
        global $post;
        if (!is_singular() && !is_category() && !is_archive()) {
            return;
        }

        $args = [
            'post_type' => 'yab_banner',
            'posts_per_page' => 1,
            'post_status' => 'publish',
            'meta_query' => [
                'relation' => 'AND',
                ['key' => '_yab_display_method', 'value' => 'Fixed'],
                ['key' => '_yab_is_active', 'value' => true],
                ['key' => '_yab_banner_type', 'value' => 'sticky-simple-banner']
            ]
        ];

        $banners = get_posts($args);
        if (empty($banners)) return;

        $banner_post = $banners[0];
        $data = get_post_meta($banner_post->ID, '_yab_banner_data', true);
        if (empty($data['displayOn'])) return;

        if (class_exists('Yab_Display_Validator') && Yab_Display_Validator::should_display($data['displayOn'])) {
            require_once YAB_PLUGIN_DIR . 'public/Renderers/class-sticky-simple-banner-renderer.php';
            $renderer = new Yab_Sticky_Simple_Banner_Renderer($data, $banner_post->ID);
            echo $renderer->render();
        }
    }

    public function enqueue_public_styles_and_scripts() {
        wp_enqueue_style( 'yab-roboto-font', 'https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap', array(), null );
        wp_enqueue_style( 'yab-public-style', YAB_PLUGIN_URL . 'assets/css/public-style.css', array('yab-roboto-font'), $this->version, 'all' );
        
        wp_enqueue_style( 'swiper-css', YAB_PLUGIN_URL . 'assets/vendor/swiper/swiper-bundle.min.css', array(), '12.0.2' );
        wp_enqueue_script( 'swiper-js', YAB_PLUGIN_URL . 'assets/vendor/swiper/swiper-bundle.min.js', array(), '12.0.2', true );
    }

    public function register_banner_cpt() {
        $labels = array(
            'name'                  => _x( 'Banners', 'Post type general name', 'yab' ),
            'singular_name'         => _x( 'Banner', 'Post type singular name', 'yab' ),
        );
        $args = array(
            'labels'             => $labels,
            'public'             => false,
            'publicly_queryable' => false,
            'show_ui'            => false,
            'show_in_menu'       => false,
            'query_var'          => false,
            'rewrite'            => array( 'slug' => 'yab_banner' ),
            'capability_type'    => 'post',
            'has_archive'        => false,
            'hierarchical'       => false,
            'supports'           => array( 'title' ),
        );
        register_post_type( 'yab_banner', $args );
    }

    public function get_plugin_name() {
        return $this->plugin_name;
    }

    public function get_version() {
        return $this->version;
    }
}