<?php
// tappersia/includes/BannerTypes/PromotionBanner/PromotionBanner.php

if (!class_exists('Yab_Promotion_Banner')) :
class Yab_Promotion_Banner {
    
    public function save($banner_data) {
        if (empty($banner_data['name'])) {
            wp_send_json_error(['message' => 'Banner name is required.']);
            return;
        }

        if ($banner_data['displayMethod'] === 'Fixed') {
            $conflict = $this->check_for_banner_conflict($banner_data['displayOn'], $banner_data['id']);
            if ($conflict['has_conflict']) {
                wp_send_json_error(['message' => $conflict['message']]);
                return;
            }
        }

        $sanitized_data = $this->sanitize_banner_data($banner_data);
        $post_id = !empty($sanitized_data['id']) ? intval($sanitized_data['id']) : 0;
        
        $post_data = [
            'post_title'    => $sanitized_data['name'],
            'post_type'     => 'yab_banner',
            'post_status'   => 'publish',
        ];

        if ($post_id > 0) {
            $post_data['ID'] = $post_id;
        }

        $result = wp_insert_post($post_data, true);

        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        } else {
            unset($sanitized_data['name']);
            unset($sanitized_data['id']);

            update_post_meta($result, '_yab_banner_data', $sanitized_data);
            update_post_meta($result, '_yab_banner_type', 'promotion-banner');
            update_post_meta($result, '_yab_display_method', $sanitized_data['displayMethod']);
            update_post_meta($result, '_yab_is_active', $sanitized_data['isActive']);
            
            wp_send_json_success(['message' => 'Banner saved successfully!', 'banner_id' => $result]);
        }

        wp_die();
    }

    private function check_for_banner_conflict($displayOn, $current_banner_id) {
        $conflict = ['has_conflict' => false, 'message' => ''];
        $post_ids = !empty($displayOn['posts']) ? array_map('intval', $displayOn['posts']) : [];
        $page_ids = !empty($displayOn['pages']) ? array_map('intval', $displayOn['pages']) : [];
        $cat_ids  = !empty($displayOn['categories']) ? array_map('intval', $displayOn['categories']) : [];

        if (empty($post_ids) && empty($page_ids) && empty($cat_ids)) {
            return $conflict;
        }

        $args = [
            'post_type'    => 'yab_banner',
            'posts_per_page' => -1,
            'post_status'  => 'publish',
            'meta_query'   => [
                'relation' => 'AND',
                ['key' => '_yab_display_method', 'value' => 'Fixed', 'compare' => '='],
                ['key' => '_yab_banner_type', 'value' => 'promotion-banner', 'compare' => '=']
            ],
            'post__not_in' => $current_banner_id ? [intval($current_banner_id)] : [],
        ];

        $other_banners_query = new WP_Query($args);

        foreach ($other_banners_query->posts as $banner_post) {
            $data = get_post_meta($banner_post->ID, '_yab_banner_data', true);
            if (empty($data) || empty($data['displayOn'])) continue;

            $other_post_ids = !empty($data['displayOn']['posts']) ? array_map('intval', $data['displayOn']['posts']) : [];
            $other_page_ids = !empty($data['displayOn']['pages']) ? array_map('intval', $data['displayOn']['pages']) : [];

            $post_intersection = array_intersect($post_ids, $other_post_ids);
            if (!empty($post_intersection)) {
                $p = get_post(reset($post_intersection));
                return ['has_conflict' => true, 'message' => sprintf('Error: The post "%s" already has the Promotion Banner "%s" assigned to it.', $p->post_title, $banner_post->post_title)];
            }

            $page_intersection = array_intersect($page_ids, $other_page_ids);
            if (!empty($page_intersection)) {
                $p = get_post(reset($page_intersection));
                return ['has_conflict' => true, 'message' => sprintf('Error: The page "%s" already has the Promotion Banner "%s" assigned to it.', $p->post_title, $banner_post->post_title)];
            }
        }
        return $conflict;
    }
    
    private function sanitize_banner_data($data) {
        $sanitized = [];
        if (!is_array($data)) return $sanitized;

        foreach ($data as $key => $value) {
            // *** START: Added sanitization for gradient stops ***
            if (($key === 'headerGradientStops' || $key === 'bodyGradientStops') && is_array($value)) {
                $sanitized[$key] = array_map(function($stop) {
                    return [
                        'color' => isset($stop['color']) ? sanitize_text_field($stop['color']) : '#FFFFFF',
                        'stop' => isset($stop['stop']) ? intval($stop['stop']) : 0,
                    ];
                }, $value);
            // *** END: Added sanitization for gradient stops ***
            } elseif (is_array($value)) {
                $sanitized[$key] = $this->sanitize_banner_data($value);
            } elseif (is_bool($value)) {
                $sanitized[$key] = $value;
            } elseif (is_numeric($value) || $value === null) {
                $sanitized[$key] = $value;
            } else {
                switch ($key) {
                    case 'iconUrl':
                    case 'linkUrl':
                        $sanitized[$key] = esc_url_raw(trim($value));
                        break;
                    case 'bodyText':
                        $sanitized[$key] = wp_kses_post(trim($value));
                        break;
                    case 'headerBgColor':
                    // --- REMOVED old keys: headerGradientColor1, headerGradientColor2 ---
                    case 'headerTextColor':
                    case 'bodyBgColor':
                    // --- REMOVED old keys: bodyGradientColor1, bodyGradientColor2 ---
                    case 'bodyTextColor':
                    case 'linkColor':
                    case 'borderColor':
                        $sanitized[$key] = sanitize_text_field($value); // Allow rgba
                        break;
                    default:
                        $sanitized[$key] = sanitize_text_field(trim($value));
                }
            }
        }
        return $sanitized;
    }
}
endif;