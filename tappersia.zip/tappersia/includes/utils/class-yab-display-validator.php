<?php

class Yab_Display_Validator {

    public static function should_display(array $display_conditions, ?int $current_object_id = null): bool {
        if (empty($display_conditions)) {
            return false;
        }

        if (!$current_object_id) {
            $current_object_id = get_queried_object_id();
        }

        // FIX: Extract IDs robustly instead of assuming simple array
        $post_ids = self::normalize_ids($display_conditions['posts'] ?? []);
        $page_ids = self::normalize_ids($display_conditions['pages'] ?? []);
        $cat_ids  = self::normalize_ids($display_conditions['categories'] ?? []);

        if (empty($post_ids) && empty($page_ids) && empty($cat_ids)) {
            return false;
        }

        if (is_singular('post') && in_array($current_object_id, $post_ids, true)) {
            return true;
        }

        if (is_page() && in_array($current_object_id, $page_ids, true)) {
            return true;
        }

        if (!empty($cat_ids)) {
            if (is_category($cat_ids)) {
                return true;
            }
            if (is_singular('post') && has_category($cat_ids, $current_object_id)) {
                return true;
            }
        }

        return false;
    }

    private static function normalize_ids($items) {
        if (empty($items) || !is_array($items)) return [];
        $ids = [];
        foreach ($items as $item) {
            if (is_numeric($item)) {
                $ids[] = intval($item);
            } elseif (is_array($item)) {
                if (isset($item['ID'])) $ids[] = intval($item['ID']);
                elseif (isset($item['id'])) $ids[] = intval($item['id']);
                elseif (isset($item['term_id'])) $ids[] = intval($item['term_id']);
            } elseif (is_object($item)) {
                 if (isset($item->ID)) $ids[] = intval($item->ID);
                 elseif (isset($item->id)) $ids[] = intval($item->id);
                 elseif (isset($item->term_id)) $ids[] = intval($item->term_id);
            }
        }
        return array_unique(array_filter($ids));
    }
}