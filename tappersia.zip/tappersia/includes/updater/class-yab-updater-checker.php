<?php
// /includes/updater/class-yab-updater-checker.php
defined('ABSPATH') || exit;

class Yab_Updater_Checker {

    protected $plugin_file;
    protected $plugin_slug;
    protected $current_version;
    protected $client;
    protected $validator;
    private $validated_response = null;

    public function __construct( $plugin_file, $current_version, Yab_Updater_Client $client, Yab_Updater_Validator $validator ) {
        $this->plugin_file     = $plugin_file;
        $this->plugin_slug     = plugin_basename( $plugin_file );
        $this->current_version = $current_version;
        $this->client          = $client;
        $this->validator       = $validator;
    }

    public function init() {
        add_filter( 'pre_set_site_transient_update_plugins', [ $this, 'check_for_updates' ] );
        add_filter( 'plugins_api', [ $this, 'plugin_information' ], 20, 3 );
        add_action( 'upgrader_process_complete', [ $this, 'after_update' ], 10, 2 );
    }

    public function check_for_updates( $transient ) {
        if ( empty( $transient->checked ) ) {
            return $transient;
        }

        $validated_data = $this->get_validated_data();
        if ( is_wp_error( $validated_data ) || ! $validated_data ) {
            return $transient;
        }

        // --- DEBUG LOGIC ---
        // این بخش لاگ برای دیباگ است. اگر در فایل wp-config.php دیباگ روشن باشد، در debug.log ذخیره می‌شود.
        /*
        error_log( sprintf( 
            'Tappersia Check: Installed[%s] vs Remote[%s]', 
            $this->current_version, 
            $validated_data->version 
        ) );
        */

        // مقایسه ورژن‌ها
        if ( version_compare( $this->current_version, $validated_data->version, '<' ) ) {
            $update_obj = new stdClass();
            $update_obj->slug          = $this->plugin_slug;
            $update_obj->plugin        = $this->plugin_slug;
            $update_obj->new_version   = $validated_data->version;
            $update_obj->url           = $validated_data->homepage;
            $update_obj->package       = $validated_data->download_url;
            $update_obj->tested        = $validated_data->tested;
            $update_obj->requires      = $validated_data->requires;
            $update_obj->requires_php  = $validated_data->requires_php;
            
            // اضافه کردن به لیست آپدیت‌ها
            $transient->response[ $this->plugin_slug ] = $update_obj;
            
            // error_log( 'Tappersia: Update available and injected into transient.' );
        } else {
            // error_log( 'Tappersia: No update needed.' );
        }

        return $transient;
    }

    public function plugin_information( $result, $action, $args ) {
        if ( 'plugin_information' !== $action || empty( $args->slug ) || $args->slug !== $this->plugin_slug ) {
            return $result;
        }

        $validated_data = $this->get_validated_data();
        if ( is_wp_error( $validated_data ) || ! $validated_data ) {
            return $result;
        }

        $plugin_data = $this->get_plugin_data();

        $result = new stdClass();
        $result->name          = $plugin_data['Name'];
        $result->slug          = $this->plugin_slug;
        $result->version       = $validated_data->version;
        $result->author        = $plugin_data['Author'];
        $result->homepage      = $validated_data->homepage;
        $result->download_link = $validated_data->download_url;
        $result->tested        = $validated_data->tested;
        $result->requires      = $validated_data->requires;
        $result->requires_php  = $validated_data->requires_php;
        $result->last_updated  = $validated_data->last_updated;
        $result->sections      = (array) $validated_data->sections;

        return $result;
    }

    public function after_update( $upgrader, $options ) {
        if ( $options['action'] === 'update' && $options['type'] === 'plugin' && isset( $options['plugins'] ) ) {
            if ( in_array( $this->plugin_slug, $options['plugins'] ) ) {
                flush_rewrite_rules();
                // پاک کردن کش بعد از آپدیت موفق
                $this->force_check();
            }
        }
    }

    public function force_check() {
        if ( $this->client ) {
            $this->client->delete_cache();
        }
    }

    public function get_plugin_slug() {
        return $this->plugin_slug;
    }

    private function get_validated_data() {
        if ( null === $this->validated_response ) {
            $raw_data = $this->client->get_update_data();
            $this->validated_response = $this->validator->validate_metadata( $raw_data );
        }
        return $this->validated_response;
    }

    private function get_plugin_data() {
        if ( ! function_exists( 'get_plugin_data' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        return get_plugin_data( $this->plugin_file );
    }
}