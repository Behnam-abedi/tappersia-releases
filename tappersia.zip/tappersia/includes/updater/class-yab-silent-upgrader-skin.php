<?php
defined('ABSPATH') || exit;

if ( ! class_exists( 'WP_Upgrader_Skin' ) ) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
}

class Yab_Silent_Upgrader_Skin extends WP_Upgrader_Skin {
    public $errors = [];

    public function header() {}
    public function footer() {}
    public function feedback( $string, ...$args ) {}
    public function before( $title = '' ) {}
    public function after( $title = '' ) {}

    public function error( $errors ) {
        if ( is_wp_error( $errors ) ) {
            $this->errors = array_merge( $this->errors, $errors->get_error_messages() );
        } elseif ( is_string( $errors ) ) {
            $this->errors[] = $errors;
        }
    }

    public function get_errors() {
        return $this->errors;
    }
}
