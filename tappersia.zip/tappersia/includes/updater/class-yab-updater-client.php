<?php
defined('ABSPATH') || exit;

class Yab_Updater_Client {

    private $metadata_url;

    private $transient_key;

    public function __construct( $plugin_file, $repository_slug = null ) {
        $headers = [
            'GitHub Plugin URI' => 'GitHub Plugin URI',
            'GitHub Branch'     => 'GitHub Branch',
        ];

        $file_data = get_file_data( $plugin_file, $headers );

        if ( ! empty( $repository_slug ) ) {
            $github_uri = $repository_slug;
        } else {
            $github_uri = $file_data['GitHub Plugin URI'] ?? '';
        }

        $branch = $file_data['GitHub Branch'] ?? 'main';

        if ( empty( $github_uri ) ) {
            return;
        }

        $this->metadata_url  = "https://raw.githubusercontent.com/{$github_uri}/{$branch}/update-info.json";
        $this->transient_key = 'yab_updater_cache_' . md5( $github_uri );
    }

    public function get_update_data() {
        if ( empty( $this->metadata_url ) ) {
            return new WP_Error( 'updater_client_no_uri', 'GitHub Repository URI is missing.' );
        }

        $request_url = add_query_arg( 't', time(), $this->metadata_url );

        $response = wp_remote_get( $request_url, [
            'timeout'   => 10,
            'sslverify' => true, 
        ] );

        if ( is_wp_error( $response ) ) {
            return new WP_Error( 'updater_client_request_failed', 'WP_Error: ' . $response->get_error_message() );
        }

        $response_code = wp_remote_retrieve_response_code( $response );
        if ( 200 !== $response_code ) {
            return new WP_Error( 'updater_client_http_error', "GitHub request failed with HTTP code: {$response_code}" );
        }

        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body );

        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return new WP_Error( 'updater_client_json_error', 'Failed to decode JSON.' );
        }

        set_transient( $this->transient_key, $data, 60 );

        return $data;
    }

    public function delete_cache() {
        if ( ! empty( $this->transient_key ) ) {
            delete_transient( $this->transient_key );
        }
    }
}
