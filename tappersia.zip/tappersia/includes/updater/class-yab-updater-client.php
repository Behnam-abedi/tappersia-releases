<?php
// /includes/updater/class-yab-updater-client.php
defined('ABSPATH') || exit;

/**
 * Handles communication with the GitHub repository.
 * Its single responsibility is to fetch and cache the update data.
 */
class Yab_Updater_Client {

    /** @var string The URL to the update-info.json file. */
    private $metadata_url;

    /** @var string The transient cache key. */
    private $transient_key;

    /**
     * Constructor.
     *
     * @param string $plugin_file     Full path to the main plugin file.
     * @param string $repository_slug (Optional) Specific repository slug.
     */
    public function __construct( $plugin_file, $repository_slug = null ) {
        $headers = [
            'GitHub Plugin URI' => 'GitHub Plugin URI',
            'GitHub Branch'     => 'GitHub Branch',
        ];

        $file_data = get_file_data( $plugin_file, $headers );

        if ( ! empty( $repository_slug ) ) {
            $github_uri = $repository_slug;
        } else {
            $github_uri = $file_data['GitHub Plugin URI'] ?? '';
        }

        $branch = $file_data['GitHub Branch'] ?? 'main';

        if ( empty( $github_uri ) ) {
            return;
        }

        $this->metadata_url  = "https://raw.githubusercontent.com/{$github_uri}/{$branch}/update-info.json";
        $this->transient_key = 'yab_updater_cache_' . md5( $github_uri );
    }

    /**
     * Fetches the update data from GitHub.
     * DEBUG MODE: Cache is disabled to ensure we see the latest version immediately.
     */
    public function get_update_data() {
        if ( empty( $this->metadata_url ) ) {
            return new WP_Error( 'updater_client_no_uri', 'GitHub Repository URI is missing.' );
        }

        // --- DEBUG LOGGING ---
        // error_log( "Tappersia Updater: Checking URL: " . $this->metadata_url );

        // 1. (TEMPORARILY DISABLED CACHE FOR DEBUGGING)
        // در حالت پروداکشن واقعی باید این خطوط از کامنت خارج شوند
        // $cached_data = get_transient( $this->transient_key );
        // if ( false !== $cached_data ) {
        //     return $cached_data;
        // }

        // 2. Fetch from GitHub
        // Add timestamp to ensure no server-side caching affects us
        $request_url = add_query_arg( 't', time(), $this->metadata_url );

        $response = wp_remote_get( $request_url, [
            'timeout'   => 10,
            'sslverify' => true, 
        ] );

        // 3. Validate response
        if ( is_wp_error( $response ) ) {
            // error_log( "Tappersia Updater: Request Failed - " . $response->get_error_message() );
            return new WP_Error( 'updater_client_request_failed', 'WP_Error: ' . $response->get_error_message() );
        }

        $response_code = wp_remote_retrieve_response_code( $response );
        if ( 200 !== $response_code ) {
            // error_log( "Tappersia Updater: HTTP Error " . $response_code );
            return new WP_Error( 'updater_client_http_error', "GitHub request failed with HTTP code: {$response_code}" );
        }

        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body );

        if ( json_last_error() !== JSON_ERROR_NONE ) {
            // error_log( "Tappersia Updater: JSON Decode Error" );
            return new WP_Error( 'updater_client_json_error', 'Failed to decode JSON.' );
        }

        // error_log( "Tappersia Updater: Successfully fetched version " . $data->version );

        // 4. Update Cache (Reduced time for testing)
        // کش را روی ۱ دقیقه تنظیم می‌کنیم تا تست راحت‌تر باشد
        set_transient( $this->transient_key, $data, 60 );

        return $data;
    }

    public function delete_cache() {
        if ( ! empty( $this->transient_key ) ) {
            delete_transient( $this->transient_key );
        }
    }
}