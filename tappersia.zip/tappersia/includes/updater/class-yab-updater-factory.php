<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Yab_Updater_Factory {

    /**
     * Builds and returns an instance of the updater checker.
     *
     * @param string $plugin_file    The full path to the main plugin file.
     * @param string $version        The current plugin version.
     * @param string $repository_url (Optional) Custom repository URL for updates.
     * @return Yab_Updater_Checker
     */
    public static function build( $plugin_file, $version, $repository_url = null ) {
        
        // 1. تعیین آدرس مخزن
        if ( empty( $repository_url ) ) {
            $repository_url = 'https://github.com/Behnam-abedi/tappersia';
        }

        $plugin_dir = plugin_dir_path( __FILE__ );

        // 2. لود کردن کلاس‌های مورد نیاز
        if ( ! class_exists( 'Yab_Updater_Client' ) ) {
            require_once $plugin_dir . 'class-yab-updater-client.php';
        }

        if ( ! class_exists( 'Yab_Updater_Checker' ) ) {
            require_once $plugin_dir . 'class-yab-updater-checker.php';
        }

        // 3. ساخت نمونه از کلاینت
        $slug = 'tappersia';
        $client = new Yab_Updater_Client( $repository_url, $slug );

        // 4. ساخت و بازگرداندن چکر (با ۴ پارامتر کامل)
        return new Yab_Updater_Checker( 
            $repository_url, 
            $plugin_file, 
            $client,
            $slug // <--- پارامتر چهارم (اسلاگ) که باعث ارور شده بود اضافه شد
        );
    }
}