<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Yab_Updater_Factory {

    /**
     * Builds and returns an instance of the updater checker.
     *
     * @param string $plugin_file    The full path to the main plugin file.
     * @param string $version        The current plugin version.
     * @param string $repository_url (Optional) Custom repository URL for updates.
     * @return Yab_Updater_Checker
     */
    public static function build( $plugin_file, $version, $repository_url = null ) {
        
        // 1. تعیین آدرس مخزن
        if ( empty( $repository_url ) ) {
            $repository_url = 'https://github.com/Behnam-abedi/tappersia';
        }

        $plugin_dir = plugin_dir_path( __FILE__ );

        // 2. لود کردن کلاس‌های مورد نیاز (اگر لود نشده باشند)
        if ( ! class_exists( 'Yab_Updater_Client' ) ) {
            require_once $plugin_dir . 'class-yab-updater-client.php';
        }

        if ( ! class_exists( 'Yab_Updater_Checker' ) ) {
            require_once $plugin_dir . 'class-yab-updater-checker.php';
        }

        // 3. ساخت اسلاگ و کلاینت
        $slug = 'tappersia';
        $client = new Yab_Updater_Client( $repository_url, $slug );

        // 4. ساخت چکر (با ۴ ورودی کامل)
        return new Yab_Updater_Checker( 
            $repository_url,  // آرگومان ۱
            $plugin_file,     // آرگومان ۲
            $client,          // آرگومان ۳ (شیء کلاینت)
            $slug             // آرگومان ۴ (اسلاگ - این مورد جا افتاده بود)
        );
    }
}