<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Yab_Updater_Factory {

    /**
     * Builds and returns an instance of the updater checker.
     *
     * @param string $plugin_file    The full path to the main plugin file.
     * @param string $version        The current plugin version.
     * @param string $repository_url (Optional) Not used in this version as Client reads from headers.
     * @return Yab_Updater_Checker
     */
    public static function build( $plugin_file, $version, $repository_url = null ) {
        
        $plugin_dir = plugin_dir_path( __FILE__ );

        // 1. لود کردن تمام کلاس‌های مورد نیاز
        if ( ! class_exists( 'Yab_Updater_Client' ) ) {
            require_once $plugin_dir . 'class-yab-updater-client.php';
        }

        if ( ! class_exists( 'Yab_Updater_Validator' ) ) {
            require_once $plugin_dir . 'class-yab-updater-validator.php';
        }

        if ( ! class_exists( 'Yab_Updater_Checker' ) ) {
            require_once $plugin_dir . 'class-yab-updater-checker.php';
        }

        // 2. ساخت کلاینت
        // اصلاح مهم: طبق فایل کلاینت شما، سازنده فقط مسیر فایل پلاگین را می‌گیرد
        // (اطلاعات گیت‌هاب از هدر فایل اصلی خوانده می‌شود)
        $client = new Yab_Updater_Client( $plugin_file );

        // 3. ساخت ولیدیتور
        $validator = new Yab_Updater_Validator();

        // 4. ساخت و بازگرداندن چکر
        // ترتیب آرگومان‌ها باید دقیقاً: فایل، نسخه، کلاینت، ولیدیتور باشد
        return new Yab_Updater_Checker( 
            $plugin_file, 
            $version, 
            $client, 
            $validator 
        );
    }
}