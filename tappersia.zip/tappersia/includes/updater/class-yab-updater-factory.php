<?php


if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


class Yab_Updater_Factory {

    public static function build( $plugin_file, $version, $repository_url = null ) {

        $plugin_dir = plugin_dir_path( __FILE__ );

        if ( ! class_exists( 'Yab_Updater_Client' ) ) {
            require_once $plugin_dir . 'class-yab-updater-client.php';
        }

        if ( ! class_exists( 'Yab_Updater_Validator' ) ) {
            require_once $plugin_dir . 'class-yab-updater-validator.php';
        }

        if ( ! class_exists( 'Yab_Updater_Checker' ) ) {
            require_once $plugin_dir . 'class-yab-updater-checker.php';
        }

        $release_repo_slug = 'Behnam-abedi/tappersia-releases';

        $client = new Yab_Updater_Client( $plugin_file, $release_repo_slug );

        $validator = new Yab_Updater_Validator();

        return new Yab_Updater_Checker( 
            $plugin_file, 
            $version, 
            $client, 
            $validator 
        );
    }
}
