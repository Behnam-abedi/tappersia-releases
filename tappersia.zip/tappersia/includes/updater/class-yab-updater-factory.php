<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Yab_Updater_Factory {

    /**
     * Builds and returns an instance of the updater checker.
     *
     * @param string $plugin_file    The full path to the main plugin file.
     * @param string $version        The current plugin version.
     * @param string $repository_url (Optional) Custom repository URL for updates.
     * @return Yab_Updater_Checker
     */
    public static function build( $plugin_file, $version, $repository_url = null ) {
        
        // 1. تعیین آدرس مخزن
        if ( empty( $repository_url ) ) {
            $repository_url = 'https://github.com/Behnam-abedi/tappersia';
        }

        $plugin_dir = plugin_dir_path( __FILE__ );

        // 2. لود کردن کلاس‌های مورد نیاز
        if ( ! class_exists( 'Yab_Updater_Client' ) ) {
            require_once $plugin_dir . 'class-yab-updater-client.php';
        }

        // لود کردن ولیدیتور (بسیار مهم)
        if ( ! class_exists( 'Yab_Updater_Validator' ) ) {
            require_once $plugin_dir . 'class-yab-updater-validator.php';
        }

        if ( ! class_exists( 'Yab_Updater_Checker' ) ) {
            require_once $plugin_dir . 'class-yab-updater-checker.php';
        }

        // 3. ساخت اشیاء مورد نیاز
        $slug = 'tappersia';
        
        // ساخت کلاینت
        $client = new Yab_Updater_Client( $repository_url, $slug );
        
        // ساخت ولیدیتور (این مورد قبلاً وجود نداشت و باعث ارور می‌شد)
        $validator = new Yab_Updater_Validator();

        // 4. ساخت و بازگرداندن چکر با ترتیب صحیح آرگومان‌ها
        // ترتیب باید دقیقاً: فایل، نسخه، کلاینت، ولیدیتور باشد
        return new Yab_Updater_Checker( 
            $plugin_file, // آرگومان ۱: مسیر فایل پلاگین
            $version,     // آرگومان ۲: نسخه فعلی
            $client,      // آرگومان ۳: شیء کلاینت
            $validator    // آرگومان ۴: شیء ولیدیتور
        );
    }
}