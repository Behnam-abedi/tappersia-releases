<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Yab_Updater_Factory {

    /**
     * Builds and returns an instance of the updater checker.
     *
     * @param string $plugin_file    The full path to the main plugin file.
     * @param string $version        The current plugin version.
     * @param string $repository_url (Optional) Not used directly, passing slug to client instead.
     * @return Yab_Updater_Checker
     */
    public static function build( $plugin_file, $version, $repository_url = null ) {
        
        $plugin_dir = plugin_dir_path( __FILE__ );

        // 1. لود کردن کلاس‌ها
        if ( ! class_exists( 'Yab_Updater_Client' ) ) {
            require_once $plugin_dir . 'class-yab-updater-client.php';
        }

        if ( ! class_exists( 'Yab_Updater_Validator' ) ) {
            require_once $plugin_dir . 'class-yab-updater-validator.php';
        }

        if ( ! class_exists( 'Yab_Updater_Checker' ) ) {
            require_once $plugin_dir . 'class-yab-updater-checker.php';
        }

        // 2. تنظیم آدرس مخزن ریلیز (محل قرارگیری فایل زیپ و جیسون)
        // این آدرس جایگزین هدر فایل می‌شود
        $release_repo_slug = 'Behnam-abedi/tappersia-releases';

        // 3. ساخت کلاینت با آدرس مخزن ریلیز
        $client = new Yab_Updater_Client( $plugin_file, $release_repo_slug );

        // 4. ساخت ولیدیتور
        $validator = new Yab_Updater_Validator();

        // 5. ساخت و بازگرداندن چکر
        return new Yab_Updater_Checker( 
            $plugin_file, 
            $version, 
            $client, 
            $validator 
        );
    }
}