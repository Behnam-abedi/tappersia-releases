<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Yab_Updater_Factory {

    /**
     * Builds and returns an instance of the updater checker.
     *
     * @param string $plugin_file    The full path to the main plugin file.
     * @param string $version        The current plugin version.
     * @param string $repository_url (Optional) Custom repository URL for updates.
     * @return Yab_Updater_Checker
     */
    public static function build( $plugin_file, $version, $repository_url = null ) {
        
        // Default URL fallback (if not provided)
        if ( empty( $repository_url ) ) {
            // Default to the main repo or generic API if needed
            $repository_url = 'https://github.com/Behnam-abedi/tappersia';
        }

        // Ensure the checker class is loaded
        if ( ! class_exists( 'Yab_Updater_Checker' ) ) {
            require_once plugin_dir_path( __FILE__ ) . 'class-yab-updater-checker.php';
        }

        // Instantiate the checker with the custom URL
        // Assuming the constructor signature is: __construct($repositoryUrl, $pluginFile, $slug = '', $checkPeriod = 12, $optionName = '')
        return new Yab_Updater_Checker( 
            $repository_url, 
            $plugin_file, 
            'tappersia' 
        );
    }
}