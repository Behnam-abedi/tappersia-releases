<?php
/**
 * Plugin Name:       Tappersia
 * Plugin URI:        https://www.tappersia.com
 * Description:       An all-in-one WordPress banner management plugin designed for travel agencies, featuring dynamic tour and hotel carousels, flight search widgets, and advanced display controls.
 * Version:           1.1.12
 * Author:            Behnam Abedi
 * Author URI:        abd.behnam@gmail.com
 * GitHub Plugin URI: Behnam-abedi/tappersia
 * GitHub Branch:     main
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       tappersia
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

define( 'YAB_VERSION', '1.1.12' );
define( 'YAB_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'YAB_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

function activate_yab() {
    require_once YAB_PLUGIN_DIR . 'includes/class-activator.php';
    Yab_Activator::activate();
}

function deactivate_yab() {
    require_once YAB_PLUGIN_DIR . 'includes/class-deactivator.php';
    Yab_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_yab' );
register_deactivation_hook( __FILE__, 'deactivate_yab' );

require_once YAB_PLUGIN_DIR . 'includes/class-main.php';

function run_yab() {
    $plugin = new Yab_Main( __FILE__ );
    $plugin->run();
}

run_yab();
