<?php
// tappersia/includes/license/class-yab-license-validator.php
defined('ABSPATH') || exit;

require_once __DIR__ . '/class-yab-api-client.php';

class Yab_License_Validator {

    private $api_client;

    public function __construct() {
        $this->api_client = new Yab_Api_Client();
    }

    /**
     * اعتبارسنجی کلید API
     */
    public function validate_license_key($api_key) {
        $response = $this->api_client->send_validation_request($api_key);

        if (is_wp_error($response)) {
            return ['success' => false, 'status' => 'invalid', 'message' => $response->get_error_message()];
        }

        // بررسی اینکه آیا پاسخ موفقیت‌آمیز بوده است
        if (isset($response['success']) && $response['success'] === true) {
            return [
                'success' => true,
                'status' => 'valid',
                'message' => $response['message'] ?? 'Allowed',
            ];
        }

        return ['success' => false, 'status' => 'invalid', 'message' => 'Validation failed.'];
    }
}