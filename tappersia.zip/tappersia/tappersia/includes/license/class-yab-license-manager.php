<?php
// tappersia/includes/license/class-yab-license-manager.php
defined('ABSPATH') || exit;

require_once __DIR__ . '/class-yab-license-validator.php';

class Yab_License_Manager {

    // نام آپشن‌ها در دیتابیس
    public function get_key_option_name() { return 'yab_license_key'; }
    public function get_status_option_name() { return 'yab_license_status'; }
    public function get_activation_option_name() { return 'yab_needs_activation_redirect'; }

    private $validator;

    public function __construct() {
        $this->validator = new Yab_License_Validator();
    }

    /**
     * دریافت کلید API ذخیره شده
     */
    public function get_api_key() {
        return get_option($this->get_key_option_name(), null);
    }

    /**
     * دریافت وضعیت لایسنس
     */
    public function get_license_status() {
        return get_option($this->get_status_option_name(), [
            'status' => 'invalid',
            'last_checked' => 0,
            'message' => 'License has not been activated.'
        ]);
    }

    /**
     * بررسی اعتبار لایسنس (بدون درخواست مجدد، فقط خواندن از دیتابیس)
     */
    public function is_license_valid() {
        $status_data = $this->get_license_status();
        return (isset($status_data['status']) && $status_data['status'] === 'valid');
    }

    /**
     * تلاش برای فعال‌سازی لایسنس جدید
     */
    public function activate_license($api_key) {
        $result = $this->validator->validate_license_key($api_key);

        if ($result['success'] && isset($result['status']) && $result['status'] === 'valid') {
            // ذخیره کلید و وضعیت موفق
            update_option($this->get_key_option_name(), $api_key);
            update_option($this->get_status_option_name(), [
                'status' => 'valid',
                'last_checked' => time(),
                'message' => $result['message'] ?? 'License activated.'
            ]);
            
            // حذف فلگ ریدایرکت اجباری
            delete_option($this->get_activation_option_name());
            
            // زمان‌بندی بررسی خودکار (Cron Job)
            $this->schedule_license_check();
            
            return ['success' => true, 'message' => 'License activated successfully.'];
        } else {
            // اگر نامعتبر بود، همه چیز را پاک کن
            $this->deactivate_license();
            return ['success' => false, 'message' => $result['message'] ?? 'Invalid API key.'];
        }
    }

    /**
     * غیرفعال‌سازی لایسنس
     */
    public function deactivate_license() {
        delete_option($this->get_key_option_name());
        delete_option($this->get_status_option_name());
        // تنظیم فلگ برای ریدایرکت کاربر به صفحه فعال‌سازی در بازدید بعدی
        update_option($this->get_activation_option_name(), true);
        
        // حذف زمان‌بندی بررسی خودکار
        $this->clear_scheduled_check();
    }

    /**
     * آیا نیاز به ریدایرکت به صفحه فعال‌سازی هست؟
     */
    public function needs_activation_flow() {
        return !$this->is_license_valid();
    }

    // --- متدهای مربوط به Cron Job ---

    /**
     * ثبت زمان‌بندی (اگر وجود نداشته باشد)
     */
    public function schedule_license_check() {
        if (!wp_next_scheduled('yab_daily_license_check_event')) {
            // 'twicedaily' یعنی هر ۱۲ ساعت یکبار
            wp_schedule_event(time(), 'twicedaily', 'yab_daily_license_check_event');
        }
    }

    /**
     * حذف زمان‌بندی
     */
    public function clear_scheduled_check() {
        $timestamp = wp_next_scheduled('yab_daily_license_check_event');
        if ($timestamp) {
            wp_unschedule_event($timestamp, 'yab_daily_license_check_event');
        }
    }

    /**
     * این فانکشن توسط کرون جاب به صورت خودکار اجرا می‌شود
     */
    public function run_automated_check() {
        $api_key = $this->get_api_key();
        if (!$api_key) return;

        $result = $this->validator->validate_license_key($api_key);

        if ($result['success'] && $result['status'] === 'valid') {
            // لایسنس هنوز معتبر است، فقط زمان آخرین بررسی را آپدیت کن
            $current_status = $this->get_license_status();
            $current_status['last_checked'] = time();
            $current_status['status'] = 'valid';
            $current_status['message'] = 'Auto-check: Valid';
            update_option($this->get_status_option_name(), $current_status);
        } else {
            // لایسنس دیگر معتبر نیست
            update_option($this->get_status_option_name(), [
                'status' => 'invalid',
                'last_checked' => time(),
                'message' => 'License expired or revoked during automatic check.'
            ]);
        }
    }
}