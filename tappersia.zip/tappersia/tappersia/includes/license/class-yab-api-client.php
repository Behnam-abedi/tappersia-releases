<?php
// tappersia/includes/license/class-yab-api-client.php
defined('ABSPATH') || exit;

class Yab_Api_Client {

    /**
     * ارسال درخواست اعتبارسنجی به اندپوینت جدید
     * @param string $api_key
     * @return array|WP_Error
     */
    public function send_validation_request($api_key) {
        // ساخت URL بر اساس ساختار جدید: /api/tenant/{API_KEY}/plugin-access
        $url = 'https://b2bapi.tapexplore.com/api/tenant/' . sanitize_text_field($api_key) . '/plugin-access';

        // ارسال درخواست با متد POST
        $response = wp_remote_post($url, [
            'method'    => 'POST',
            'timeout'   => 15,
            'sslverify' => true,
            'body'      => [] // معمولاً بادی خالی است چون کلید در URL است
        ]);

        return $this->handle_response($response);
    }

    /**
     * بررسی پاسخ سرور
     */
    private function handle_response($response) {
        if (is_wp_error($response)) {
            return new WP_Error('api_connection_error', 'API Connection Error: ' . $response->get_error_message());
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        // لاگ کردن برای دیباگ (در صورت نیاز می‌توانید حذف کنید)
        // error_log('License Response: ' . print_r($data, true));

        if ($response_code === 200) {
            // بررسی شرط موفقیت طبق توضیحات شما: code: 100 و success: true
            if (isset($data['success']) && $data['success'] === true && isset($data['code']) && $data['code'] === 100) {
                return ['success' => true, 'valid' => true, 'message' => $data['message'] ?? 'Allowed'];
            } else {
                $message = $data['message'] ?? 'Validation failed.';
                return new WP_Error('api_validation_failed', $message);
            }
        }

        // مدیریت خطاهای HTTP
        $message = $data['message'] ?? 'Server error occurred.';
        return new WP_Error('api_server_error', 'Error ' . $response_code . ': ' . $message);
    }
}