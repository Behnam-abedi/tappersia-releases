<?php

if (!class_exists('Yab_Sticky_Simple_Banner_Renderer')) {
    require_once __DIR__ . '/class-abstract-banner-renderer.php';

    class Yab_Sticky_Simple_Banner_Renderer extends Yab_Abstract_Banner_Renderer {

        public function render(): string {
            if (empty($this->data['sticky_simple'])) {
                return '';
            }
            
            $desktop_b = $this->data['sticky_simple'];
            $mobile_b = $this->data['sticky_simple_mobile'] ?? $desktop_b; 
            $mobile_b['direction'] = $desktop_b['direction'] ?? 'ltr';
            $banner_id = $this->banner_id;
            
            $desktop_hover_color = esc_attr($desktop_b['buttonBgHoverColor'] ?? $desktop_b['buttonBgColor']);
            $mobile_hover_color = esc_attr($mobile_b['buttonBgHoverColor'] ?? $desktop_hover_color);
            
            ob_start();
            ?>
            <style>
                .yab-sticky-simple-banner-wrapper-<?php echo $banner_id; ?> .yab-banner-mobile { display: none; }
                .yab-sticky-simple-banner-wrapper-<?php echo $banner_id; ?> .yab-banner-desktop { display: flex; }
                
                .yab-sticky-simple-banner-wrapper-<?php echo $banner_id; ?> .yab-banner-desktop .yab-sticky-button:hover {
                    background-color: <?php echo $desktop_hover_color; ?> !important;
                }
                
                @media (max-width: 768px) {
                    .yab-sticky-simple-banner-wrapper-<?php echo $banner_id; ?> .yab-banner-desktop { display: none; }
                    .yab-sticky-simple-banner-wrapper-<?php echo $banner_id; ?> .yab-banner-mobile { display: flex; }

                    .yab-sticky-simple-banner-wrapper-<?php echo $banner_id; ?> .yab-banner-mobile .yab-sticky-button:hover {
                        background-color: <?php echo $mobile_hover_color; ?> !important;
                    }
                }
            </style>

            <div class="yab-wrapper yab-sticky-simple-banner-wrapper-<?php echo $banner_id; ?>" style="position: fixed; bottom: 0; left: 0; right: 0; z-index: 99999; width: 100%; direction: ltr;">
                <?php echo $this->render_view($desktop_b, 'desktop', $banner_id, $desktop_b); ?>
                <?php echo $this->render_view($mobile_b, 'mobile', $banner_id, $desktop_b); ?>
            </div>

            <?php
            return ob_get_clean();
        }

        private function render_view($b, $view, $banner_id, $content_source) {
            ob_start();

            $border_style = 'border-radius: ' . esc_attr($b['borderRadius'] ?? 0) . 'px;';
            if (!empty($b['enableBorder']) && $b['enableBorder']) {
                $border_color = $b['borderColor'] ?? ($content_source['borderColor'] ?? '#E0E0E0');
                $border_style .= ' border: ' . esc_attr($b['borderWidth'] ?? 1) . 'px solid ' . esc_attr($border_color) . ';';
            } else {
                $border_style .= ' border: none;';
            }

            $text_color = esc_attr($b['textColor'] ?? $content_source['textColor']);
            $button_bg_color = esc_attr($b['buttonBgColor'] ?? $content_source['buttonBgColor']);
            $button_text_color = esc_attr($b['buttonTextColor'] ?? $content_source['buttonTextColor']);
            
            $text = esc_html($content_source['text']);
            $button_text = esc_html($content_source['buttonText']);
            $button_link = esc_url($content_source['buttonLink']);

            ?>
            <div class="yab-banner-item yab-banner-<?php echo $view; ?>" 
                 style="width: 100%; 
                        height: auto; 
                        min-height: <?php echo esc_attr($b['minHeight']); ?>px;
                        <?php echo $border_style; ?> 
                        <?php echo $this->get_background_style($b); ?>;
                        padding: <?php echo esc_attr($b['paddingY']); ?>px <?php echo esc_attr($b['paddingX'] . ($b['paddingXUnit'] ?? 'px')); ?>;
                        align-items: center;
                        justify-content: space-between;
                        box-sizing: border-box;
                        flex-direction: <?php echo ($b['direction'] === 'rtl') ? 'row-reverse' : 'row'; ?>;
                        gap: 15px;
                        ">
                <span style="font-size: <?php echo esc_attr($b['textSize']); ?>px;
                             font-weight: <?php echo esc_attr($b['textWeight']); ?>;
                             color: <?php echo $text_color; ?>;
                             flex-grow: 1;
                             max-width: <?php echo esc_attr(($b['contentWidth'] ?? 100) . ($b['contentWidthUnit'] ?? '%')); ?>;
                             text-align: <?php echo esc_attr($b['direction'] === 'rtl' ? 'right' : 'left'); ?>;">
                    <?php echo $text; ?>
                </span>
                <a href="<?php echo $button_link; ?>" 
                   target="_blank" 
                   class="yab-sticky-button" 
                   style="background-color: <?php echo $button_bg_color; ?>;
                          border-radius: <?php echo esc_attr($b['buttonBorderRadius']); ?>px!important;
                          color: <?php echo $button_text_color; ?>!important;
                          font-size: <?php echo esc_attr($b['buttonFontSize']); ?>px!important;
                          font-weight: <?php echo esc_attr($b['buttonFontWeight']); ?>!important;
                          padding: <?php echo esc_attr($b['buttonPaddingY']); ?>px <?php echo esc_attr($b['buttonPaddingX']); ?>px!important;
                          min-width: <?php echo esc_attr($b['buttonMinWidth']); ?>px;
                          text-decoration: none;
                          text-align: center;
                          box-sizing: border-box;
                          flex-shrink: 0;
                          line-height: 1;
                          transition: background-color 0.3s; 
                          ">
                    <?php echo $button_text; ?>
                </a>
            </div>
            <?php
            return ob_get_clean();
        }
    }
}
