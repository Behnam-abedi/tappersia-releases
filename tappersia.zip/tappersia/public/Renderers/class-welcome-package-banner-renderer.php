<?php

if (!class_exists('Yab_Welcome_Package_Banner_Renderer')) {
    require_once __DIR__ . '/class-abstract-banner-renderer.php';

    class Yab_Welcome_Package_Banner_Renderer extends Yab_Abstract_Banner_Renderer {

        public function render(): string {
            if (empty($this->data['welcome_package']) || empty($this->banner_id)) {
                return '';
            }

            $banner_id = $this->banner_id;
            $placeholder_id = "yab-wp-banner-placeholder-" . $banner_id;

            ob_start();
            ?>
            <div id="<?php echo esc_attr($placeholder_id); ?>" class="yab-wp-banner-placeholder yab-skeleton-loader" style="width: 100%; min-height: 100px; background-color: #f4f4f4; border-radius: 8px; margin: 20px 0;">
                <div style="padding: 20px; text-align: center; color: #ccc;">Loading banner...</div>
            </div>

            <script>
            document.addEventListener('DOMContentLoaded', function() {
                const placeholder_<?php echo $banner_id; ?> = document.getElementById('<?php echo esc_js($placeholder_id); ?>');
                if (!placeholder_<?php echo $banner_id; ?>) return;

                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        'action': 'yab_render_welcome_package_ssr',
                        'banner_id': '<?php echo $banner_id; ?>'
                    })
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.json();
                 })
                .then(result => {
                    if (result.success && result.data && result.data.html) {
                        placeholder_<?php echo $banner_id; ?>.innerHTML = result.data.html;
                        placeholder_<?php echo $banner_id; ?>.classList.remove('yab-skeleton-loader');
                        placeholder_<?php echo $banner_id; ?>.style.minHeight = '';
                        placeholder_<?php echo $banner_id; ?>.style.backgroundColor = '';
                        placeholder_<?php echo $banner_id; ?>.style.borderRadius = '';

                        const scripts = placeholder_<?php echo $banner_id; ?>.querySelectorAll('script');
                        scripts.forEach(oldScript => {
                            const newScript = document.createElement('script');
                            Array.from(oldScript.attributes).forEach(attr => {
                                newScript.setAttribute(attr.name, attr.value);
                            });
                            newScript.textContent = oldScript.textContent;
                            oldScript.parentNode.replaceChild(newScript, oldScript);
                        });

                    } else {
                        console.error('Failed to load Welcome Package banner:', result.data ? result.data.message : 'Unknown error');
                        placeholder_<?php echo $banner_id; ?>.innerHTML = '';
                        placeholder_<?php echo $banner_id; ?>.classList.remove('yab-skeleton-loader');
                    }
                })
                .catch(error => {
                    console.error('Error fetching Welcome Package banner:', error);
                    placeholder_<?php echo $banner_id; ?>.innerHTML = '';
                    placeholder_<?php echo $banner_id; ?>.classList.remove('yab-skeleton-loader');
                });
            });
            </script>
            <style>
                .yab-wp-banner-placeholder.yab-skeleton-loader { position: relative; overflow: hidden; }
                .yab-wp-banner-placeholder.yab-skeleton-loader::before {
                    content: ''; position: absolute; inset: 0; transform: translateX(-100%);
                    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.6), transparent);
                    animation: yab-shimmer-wp-<?php echo $banner_id; ?> 1.5s infinite;
                }
                @keyframes yab-shimmer-wp-<?php echo $banner_id; ?> { 100% { transform: translateX(100%); } }
            </style>
            <?php
            return ob_get_clean();
        }
    }
}
