<?php


if (!class_exists('Yab_Flight_Ticket_Renderer')) {
    require_once __DIR__ . '/class-abstract-banner-renderer.php';

    
    class Yab_Flight_Ticket_Renderer extends Yab_Abstract_Banner_Renderer {

        public function render(): string {
            
            if (empty($this->data['flight_ticket']) || empty($this->banner_id)) {
                return '';
            }

            $banner_id = $this->banner_id;
            $placeholder_id = "yab-flight-ticket-placeholder-" . $banner_id;

            
            $desktop_design = $this->data['flight_ticket']['design'] ?? [];
            $mobile_design = $this->data['flight_ticket']['design_mobile'] ?? $desktop_design;

            $desktop_height = esc_attr($desktop_design['minHeight'] ?? 150) . 'px';
            $desktop_radius = esc_attr($desktop_design['borderRadius'] ?? 16) . 'px';

            $mobile_height = esc_attr($mobile_design['minHeight'] ?? 70) . 'px';
            $mobile_radius = esc_attr($mobile_design['borderRadius'] ?? 8) . 'px';
            

            ob_start();
            ?>
            
            <div id="<?php echo esc_attr($placeholder_id); ?>" class="yab-flight-ticket-placeholder " style="width: 100%; position: relative;">
                
                <div class="yab-ft-skeleton-desktop" style=" flex-direction:row; align-items:center; justify-content:space-between; width: 100%; height: <?php echo $desktop_height; ?>; background-color: #f4f4f4; border-radius: 16px; margin: 0; padding: <?php echo esc_attr($desktop_design['padding'] ?? 12); ?>px; box-sizing: border-box;">
                    <div style="width:40%; height: 90%; background-color: #ebebeb; border-radius:10px; margin-right: 20px;" class=" yab-skeleton-loader"></div>
                    <div style="width:30%; height:129px; background-color: #ebebeb; border-radius:10px; flex-shrink: 0;" class=" yab-skeleton-loader"></div>
                </div>

                <div class="yab-ft-skeleton-mobile" style="flex-direction:row; align-items:center; justify-content:space-between;padding:0 5px; width: 100%; height: <?php echo $mobile_height; ?>; background-color: #f4f4f4; border-radius:8px; margin: 0;  box-sizing: border-box;">
                    <div style="width:40%; height: 80%; background-color: #ebebeb; border-radius:8px; " class=" yab-skeleton-loader"></div>
                    
                    <div style="width:30%; height:60px; background-color: #ebebeb; border-radius:8px; flex-shrink: 0;" class=" yab-skeleton-loader"></div>
                </div>

            </div>
            
            <script>
            document.addEventListener('DOMContentLoaded', function() {
                const placeholder_<?php echo $banner_id; ?> = document.getElementById('<?php echo esc_js($placeholder_id); ?>');
                if (!placeholder_<?php echo $banner_id; ?>) return;

                
                const today = new Date();
                const tomorrow = new Date(today);
                tomorrow.setDate(today.getDate() + 1);

                const yyyy = tomorrow.getFullYear();
                const mm = String(tomorrow.getMonth() + 1).padStart(2, '0');
                const dd = String(tomorrow.getDate()).padStart(2, '0');
                const tomorrowDateString = `${yyyy}-${mm}-${dd}`;
                
                
                const isMobileClient = window.innerWidth <= 768;
                

                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        'action': 'yab_render_flight_ticket_ssr',
                        'banner_id': '<?php echo $banner_id; ?>',
                        'local_departure_date': tomorrowDateString,
                        'is_mobile': isMobileClient ? '1' : '0'
                    })
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.json();
                 })
                .then(result => {
                    if (result.success && result.data && result.data.html) {
                        placeholder_<?php echo $banner_id; ?>.innerHTML = result.data.html;
                        
                        placeholder_<?php echo $banner_id; ?>.classList.remove('yab-skeleton-loader');
                        placeholder_<?php echo $banner_id; ?>.style.minHeight = '';
                        placeholder_<?php echo $banner_id; ?>.style.backgroundColor = '';
                        placeholder_<?php echo $banner_id; ?>.style.borderRadius = '';
                        placeholder_<?php echo $banner_id; ?>.style.margin = '';
                        placeholder_<?php echo $banner_id; ?>.style.maxWidth = '';
                        placeholder_<?php echo $banner_id; ?>.style.position = '';
                        placeholder_<?php echo $banner_id; ?>.style.overflow = '';

                    } else {
                        console.error('Tappersia: Failed to load Flight Ticket banner:', result.data ? result.data.message : 'Unknown error');
                        placeholder_<?php echo $banner_id; ?>.innerHTML = '';
                        placeholder_<?php echo $banner_id; ?>.classList.remove('yab-skeleton-loader');
                    }
                })
                .catch(error => {
                    console.error('Tappersia: Error fetching Flight Ticket banner:', error);
                    placeholder_<?php echo $banner_id; ?>.innerHTML = '';
                    placeholder_<?php echo $banner_id; ?>.classList.remove('yab-skeleton-loader');
                });
            });
            </script>
            
            <style>
                .yab-flight-ticket-placeholder .yab-ft-skeleton-mobile { display: none; }
                .yab-flight-ticket-placeholder .yab-ft-skeleton-desktop { display: flex; }
                .yab-flight-ticket-placeholder{border-radius:16px}
                @media (max-width: 768px) {
                    .yab-flight-ticket-placeholder .yab-ft-skeleton-desktop { display: none; }
                    .yab-flight-ticket-placeholder .yab-ft-skeleton-mobile { display: flex; }
                    .yab-flight-ticket-placeholder{border-radius:8px}
                }
                .yab-flight-ticket-placeholder.yab-skeleton-loader {
                    position: relative; 
                    overflow: hidden; 
                    background-color: #f4f4f4;
                }
                .yab-flight-ticket-placeholder.yab-skeleton-loader .yab-skeleton-inner {
                     position: relative;
                     overflow: hidden;
                     background-color: #ebebeb;
                }
                .yab-flight-ticket-placeholder.yab-skeleton-loader .yab-skeleton-inner::before {
                    content: ''; 
                    position: absolute; 
                    inset: 0; 
                    transform: translateX(-100%);
                    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.6), transparent);
                    animation: yab-shimmer-ft-<?php echo $banner_id; ?> 1.5s infinite;
                }
                 @keyframes yab-shimmer-ft-<?php echo $banner_id; ?> { 
                    100% { transform: translateX(100%); } 
                 }
            </style>
            <?php
            return ob_get_clean();
        }
    }
}
