<?php

if (!class_exists('Yab_Tour_Carousel_Renderer')) {
    require_once __DIR__ . '/class-abstract-banner-renderer.php';

    class Yab_Tour_Carousel_Renderer extends Yab_Abstract_Banner_Renderer {

        public function render(): string {
            if (empty($this->data['tour_carousel']) || empty($this->data['tour_carousel']['selectedTours'])) {
                return '';
            }

            $banner_id = $this->banner_id;
            $desktop_settings = $this->data['tour_carousel']['settings'] ?? [];
            $mobile_settings = $this->data['tour_carousel']['settings_mobile'] ?? $desktop_settings;
            $original_tours_ids = $this->data['tour_carousel']['selectedTours'];
            
            ob_start();
            ?>
            <style>
                .yab-tour-carousel-wrapper-<?php echo $banner_id; ?> .yab-tour-carousel-mobile { display: none; }
                .yab-tour-carousel-wrapper-<?php echo $banner_id; ?> .yab-tour-carousel-desktop { display: block; }
                
                @media (max-width: 768px) {
                    .yab-tour-carousel-wrapper-<?php echo $banner_id; ?> .yab-tour-carousel-desktop { display: none; }
                    .yab-tour-carousel-wrapper-<?php echo $banner_id; ?> .yab-tour-carousel-mobile { display: block; }
                }
            </style>
            <div class="yab-tour-carousel-wrapper-<?php echo $banner_id; ?>">
                <div class="yab-tour-carousel-desktop">
                    <?php echo $this->render_view($banner_id, 'desktop', $desktop_settings, $original_tours_ids); ?>
                </div>
                <div class="yab-tour-carousel-mobile">
                    <?php echo $this->render_view($banner_id, 'mobile', $mobile_settings, $original_tours_ids); ?>
                </div>
            </div>
            <?php
            return ob_get_clean();
        }

        private function render_view($banner_id, $view, $settings, $original_tours_ids) {
            $header_settings = $settings['header'] ?? [];
            $card_settings = $settings['card'] ?? [];
            $tour_count = count($original_tours_ids);
            
            $responsive_slides = $settings['responsiveSlides'] ?? false;

            $slides_per_view = $settings['slidesPerView'] ?? 3;
            $space_between = $settings['spaceBetween'] ?? 18;
            $auto_gap = $settings['autoGap'] ?? false;
            
            $row_gap = $settings['rowGap'] ?? 20;

            $loop = $settings['loop'] ?? false;
            $is_doubled = $settings['isDoubled'] ?? false;
            $direction = $settings['direction'] ?? 'ltr';
            $is_rtl = $direction === 'rtl';
            $grid_fill = $settings['loop'] ? 'column' : ($settings['gridFill'] ?? 'column');
            
            $autoplay_enabled = $settings['autoplay']['enabled'] ?? false;
            $autoplay_delay = $settings['autoplay']['delay'] ?? 3000;
            $navigation_enabled = $settings['navigation']['enabled'] ?? true;
            $pagination_enabled = $settings['pagination']['enabled'] ?? true;
            $pagination_color = $settings['pagination']['paginationColor'] ?? '#00BAA44F';
            $pagination_active_color = $settings['pagination']['paginationActiveColor'] ?? '#00BAA4';

            // اگر حالت ریسپانسیو فعال است، برای محاسبه لوپ حداکثر تعداد (۵) را در نظر می‌گیریم
            $slides_per_view_calc = $responsive_slides ? 5 : $slides_per_view;

            $slides_to_render = $original_tours_ids;

            if ($loop && $tour_count > 0) {
                $final_tours = $original_tours_ids;
                if ($is_doubled) {
                    $min_loop_count = (2 * $slides_per_view_calc) + 2;
                    while (count($final_tours) < $min_loop_count) {
                        $final_tours = array_merge($final_tours, $original_tours_ids);
                    }
                } else {
                    $min_loop_count = $slides_per_view_calc * 2;
                    while (count($final_tours) < $min_loop_count) {
                        $final_tours = array_merge($final_tours, $original_tours_ids);
                    }
                }
                $slides_to_render = $final_tours;
            }

            $card_width = $settings['cardWidth'] ?? 295;
            
            if ($auto_gap || $responsive_slides) {
                $container_max_width = '100%';
            } else {
                $container_style_width = ($view === 'desktop' || $slides_per_view > 1)
                    ? (($card_width * $slides_per_view) + ($space_between * ($slides_per_view - 1))) . 'px'
                    : $card_width . 'px';
                $container_max_width = $container_style_width;
            }
            
            // در اینجا 'height' به عنوان min-height استفاده می‌شود
            $card_height = $card_settings['height'] ?? 375;
            
            $grid_height_css = $is_doubled ? ( 'height: ' . (($card_height * 2) + $row_gap) . 'px;' ) : '';
            
            $unique_id = $banner_id . '_' . $view;

            ob_start();
            ?>
            <style>
                <?php if (!$responsive_slides): ?>
                #yab-tour-carousel-<?php echo esc_attr($unique_id); ?> .swiper-slide { 
                    width: <?php echo esc_attr($card_width); ?>px !important; 
                }
                <?php endif; ?>

                #yab-tour-carousel-<?php echo esc_attr($unique_id); ?> .swiper-slide { 
                    box-sizing: border-box;
                    height: auto !important; 
                    margin-top: 0 !important;
                }
                
                <?php if ($is_doubled): ?>
                #yab-tour-carousel-<?php echo esc_attr($unique_id); ?> .swiper-slide {
                    height: calc((100% - <?php echo esc_attr($row_gap); ?>px) / 2) !important;
                }
                #yab-tour-carousel-<?php echo esc_attr($unique_id); ?> .swiper-wrapper {
                    align-content: flex-start;
                    row-gap: <?php echo esc_attr($row_gap); ?>px !important;
                    flex-direction: column !important;
                }
                <?php else: ?>
                #yab-tour-carousel-<?php echo esc_attr($unique_id); ?> .swiper-slide {
                     height: 100% !important;
                }
                <?php endif; ?>

                #yab-tour-carousel-<?php echo esc_attr($unique_id); ?> .tappersia-carusel-next, 
                #yab-tour-carousel-<?php echo esc_attr($unique_id); ?> .tappersia-carusel-perv { 
                    background: white; border-radius: 8px; box-shadow: inset 0 0 0 2px #E5E5E5; 
                    display: flex; align-items: center; justify-content: center; 
                    z-index: 10; cursor: pointer; width: 36px; height: 36px; 
                }
                #yab-tour-carousel-<?php echo esc_attr($unique_id); ?> .tappersia-carusel-next {
                    <?php echo $is_rtl ? 'padding-left: 2px' : 'padding-right: 4px'; ?>
                }
                #yab-tour-carousel-<?php echo esc_attr($unique_id); ?> .tappersia-carusel-perv {
                    <?php echo $is_rtl ? 'padding-right: 4px' : 'padding-left: 4px'; ?>
                }
                #yab-tour-carousel-<?php echo esc_attr($unique_id); ?> .tappersia-carusel-perv > div { 
                    transform: rotate(<?php echo $is_rtl ? '45deg' : '-135deg'; ?>); 
                }
                #yab-tour-carousel-<?php echo esc_attr($unique_id); ?> .tappersia-carusel-next > div { 
                    transform: rotate(<?php echo $is_rtl ? '-135deg' : '45deg'; ?>); 
                }
                 #yab-tour-carousel-<?php echo esc_attr($unique_id); ?> .tappersia-carusel-next > div, 
                #yab-tour-carousel-<?php echo esc_attr($unique_id); ?> .tappersia-carusel-perv > div { 
                    width: 10px; height: 10px; 
                    border-top: 2px solid black; border-right: 2px solid black; border-radius: 2px; 
                }
                .is-loaded .yab-tour-card { animation: yab-fade-in 0.5s ease-in-out; }

                #yab-tour-carousel-<?php echo esc_attr($unique_id); ?> .swiper-pagination-bullet {
                    background-color: <?php echo esc_attr($pagination_color); ?> !important;
                }
                #yab-tour-carousel-<?php echo esc_attr($unique_id); ?> .swiper-pagination-bullet-active {
                    background-color: <?php echo esc_attr($pagination_active_color); ?> !important;
                }
            </style>
            <div id="yab-tour-carousel-<?php echo esc_attr($unique_id); ?>" dir="<?php echo esc_attr($direction); ?>">
                <div style="max-width: <?php echo esc_attr($container_max_width); ?>; margin: 0 auto; position: relative;">
                    <?php if(!empty($header_settings['text'])): ?>
                    <div style="margin-bottom: <?php echo esc_attr($header_settings['marginTop'] ?? 28); ?>px;">
                         <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 13px;">
                            <span style="font-size: <?php echo esc_attr($header_settings['fontSize'] ?? 24); ?>px; font-weight: <?php echo esc_attr($header_settings['fontWeight'] ?? '700'); ?>; color: <?php echo esc_attr($header_settings['color'] ?? '#000000'); ?>;"><?php echo esc_html($header_settings['text']); ?></span>
                            <?php if ($navigation_enabled): ?>
                            <div style="display: flex; gap: 7px; align-items: center;">
                               <div class="tappersia-carusel-perv"><div></div></div>
                               <div class="tappersia-carusel-next"><div></div></div>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div style="position: relative; text-align: <?php echo $is_rtl ? 'right' : 'left'; ?>;">
                            <div style="width: 100%; height: 1px; background-color: #E2E2E2; border-radius: 2px;"></div>
                            <div style="position: absolute; margin-top: -2px; width: 15px; height: 2px; background-color: <?php echo esc_attr($header_settings['lineColor'] ?? '#00BAA4'); ?>; border-radius: 2px; <?php echo $is_rtl ? 'right: 0;' : 'left: 0;'; ?>"></div>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <div class="swiper" style="overflow: hidden; padding-bottom: 10px; <?php echo $grid_height_css; ?>">
                        <div class="swiper-wrapper">
                            <?php 
                            $card_height_esc = esc_attr($card_settings['height'] ?? 375);
                            $image_height_esc = esc_attr($card_settings['imageHeight'] ?? 204);
                            
                            // اضافه کردن min-height به اسکلتون
                            $skeleton_html = <<<HTML
                                <div class="yab-tour-card-skeleton yab-skeleton-loader" style="width: {$card_width}px; height: 100%; min-height: {$card_height_esc}px; background-color: #f4f4f4; border-radius: 14px; padding: 9px; display: flex; flex-direction: column; gap: 9px; overflow: hidden;">
                                    <div class="yab-skeleton-image" style="width: 100%; height: {$image_height_esc}px; background-color: #ebebeb; border-radius: 14px;"></div>
                                    <div style="padding: 14px 5px 5px 5px; display: flex; flex-direction: column; gap: 10px; flex-grow: 1;">
                                        <div class="yab-skeleton-text" style="width: 80%; height: 20px; background-color: #ebebeb; border-radius: 4px;"></div>
                                        <div class="yab-skeleton-text" style="width: 40%; height: 16px; background-color: transparent; border-radius: 4px;"></div>
                                        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: auto; padding-bottom: 5px;">
                                            <div class="yab-skeleton-text" style="width: 40%; height: 20px; background-color: #ebebeb; border-radius: 4px;"></div>
                                            <div class="yab-skeleton-text" style="width: 30%; height: 16px; background-color: #ebebeb; border-radius: 4px;"></div>
                                        </div>
                                        <div class="yab-skeleton-text" style="height: 33px; width: 100%; margin-top: 10px; background-color: #ebebeb; border-radius: 4px;"></div>
                                    </div>
                                </div>
HTML;
                            foreach ($slides_to_render as $tour_id) : ?>
                                <div class="swiper-slide" data-tour-id="<?php echo esc_attr($tour_id); ?>">
                                    <?php echo $skeleton_html; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php if ($pagination_enabled): ?>
                    <div class="swiper-pagination" style="position: static; margin-top: 10px;"></div>
                    <?php endif; ?>
                </div>
            </div>
            <script>
            document.addEventListener('DOMContentLoaded', function() {
                var container = document.getElementById('yab-tour-carousel-<?php echo esc_js($unique_id); ?>');
                if (!container || container.swiperInitialized) return;
                container.swiperInitialized = true;
                
                const swiperEl = container.querySelector('.swiper');
                const fetchedIds = new Set();
                const isRTL = <?php echo json_encode($is_rtl); ?>;
                const cardSettings = <?php echo json_encode($card_settings); ?>;
                const cardWidth = <?php echo esc_js($card_width); ?>;
                const cardHeight = <?php echo esc_js($card_height_esc); ?>;

                const slidesPerView = <?php echo esc_js($slides_per_view); ?> || 3;
                const autoGap = <?php echo json_encode($auto_gap); ?>;
                const isDoubled = <?php echo json_encode($is_doubled); ?>;
                const rowGap = <?php echo esc_js($row_gap); ?>;
                
                const responsiveSlides = <?php echo json_encode($responsive_slides); ?>;

                const calculateGap = () => {
                    if (!autoGap) return <?php echo esc_js($space_between); ?>;
                    const containerWidth = container.offsetWidth || container.clientWidth;
                    if (!containerWidth) return <?php echo esc_js($space_between); ?>;
                    if (slidesPerView <= 1) return 0;
                    const totalCardWidth = cardWidth * slidesPerView;
                    const remainingSpace = containerWidth - totalCardWidth;
                    const gap = remainingSpace / (slidesPerView - 1);
                    return Math.max(0, gap);
                };
                
                let spaceBetween = calculateGap();

                const updateGridHeight = () => {
                    if (isDoubled) {
                        const totalHeight = (cardHeight * 2) + rowGap;
                        swiperEl.style.height = totalHeight + 'px';
                    } else {
                        swiperEl.style.height = 'auto';
                    }
                };
                
                updateGridHeight();

                const getCardBackground = (settings) => { if (!settings) return '#FFFFFF'; if (settings.backgroundType === 'gradient') { const stops = (settings.gradientStops || []).map(s => `${s.color} ${s.stop}%`).join(', '); return `linear-gradient(${settings.gradientAngle || 90}deg, ${stops})`; } return settings.bgColor || '#FFFFFF'; };
                const escapeHTML = (str) => { if (!str) return ''; return String(str).replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m])); };

                const generateTourCardHTML = (tour) => {
                    if (!tour) return '';
                    const salePrice = tour.salePrice != null ? tour.salePrice.toFixed(2) : (tour.price != null ? tour.price.toFixed(2) : '0.00');
                    const rate = tour.rate != null ? tour.rate.toFixed(1) : '0.0';
                    const rateCount = tour.rateCount != null ? tour.rateCount : 0;
                    const durationDays = tour.durationDays != null ? tour.durationDays : '?';
                    const startProvinceName = tour.startProvince?.name || 'N/A';
                    const detailUrl = tour.detailUrl || '#';
                    const bannerImageUrl = tour.bannerImage?.url || 'https://placehold.co/276x204/e0e0e0/cccccc?text=No+Image';

                    const rtlFlex = isRTL ? 'row-reverse' : 'row';
                    const rtlTextAlign = isRTL ? 'right' : 'left';
                    const rtlArrow = isRTL ? '-135deg' : '45deg';
                    const provincePos = isRTL ? `left: ${cardSettings.province.side}px;` : `right: ${cardSettings.province.side}px;`;
                    
                    const buttonBgColor = escapeHTML(cardSettings.button.bgColor || '#00BAA4');
                    const buttonBgHoverColor = escapeHTML(cardSettings.button.BgHoverColor || buttonBgColor);
                    
                    const titleMarginTop = cardSettings.title.marginTop ? cardSettings.title.marginTop + 'px' : '0';
                    const infoMarginTop = (cardSettings.infoRow && cardSettings.infoRow.marginTop !== null && cardSettings.infoRow.marginTop !== '') ? cardSettings.infoRow.marginTop + 'px' : 'auto';
                    const infoMarginBottom = (cardSettings.infoRow && cardSettings.infoRow.marginBottom) ? cardSettings.infoRow.marginBottom + 'px' : '10px';
                    const btnMarginBottom = cardSettings.button.marginBottom ? cardSettings.button.marginBottom + 'px' : '0';
                    const btnWidth = cardSettings.button.width ? cardSettings.button.width + (cardSettings.button.widthUnit || '%') : '100%';
                    
                    const widthStyle = responsiveSlides ? 'width: 100%;' : `width: ${cardWidth}px;`;
                    
                    // اضافه شدن min-height به استایل کارت
                    return `
                    <div class="yab-tour-card" style="position: relative; text-decoration: none; color: inherit; display: block; ${widthStyle} height: 100%; min-height: ${cardSettings.height}px; background: ${getCardBackground(cardSettings)}; border: ${cardSettings.borderWidth}px solid ${cardSettings.borderColor}; border-radius: ${cardSettings.borderRadius}px; overflow: hidden; display: flex; flex-direction: column; padding: ${cardSettings.padding}px; direction: ${isRTL ? 'rtl' : 'ltr'}; box-sizing: border-box;">
                        <a href="${escapeHTML(detailUrl)}" target="_blank" style="flex:1;text-decoration: none; color: inherit; display: flex; flex-direction: column; height: 100%; outline: none; -webkit-tap-highlight-color: transparent;">
                            <div style="position: relative; width: 100%; height: ${cardSettings.imageHeight}px; flex-shrink: 0;">
                                <img src="${escapeHTML(bannerImageUrl)}" alt="${escapeHTML(tour.title)}" style="width: 100%; height: 100%; object-fit: cover; border-radius: ${cardSettings.borderRadius > 2 ? cardSettings.borderRadius - 2 : cardSettings.borderRadius}px;" />
                                <div style="position: absolute; bottom: ${cardSettings.province.bottom}px; ${provincePos} min-height: 23px; display: flex; align-items: center; justify-content: center; border-radius: 29px; background: ${cardSettings.province.bgColor}; padding: 0 11px; backdrop-filter: blur(${cardSettings.province.blur}px);">
                                    <span style="color: ${cardSettings.province.color}; font-size: ${cardSettings.province.fontSize}px; font-weight: ${cardSettings.province.fontWeight}; line-height: 24px;">${escapeHTML(startProvinceName)}</span>
                                </div>
                            </div>
                            <div style="display: flex; flex-direction: column; justify-content: space-between; flex-grow: 1; padding: 14px 5px 5px 5px; text-align: ${rtlTextAlign}; min-height: 0;">
                                <div style="margin-top: ${titleMarginTop};">
                                    <h4 style="font-weight: ${cardSettings.title.fontWeight}; font-size: ${cardSettings.title.fontSize}px; line-height: ${cardSettings.title.lineHeight}; color: ${cardSettings.title.color}; text-overflow: ellipsis; overflow: hidden; display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 2; margin: 0;">${escapeHTML(tour.title)}</h4>
                                </div>
                                <div style="margin-top: ${infoMarginTop}; margin-bottom: ${infoMarginBottom}; display: flex; align-items: center; justify-content: space-between; padding: 0 4px; direction:ltr; flex-direction: ${rtlFlex};">
                                    <div style="display: flex; flex-direction: row; gap: 4px; align-items: baseline;">
                                        <span style="font-size: ${cardSettings.price.fontSize}px; font-weight: ${cardSettings.price.fontWeight}; color: ${cardSettings.price.color};">€${salePrice}</span>
                                        <span style="font-size: ${cardSettings.duration.fontSize}px; font-weight: ${cardSettings.duration.fontWeight}; color: ${cardSettings.duration.color};">/${durationDays} Days</span>
                                    </div>
                                    <div style="display: flex; flex-direction: row; gap: 5px; align-items: baseline;">
                                        <span style="font-size: ${cardSettings.rating.fontSize}px; font-weight: ${cardSettings.rating.fontWeight}; color: ${cardSettings.rating.color};">${rate}</span>
                                        <span style="font-size: ${cardSettings.reviews.fontSize}px; font-weight: ${cardSettings.reviews.fontWeight}; color: ${cardSettings.reviews.color};">(${rateCount} Reviews)</span>
                                    </div>
                                </div>
                                <div style="padding: 0 4px; flex-shrink: 0; margin-bottom: ${btnMarginBottom}; display: flex; justify-content: start;">
                                    <div style="direction:ltr; display:flex; height: 33px; width: ${btnWidth}; align-items: center; justify-content: space-between; border-radius: 5px; background-color: ${buttonBgColor}; padding: 0 20px; text-decoration: none; flex-direction: ${rtlFlex}; box-sizing: border-box; transition: background-color 0.3s;" onmouseover="this.style.backgroundColor='${buttonBgHoverColor}'" onmouseout="this.style.backgroundColor='${buttonBgColor}'">
                                        <span style="font-size: ${cardSettings.button.fontSize}px; font-weight: ${cardSettings.button.fontWeight}; color: ${cardSettings.button.color};">View More</span>
                                        <div style="width: ${cardSettings.button.arrowSize}px; height: ${cardSettings.button.arrowSize}px; border-top: 2px solid ${cardSettings.button.color}; border-right: 2px solid ${cardSettings.button.color}; transform: rotate(${rtlArrow}); border-radius: 2px;"></div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>`;
                };
                
                const fetchTourData = (idsToFetch, retries = 2) => {
                    const uniqueIds = Array.from(new Set(idsToFetch)).filter(id => !fetchedIds.has(id));
                    if (uniqueIds.length === 0) return;
                    uniqueIds.forEach(id => fetchedIds.add(id));
                    const body = new URLSearchParams();
                    body.append('action', 'yab_fetch_tour_details_by_ids');
                    uniqueIds.forEach(id => { body.append('tour_ids[]', id); });

                    fetch('<?php echo admin_url('admin-ajax.php'); ?>', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: body }).then(r => r.ok ? r.json() : Promise.reject(`HTTP error! status: ${r.status}`)).then(res => { if(res.success && Array.isArray(res.data)) { res.data.forEach(tour => { if (!tour || !tour.id) return; container.querySelectorAll(`.swiper-slide[data-tour-id="${tour.id}"]`).forEach(slide => { if(slide.querySelector('.yab-tour-card-skeleton')) { const image = new Image(); const imageUrl = tour.bannerImage?.url || 'https://placehold.co/276x204/e0e0e0/cccccc?text=No+Image'; image.src = imageUrl; image.onload = () => { slide.innerHTML = generateTourCardHTML(tour); slide.classList.add('is-loaded'); }; image.onerror = () => { slide.innerHTML = generateTourCardHTML(tour); slide.classList.add('is-loaded'); }; } }); }); } else { console.error('AJAX error:', res.data ? res.data.message : 'Unknown error'); } }).catch(error => { console.error('AJAX call failed!', error); uniqueIds.forEach(id => fetchedIds.delete(id)); if(retries > 0) { setTimeout(() => fetchTourData(uniqueIds, retries - 1), 2000); } });
                };
                
                const checkAndLoadSlides = (swiper) => {
                    if (!swiper || !swiper.slides || swiper.slides.length === 0 || !swiper.params) return;
                    const idsToFetch = new Set();
                    const slides = Array.from(swiper.slides);
                    const isGrid = swiper.params.grid && swiper.params.grid.rows > 1;
                    const rows = isGrid ? swiper.params.grid.rows : 1;
                    
                    let currentSlidesPerView = 1;
                    if (responsiveSlides) {
                         currentSlidesPerView = swiper.params.slidesPerView;
                    } else {
                         if (isGrid) { currentSlidesPerView = parseInt(swiper.params.slidesPerView, 10) || 1; } else { currentSlidesPerView = slidesPerView || 3; }
                    }
                    
                    const startIndex = Math.max(0, swiper.activeIndex || 0);
                    const slidesToLoadCount = Math.max(1, (currentSlidesPerView * rows) + 2);
                    const slidesToCheck = slides.slice(startIndex, startIndex + slidesToLoadCount);
                    if (slidesToCheck.length > 0) { slidesToCheck.forEach(slide => { if(slide.dataset.tourId) idsToFetch.add(parseInt(slide.dataset.tourId, 10)); }); }
                    if (idsToFetch.size > 0) { fetchTourData(Array.from(idsToFetch)); }
                };
                
                let calculatedSlidesPerView = slidesPerView;
                if(responsiveSlides) {
                    const containerW = container.offsetWidth || container.clientWidth;
                    let desiredCount = Math.floor((containerW + spaceBetween) / (cardWidth + spaceBetween));
                    calculatedSlidesPerView = Math.min(Math.max(desiredCount, 1), 5);
                }

                const swiperOptions = {
                    slidesPerView: calculatedSlidesPerView,
                    spaceBetween: spaceBetween,
                    loop: <?php echo json_encode($loop); ?>,
                    dir: '<?php echo esc_js($direction); ?>',
                    on: { 
                        init: (s) => setTimeout(() => checkAndLoadSlides(s), 150), 
                        slideChange: checkAndLoadSlides, 
                        resize: (s) => {
                            checkAndLoadSlides(s);
                            
                            if (responsiveSlides) {
                                 const containerW = s.el.clientWidth;
                                 let desiredCount = Math.floor((containerW + spaceBetween) / (cardWidth + spaceBetween));
                                 let newSlidesPerView = Math.min(Math.max(desiredCount, 1), 5);
                                 
                                 if(s.params.slidesPerView !== newSlidesPerView) {
                                     s.params.slidesPerView = newSlidesPerView;
                                     s.update();
                                     s.updateSlides();
                                     s.updateProgress();
                                 }
                            } else if (autoGap) {
                                const newGap = calculateGap();
                                s.params.spaceBetween = newGap;
                                updateGridHeight(); 
                                s.update();
                            }
                        } 
                    },
                    observer: true,
                    observeParents: true
                };
                
                <?php if ($autoplay_enabled): ?> swiperOptions.autoplay = { delay: <?php echo esc_js($autoplay_delay); ?>, disableOnInteraction: false }; <?php endif; ?>
                <?php if ($navigation_enabled): ?> swiperOptions.navigation = { nextEl: container.querySelector('.tappersia-carusel-next'), prevEl: container.querySelector('.tappersia-carusel-perv') }; <?php endif; ?>
                <?php if ($pagination_enabled): ?> swiperOptions.pagination = { el: container.querySelector('.swiper-pagination'), clickable: true }; <?php endif; ?>
                <?php if ($is_doubled): ?> 
                    swiperOptions.grid = { rows: 2, fill: '<?php echo esc_js($grid_fill); ?>' }; 
                    swiperOptions.slidesPerView = calculatedSlidesPerView;
                    swiperOptions.slidesPerGroup = 1; 
                    swiperOptions.spaceBetween = spaceBetween;
                <?php endif; ?>

                if (typeof Swiper !== 'undefined') {
                    try { new Swiper(swiperEl, swiperOptions); } catch (e) { console.error("Swiper initialization failed for <?php echo esc_js($unique_id); ?>:", e); }
                } else { console.error("Swiper library not loaded for <?php echo esc_js($unique_id); ?>."); }
            });
            </script>
            <?php
            return ob_get_clean();
        }
    }
}