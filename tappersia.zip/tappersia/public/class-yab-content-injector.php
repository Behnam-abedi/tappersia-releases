<?php

class Yab_Content_Injector {

    public function init() {
        // اولویت 99 برای اطمینان از اجرا شدن بعد از تغییرات قالب و المنتور
        add_filter('the_content', [$this, 'inject_banners_html'], 99);
    }

    public function inject_banners_html($content) {
        // اگر در ادمین هستیم یا صفحه تکی نیست، کاری نکن
        if (is_admin() || !is_singular()) {
            return $content;
        }

        $banners = $this->get_injection_banners();
        if (empty($banners)) {
            return $content;
        }

        // پاراگراف‌ها را بر اساس تگ بسته جدا می‌کنیم
        $paragraphs = explode('</p>', $content);
        $total_paragraphs = count($paragraphs);
        
        // اگر محتوا پاراگراف‌بندی نشده است (کمتر از 2 پاراگراف)
        if ($total_paragraphs <= 1) {
             return $content;
        }

        $injections = []; 

        foreach ($banners as $banner_post) {
            $data = get_post_meta($banner_post->ID, '_yab_banner_data', true);
            $method = $data['displayMethod'] ?? '';
            
            // نرمال‌سازی متد نمایش
            $injection_type = 'Top'; // Default
            if (in_array($method, ['BotInjection', 'LastParagraph', 'Bot'])) {
                $injection_type = 'Bot';
            }

            // تولید HTML بنر
            $html = $this->generate_banner_html($banner_post, $data);
            if (empty($html)) continue;

            if ($injection_type === 'Top') {
                // تزریق بعد از پاراگراف اول (ایندکس 0)
                if (!isset($injections[0])) $injections[0] = '';
                $injections[0] .= $html;
            } 
            elseif ($injection_type === 'Bot') {
                // تزریق قبل از پاراگراف آخر
                $target_index = max(0, $total_paragraphs - 2);
                if (trim(end($paragraphs)) === '') {
                    $target_index = max(0, $total_paragraphs - 3);
                }

                if (!isset($injections[$target_index])) $injections[$target_index] = '';
                $injections[$target_index] .= $html;
            }
        }

        // بازسازی محتوا
        $new_content = '';
        foreach ($paragraphs as $index => $paragraph) {
            $new_content .= $paragraph;
            
            // برگرداندن تگ </p>
            if ($index < count($paragraphs) - 1 || trim($paragraph) !== '') {
                 $new_content .= '</p>';
            }

            // اضافه کردن بنرها در جایگاه مربوطه
            if (isset($injections[$index])) {
                $new_content .= $injections[$index];
            }
        }
        
        return $new_content;
    }

    private function get_injection_banners() {
        $args = [
            'post_type'      => 'yab_banner',
            'posts_per_page' => -1,
            'post_status'    => 'publish',
            'meta_query'     => [
                'relation' => 'AND',
                ['key' => '_yab_is_active', 'value' => '1'],
                [
                    'key'     => '_yab_display_method',
                    'value'   => ['TopInjection', 'BotInjection', 'FirstParagraph', 'LastParagraph'],
                    'compare' => 'IN'
                ]
            ]
        ];

        $banners = get_posts($args);
        $filtered = [];

        foreach ($banners as $banner) {
            $data = get_post_meta($banner->ID, '_yab_banner_data', true);
            if (empty($data['displayOn'])) continue;

            if (class_exists('Yab_Display_Validator') && Yab_Display_Validator::should_display($data['displayOn'])) {
                $filtered[] = $banner;
            }
        }

        return $filtered;
    }

    private function generate_banner_html($banner_post, $data) {
        $type = get_post_meta($banner_post->ID, '_yab_banner_type', true);
        $class_name_part = str_replace('-', '_', ucwords($type, '-'));
        $class_name = 'Yab_' . $class_name_part . '_Renderer';

        if (class_exists($class_name)) {
             try {
                 $renderer = new $class_name($data, $banner_post->ID);
                 return $renderer->render();
             } catch (Exception $e) {
                 return "";
             }
        }
        return "";
    }
}