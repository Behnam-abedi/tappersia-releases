Tappersia Plugin Developer Documentation
Welcome to the Tappersia WordPress plugin development guide. This document provides all the necessary information to set up your environment, understand the codebase architecture, and follow the release procedures utilizing our automated GitHub Actions pipelines.

Table of Contents
Getting Started & Installation

Project Structure

Architecture Overview

Development Workflow

Deployment & Release Automation

1. Getting Started & Installation
To contribute to this project, you need a local WordPress environment (e.g., LocalWP, XAMPP, Docker).

Step 1: Clone the Repository
Open your terminal, navigate to your WordPress plugins directory, and clone the source code:


cd /path/to/your/wordpress/wp-content/plugins/
git clone https://github.com/Behnam-abedi/tappersia.git
Step 2: Activation
Log in to your WordPress Admin Dashboard.

Navigate to Plugins and activate Tappersia.

License Activation: Upon activation, you will be redirected to an activation screen. You must enter a valid API Key to unlock the plugin features. This key authenticates against b2bapi.tapexplore.com.

2. Project Structure
The plugin follows a hybrid structure, combining a Vue.js Single Page Application (SPA) for the Admin Dashboard with standard PHP classes for the frontend rendering.

Plaintext

tappersia/
├── .github/workflows/           # CI/CD Automation files (See Section 5)
├── tappersia-main.php           # Plugin entry point (Constants & Hooks)
├── includes/
│   ├── class-main.php           # Core loader (Instantiates Admin/Public/Updater)
│   ├── class-activator.php      # Runs on activation (Registers 'yab_banner' CPT)
│   ├── license/                 # License validation logic & API Client
│   ├── updater/                 # Custom GitHub-based update mechanism
│   └── BannerTypes/             # Backend logic for saving/sanitizing specific banner data
├── admin/                       # Admin Dashboard (Vue.js App)
│   ├── class-admin-menu.php     # Menu registration & Asset enqueueing
│   ├── class-ajax-handler.php   # AJAX Controller (Save, Delete, Duplicate)
│   └── views/                   # PHP wrappers for Vue components
│       └── banner-types/        # Editor templates for specific banner types
├── public/                      # Frontend Logic
│   ├── class-shortcode-handler.php # Handles [shortcodes]
│   └── Renderers/               # PHP Classes that generate final HTML for the site
└── assets/
    ├── css/                     # Admin & Public Styles (Tailwind utility classes)
    └── js/
        ├── admin/
        │   ├── app.js           # Vue.js Entry Point
        │   ├── app-logic/       # Core Vue logic & Components
        │   └── composables/     # Vue State Management (The "Store")
        └── vendor/              # Dependencies (Swiper, Coloris, etc.)
3. Architecture Overview
The Admin Panel (Vue.js)
The admin interface is built with Vue.js 3 (using CDN, no build step required).

State Management: The file assets/js/admin/composables/banner-state/bannerState.js holds the reactive state of the banner being edited.

Data Flow: When a user clicks "Save", the JavaScript object is serialized into JSON and sent via AJAX to admin/ajax/class-yab-ajax-banner-handler.php.

Data Storage
Banners are stored as a Custom Post Type: yab_banner.

All configuration data (colors, text, API selections) is stored in a single JSON object within the _yab_banner_data post meta.

The Frontend (SSR)
The frontend does not use Vue.js for rendering to ensure SEO and performance.

Shortcode: WordPress parses the shortcode (e.g., [singlebanner id="5"]).

Handler: class-shortcode-handler.php identifies the banner type.

Renderer: The specific Renderer class (e.g., Yab_Single_Banner_Renderer) generates raw HTML/CSS based on the saved metadata.

4. Development Workflow
How to add a new feature
Vue Store: Add the new property to the default state in assets/js/admin/composables/banner-state/defaults/.

UI: Add the input field in the relevant PHP view inside admin/views/banner-types/.

Backend Sanitization: Update the sanitize_banner_data method in the corresponding class inside includes/BannerTypes/.

Frontend Render: Update the renderer class in public/Renderers/ to output the new data.

5. Deployment & Release Automation
We do not manually build ZIP files. We use GitHub Actions to automate security obfuscation, packaging, and distribution.

The Deployment Flow
The plugin uses a "Private Source, Public Distribution" model. The source code is secure, while the release ZIP is pushed to a public repository for users to download.

How to Release a New Version
Update Version Number: Open tappersia-main.php and increment the YAB_VERSION constant and the file header version.

PHP

define( 'YAB_VERSION', '1.0.5' );
Push and Tag: Commit your changes and push to the main branch. To trigger the release pipeline, you must create a Git Tag starting with v.


git add .
git commit -m "Bump version to 1.0.5"
git push origin main

# Trigger the release pipeline
git tag v1.0.5
git push origin v1.0.5
What Happens Automatically? (The CI/CD Pipeline)
When you push a tag (e.g., v1.0.5), the release.yml workflow triggers. Here is the automated process:

Environment Setup: The runner checks out the code and sets up PHP 7.4.

Security Obfuscation (YAK Pro):

The workflow installs YAK Pro.

It specifically obfuscates sensitive license handling files (class-yab-license-manager.php, class-yab-api-client.php, etc.) to protect our API logic.

Note: The rest of the plugin remains open source/readable.

Changelog Generation: It automatically generates a changelog HTML based on your commit messages between tags.

JSON Generation: It creates an update-info.json file containing:

The new version number.

The direct download link for the ZIP.

The HTML changelog.

Packaging: It zips the tappersia folder (excluding git files and development configs).

Public Distribution:

The workflow checks out the public distribution repository (Behnam-abedi/tappersia-releases).

It copies the new tappersia.zip and update-info.json to that repository.

It commits and pushes these files.

How Users Receive Updates
The plugin's Updater Class (includes/updater/) periodically polls the update-info.json file from the public repository.

If the version in the JSON is higher than the installed version, WordPress displays an "Update Available" notification.

Clicking "Update" downloads the obfuscated, production-ready ZIP file created by the GitHub Action.