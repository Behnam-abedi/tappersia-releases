<?php

if (!class_exists('Yab_Ajax_Banner_Handler')) {
    class Yab_Ajax_Banner_Handler {

        public function register_hooks() {
            add_action('wp_ajax_yab_save_banner', [$this, 'save_banner']);
            add_action('wp_ajax_yab_delete_banner', [$this, 'delete_banner']);
            add_action('wp_ajax_yab_duplicate_banner', [$this, 'duplicate_banner']);
        }

        private function get_banner_type_handler($banner_type_slug) {
            $handlers = [
                'double-banner'                 => 'Yab_Double_Banner',
                'single-banner'                 => 'Yab_Single_Banner',
                'api-banner'                    => 'Yab_Api_Banner',
                'simple-banner'                 => 'Yab_Simple_Banner',
                'sticky-simple-banner'          => 'Yab_Sticky_Simple_Banner',
                'promotion-banner'              => 'Yab_Promotion_Banner',
                'content-html-banner'           => 'Yab_Content_Html_Banner',
                'content-html-sidebar-banner'   => 'Yab_Content_Html_Sidebar_Banner',
                'tour-carousel'                 => 'Yab_Tour_Carousel',
                'hotel-carousel'                => 'Yab_Hotel_Carousel',
                'flight-ticket'                 => 'Yab_Flight_Ticket',
                'welcome-package-banner'        => 'Yab_Welcome_Package_Banner', 
            ];

            if (array_key_exists($banner_type_slug, $handlers)) {
                $class_name = $handlers[$banner_type_slug];
                $folder_name = str_replace(['Yab_', '_'], ['', ''], $class_name);
                $file_path = YAB_PLUGIN_DIR . 'includes/BannerTypes/' . $folder_name . '/' . $folder_name . '.php';

                if (file_exists($file_path)) {
                    require_once $file_path;
                    if (class_exists($class_name)) {
                        return new $class_name();
                    }
                }
            }
            return null;
        }

        public function save_banner() {
            check_ajax_referer('yab_nonce', 'nonce');
            if (!current_user_can('manage_options')) {
                wp_send_json_error(['message' => 'Permission denied.'], 403);
                return;
            }

            if (!isset($_POST['banner_data']) || !isset($_POST['banner_type'])) {
                wp_send_json_error(['message' => 'Incomplete data provided.'], 400);
                return;
            }

            $banner_data = json_decode(stripslashes($_POST['banner_data']), true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                 wp_send_json_error(['message' => 'Invalid JSON format.', 'error_details' => json_last_error_msg()], 400);
                 return;
            }

            $banner_type = sanitize_text_field($_POST['banner_type']);
            
            // --- VALIDATION LOGIC START ---
            $current_banner_id = isset($banner_data['id']) ? intval($banner_data['id']) : 0;
            $display_method = $banner_data['displayMethod'] ?? 'Fixed';
            $is_active = $banner_data['isActive'] ?? false;
            $conditions = $banner_data['displayOn'] ?? [];

            if ($display_method !== 'Embeddable' && $is_active) {
                $conflict_error = $this->check_conflicts($current_banner_id, $banner_type, $display_method, $conditions);
                if ($conflict_error) {
                    wp_send_json_error(['message' => $conflict_error], 400);
                    return;
                }
            }
            // --- VALIDATION LOGIC END ---

            $handler = $this->get_banner_type_handler($banner_type);

            if (!$handler) {
                wp_send_json_error(['message' => 'Invalid banner type.'], 400);
                return;
            }

            $handler->save($banner_data);
            wp_die();
        }

        /**
         * Check for conflicts:
         * Prevents assigning the same banner type with the same display method
         * to the same Posts/Pages/Categories.
         */
        private function check_conflicts($current_id, $type, $method, $conditions) {
            $new_posts = $this->normalize_ids($conditions['posts'] ?? []);
            $new_pages = $this->normalize_ids($conditions['pages'] ?? []);
            $new_cats  = $this->normalize_ids($conditions['categories'] ?? []);

            if (empty($new_posts) && empty($new_pages) && empty($new_cats)) {
                return null;
            }

            $args = [
                'post_type' => 'yab_banner',
                'posts_per_page' => -1,
                'post_status' => 'publish',
                'post__not_in' => [$current_id],
                'meta_query' => [
                    'relation' => 'AND',
                    ['key' => '_yab_banner_type', 'value' => $type],
                    ['key' => '_yab_display_method', 'value' => $method],
                    ['key' => '_yab_is_active', 'value' => '1'],
                ]
            ];

            $existing_banners = get_posts($args);

            foreach ($existing_banners as $banner) {
                $data = get_post_meta($banner->ID, '_yab_banner_data', true);
                $existing_cond = $data['displayOn'] ?? [];

                $ex_posts = $this->normalize_ids($existing_cond['posts'] ?? []);
                $ex_pages = $this->normalize_ids($existing_cond['pages'] ?? []);
                $ex_cats  = $this->normalize_ids($existing_cond['categories'] ?? []);

                // 1. Direct Post Conflict
                $post_intersect = array_intersect($new_posts, $ex_posts);
                if (!empty($post_intersect)) {
                    $p_titles = [];
                    foreach($post_intersect as $pid) $p_titles[] = get_the_title($pid);
                    return sprintf('Conflict with banner "%s": Post(s) (%s) are already assigned to this banner type.', $banner->post_title, implode(', ', $p_titles));
                }

                // 2. Direct Page Conflict
                $page_intersect = array_intersect($new_pages, $ex_pages);
                if (!empty($page_intersect)) {
                    $p_titles = [];
                    foreach($page_intersect as $pid) $p_titles[] = get_the_title($pid);
                    return sprintf('Conflict with banner "%s": Page(s) (%s) are already assigned to this banner type.', $banner->post_title, implode(', ', $p_titles));
                }

                // 3. Direct Category Conflict
                $cat_intersect = array_intersect($new_cats, $ex_cats);
                if (!empty($cat_intersect)) {
                    $c_names = [];
                    foreach($cat_intersect as $cid) $c_names[] = get_cat_name($cid);
                    return sprintf('Conflict with banner "%s": Category(s) (%s) are already assigned to this banner type.', $banner->post_title, implode(', ', $c_names));
                }

                // 4. Combined Conflict: New Post exists in Old Category
                if (!empty($new_posts) && !empty($ex_cats)) {
                    foreach ($new_posts as $pid) {
                        if (has_category($ex_cats, $pid)) {
                            return sprintf('Conflict with banner "%s": The post "%s" belongs to a category already assigned to that banner.', $banner->post_title, get_the_title($pid));
                        }
                    }
                }

                // 5. Combined Conflict: New Category contains Old Post
                if (!empty($new_cats) && !empty($ex_posts)) {
                    foreach ($ex_posts as $pid) {
                        if (has_category($new_cats, $pid)) {
                            return sprintf('Conflict with banner "%s": Your selected category contains the post "%s" which is already assigned to that banner.', $banner->post_title, get_the_title($pid));
                        }
                    }
                }
            }

            return null;
        }

        private function normalize_ids($items) {
            if (empty($items)) return [];
            $ids = [];
            foreach ($items as $item) {
                if (is_numeric($item)) $ids[] = intval($item);
                elseif (is_array($item) && isset($item['id'])) $ids[] = intval($item['id']);
                elseif (is_object($item) && isset($item->id)) $ids[] = intval($item->id);
            }
            return array_unique($ids);
        }
        
        // ... (delete_banner and duplicate_banner remain unchanged) ...

        public function delete_banner() {
             check_ajax_referer('yab_nonce', 'nonce');
            if (!current_user_can('manage_options')) { wp_send_json_error(['message' => 'Permission denied.'], 403); return; }
            if (!isset($_POST['banner_id']) || !is_numeric($_POST['banner_id'])) { wp_send_json_error(['message' => 'Invalid banner ID.'], 400); return; }

            $banner_id = intval($_POST['banner_id']);
            $post = get_post($banner_id);

            if (!$post || $post->post_type !== 'yab_banner') {
                wp_send_json_error(['message' => 'Banner not found.'], 404);
                return;
            }

            $result = wp_delete_post($banner_id, true); 

            if ($result === false) {
                wp_send_json_error(['message' => 'Failed to delete the banner.'], 500);
            } else {
                wp_send_json_success(['message' => 'Banner deleted successfully.']);
            }

            wp_die();
        }

        public function duplicate_banner() {
            check_ajax_referer('yab_nonce', 'nonce');
            if (!current_user_can('manage_options')) { wp_send_json_error(['message' => 'Permission denied.'], 403); return; }
            if (!isset($_POST['banner_id']) || !is_numeric($_POST['banner_id'])) { wp_send_json_error(['message' => 'Invalid banner ID.'], 400); return; }

            $original_banner_id = intval($_POST['banner_id']);
            $post = get_post($original_banner_id);

            if (!$post || $post->post_type !== 'yab_banner') {
                wp_send_json_error(['message' => 'Banner not found.'], 404);
                return;
            }

            $original_data = get_post_meta($original_banner_id, '_yab_banner_data', true);
            $original_type = get_post_meta($original_banner_id, '_yab_banner_type', true);

            if (empty($original_data) || empty($original_type)) {
                wp_send_json_error(['message' => 'Banner data is corrupt or missing.'], 500);
                return;
            }

            $new_post_title = $post->post_title . ' - Copy';
            $new_banner_data = $original_data;

            $new_banner_data['displayOn'] = ['posts' => [], 'pages' => [], 'categories' => []];
            $new_banner_data['isActive'] = false;
            unset($new_banner_data['id']);
            unset($new_banner_data['name']);
            $new_banner_data['displayMethod'] = $original_data['displayMethod'] ?? 'Fixed';


            $new_post_data = [
                'post_title'    => $new_post_title,
                'post_type'     => 'yab_banner',
                'post_status'   => 'publish',
                'post_author'   => get_current_user_id(),
            ];

            $new_post_id = wp_insert_post($new_post_data, true);

            if (is_wp_error($new_post_id)) {
                wp_send_json_error(['message' => $new_post_id->get_error_message()], 500);
                return;
            }

            update_post_meta($new_post_id, '_yab_banner_data', $new_banner_data);
            update_post_meta($new_post_id, '_yab_banner_type', $original_type);
            update_post_meta($new_post_id, '_yab_display_method', $new_banner_data['displayMethod']);
            update_post_meta($new_post_id, '_yab_is_active', $new_banner_data['isActive']);

            $new_banner_for_list = [
                'id' => $new_post_id,
                'title' => $new_post_title,
                'date' => get_the_date('Y/m/d', $new_post_id),
                'is_active' => $new_banner_data['isActive'],
                'display_method' => $new_banner_data['displayMethod'],
                'shortcode' => $this->generate_shortcode($new_post_id, $original_type, $new_banner_data['displayMethod']),
                'type' => $original_type,
                'edit_url' => admin_url('admin.php?page=tappersia&action=edit&banner_id=' . $new_post_id),
            ];

            wp_send_json_success([
                'message' => 'Banner duplicated successfully.',
                'newBanner' => $new_banner_for_list
            ]);

            wp_die();
        }

        private function generate_shortcode($banner_id, $banner_type, $display_method) {
             $base_shortcode = str_replace('-', '', $banner_type);
             $base_shortcode = str_replace(['contenthtmlbanner','contenthtmlsidebarbanner','welcomepackagebanner'], 
                                           ['contenthtml','contenthtmlsidebar','welcomepackage'], $base_shortcode);
 
             if ($display_method === 'Embeddable') {
                 return '[' . $base_shortcode . ' id="' . $banner_id . '"]';
             } else {
                 return '[' . $base_shortcode . '_fixed]';
             }
        }
    }
}