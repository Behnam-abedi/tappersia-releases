<?php
// tappersia/admin/ajax/class-yab-ajax-migration-handler.php

if (!class_exists('Yab_Ajax_Migration_Handler')) {
    class Yab_Ajax_Migration_Handler {

        public function register_hooks() {
            add_action('wp_ajax_yab_export_banners', [$this, 'handle_export']);
            add_action('wp_ajax_yab_import_banners', [$this, 'handle_import']);
        }

        public function handle_export() {
            check_ajax_referer('yab_nonce', 'nonce');
            if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Permission denied.']);

            $banner_ids = isset($_POST['banner_ids']) ? $_POST['banner_ids'] : [];
            if (empty($banner_ids) || !is_array($banner_ids)) {
                wp_send_json_error(['message' => 'No banners selected.']);
            }

            // اطمینان از وجود ثابت دایرکتوری، در غیر این صورت استفاده از مسیر نسبی
            if (defined('YAB_PLUGIN_DIR')) {
                require_once YAB_PLUGIN_DIR . 'includes/class-migration-manager.php';
            } else {
                require_once plugin_dir_path(dirname(dirname(__DIR__))) . 'includes/class-migration-manager.php';
            }

            $manager = new Yab_Migration_Manager();
            
            $result = $manager->export_banners($banner_ids);

            if (is_wp_error($result)) {
                wp_send_json_error(['message' => $result->get_error_message()]);
            } else {
                wp_send_json_success(['url' => $result]);
            }
        }

        public function handle_import() {
            check_ajax_referer('yab_nonce', 'nonce');
            if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Permission denied.']);

            if (empty($_FILES['import_file'])) {
                wp_send_json_error(['message' => 'No file uploaded.']);
            }

            $file = $_FILES['import_file'];
            if ($file['type'] !== 'application/zip' && $file['type'] !== 'application/x-zip-compressed') {
                 $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
                 if($ext !== 'zip') {
                     wp_send_json_error(['message' => 'Only ZIP files are allowed.']);
                     return;
                 }
            }

            if (defined('YAB_PLUGIN_DIR')) {
                require_once YAB_PLUGIN_DIR . 'includes/class-migration-manager.php';
            } else {
                require_once plugin_dir_path(dirname(dirname(__DIR__))) . 'includes/class-migration-manager.php';
            }

            $manager = new Yab_Migration_Manager();
            
            $result = $manager->import_banners($file['tmp_name']);

            if (is_wp_error($result)) {
                wp_send_json_error(['message' => $result->get_error_message()]);
            } else {
                wp_send_json_success(['message' => "Successfully imported {$result} banners."]);
            }
        }
    }
}