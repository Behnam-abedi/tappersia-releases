<?php
defined('ABSPATH') || exit;

class Yab_Global_Settings {

    public function init() {
        add_action('admin_menu', [$this, 'add_settings_page']);
        
        $ajax_path = YAB_PLUGIN_DIR . 'admin/ajax/class-yab-ajax-migration-handler.php';
        if (file_exists($ajax_path)) {
            require_once $ajax_path;
            if (class_exists('Yab_Ajax_Migration_Handler')) {
                $handler = new Yab_Ajax_Migration_Handler();
                $handler->register_hooks();
            }
        }
    }

    public function add_settings_page() {
        add_submenu_page(
            'tappersia',
            'Migration',
            'Export / Import',
            'manage_options',
            'yab-migration',
            [$this, 'render_page']
        );
    }

    private function get_banner_icon($type) {
        $icons = [
            'single-banner'               => 'dashicons-format-image',
            'double-banner'               => 'dashicons-columns',
            'api-banner'                  => 'dashicons-rest-api',
            'simple-banner'               => 'dashicons-text-page',
            'sticky-simple-banner'        => 'dashicons-sticky',
            'promotion-banner'            => 'dashicons-megaphone',
            'content-html-banner'         => 'dashicons-editor-code',
            'content-html-sidebar-banner' => 'dashicons-align-pull-right',
            'tour-carousel'               => 'dashicons-slides',
            'hotel-carousel'              => 'dashicons-building',
            'flight-ticket'               => 'dashicons-airplane',
            'welcome-package-banner'      => 'dashicons-products',
        ];
        return isset($icons[$type]) ? $icons[$type] : 'dashicons-cover-image';
    }

    public function render_page() {
        $banners = get_posts(['post_type' => 'yab_banner', 'posts_per_page' => -1]);
        
        $types = [];
        foreach ($banners as $b) {
            $t = get_post_meta($b->ID, '_yab_banner_type', true);
            if($t) $types[$t] = ucwords(str_replace('-', ' ', $t));
        }
        $types = array_unique($types);
        ?>
        <style>
            #wpcontent{
              padding-left:0 !important;
            }
        </style>
        <div class="wrap yab-settings-wrapper pt-5 pb-5 px-20 ">
            
            <div class="yab-header mb-10 flex flex-col jusitfy-center items-center">
                <h1 class="wp-heading-inline">Migration Center</h1>
                <p class="yab-subtitle">Export your designs to a ZIP file or import from another website.</p>
            </div>

            <div class="yab-migration-tabs">
                <button class="yab-mig-tab-btn active" data-target="export">
                    <span class="dashicons dashicons-download"></span> Export Banners
                </button>
                <button class="yab-mig-tab-btn" data-target="import">
                    <span class="dashicons dashicons-upload"></span> Import Banners
                </button>
            </div>

            <div id="view-export" class="yab-view-section">
                <div class="yab-card">
                    <h2 class="yab-card-title">
                        <span class="dashicons dashicons-grid-view"></span> Export Selection
                    </h2>
                    <div class="yab-card-body">
                        
                        <form id="form-export">
                            <div class="yab-mig-toolbar">
                                <input type="text" id="yab-search" class="yab-search-input" placeholder="Search banners...">
                                <select id="yab-filter" class="yab-select-input">
                                    <option value="all">All Types</option>
                                    <?php foreach($types as $k => $v): ?>
                                        <option value="<?php echo esc_attr($k); ?>"><?php echo esc_html($v); ?></option>
                                    <?php endforeach; ?>
                                </select>
                                
                                <div class="yab-toolbar-actions">
                                    <span id="top-counter" class="yab-selection-count">0 Selected</span>
                                    <button type="button" class="yab-btn-outline-secondary" id="btn-select-all">Select All</button>
                                </div>
                            </div>

                            <div class="yab-mig-grid" id="yab-grid-container">
                                <?php if($banners): foreach($banners as $banner): 
                                    $type = get_post_meta($banner->ID, '_yab_banner_type', true);
                                    $active = get_post_meta($banner->ID, '_yab_is_active', true);
                                    $date = get_the_date('M j, Y', $banner);
                                    $type_label = ucwords(str_replace('-', ' ', $type));
                                    $icon = $this->get_banner_icon($type);
                                ?>
                                <div class="yab-mig-item" data-title="<?php echo strtolower($banner->post_title); ?>" data-type="<?php echo $type; ?>" onclick="toggleCard(this)">
                                    <div class="yab-mig-item-header">
                                        <span class="yab-mig-badge"><?php echo $type_label; ?></span>
                                        <div class="yab-check-icon"><span class="dashicons dashicons-yes"></span></div>
                                    </div>
                                    
                                    <div class="yab-mig-title-row">
                                        <span class="dashicons <?php echo $icon; ?> yab-banner-icon"></span>
                                        <h3 class="yab-mig-title"><?php echo esc_html($banner->post_title); ?></h3>
                                    </div>

                                    <div class="yab-mig-meta">
                                        <span style="color: <?php echo $active ? '#4ade80' : '#fbbf24'; ?>">
                                            <?php echo $active ? '● Active' : '● Draft'; ?>
                                        </span>
                                        <span><?php echo $date; ?></span>
                                    </div>
                                    <input type="checkbox" name="banner_ids[]" value="<?php echo $banner->ID; ?>" style="display:none;">
                                </div>
                                <?php endforeach; else: ?>
                                    <div style="grid-column:1/-1; text-align:center; padding:30px; color:#94a3b8;">
                                        No banners found.
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="yab-sticky-actions" id="sticky-footer">
                                <div style="color:#e2e8f0; font-size:14px;">
                                    Ready to export: <strong id="selected-count" style="color:#00baa4; font-size:15px; margin-left:5px;">0</strong> items
                                </div>
                                <button type="submit" class="yab-btn-primary" id="btn-do-export">
                                    Generate Export ZIP
                                </button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>

            <div id="view-import" class="yab-view-section hidden">
                <div class="yab-card">
                    <h2 class="yab-card-title">
                        <span class="dashicons dashicons-cloud-upload"></span> Import Backup
                    </h2>
                    <div class="yab-card-body">
                        <form id="form-import" style="max-width: 600px; margin: 0 auto;">
                            
                            <div class="yab-upload-zone" id="yab-drop-zone" onclick="document.getElementById('import_file').click()">
                                <span class="dashicons dashicons-media-archive"></span>
                                <h3 class="text-white">Click or Drag & Drop .zip file</h3>
                                <p style="font-size:13px; color:#94a3b8;">Only Tappersia export files are supported.</p>
                                <input type="file" name="import_file" id="import_file" accept=".zip" style="display:none" onchange="handleFileSelect(this)">
                                <p id="file-name" style="margin-top:15px; color:#00baa4; font-weight:bold;"></p>
                            </div>

                            <div style="text-align:center; margin-top: 25px;">
                                <button type="submit" class="yab-btn-primary" id="btn-do-import" disabled>
                                    Start Import Process
                                </button>
                            </div>
                            <div id="import-msg" style="text-align:center;"></div>
                        </form>
                    </div>
                </div>
            </div>

        </div>

        <script>
        // --- JS Logic ---
        function toggleCard(card) {
            const chk = card.querySelector('input');
            chk.checked = !chk.checked;
            card.classList.toggle('selected');
            updateCount();
        }

        function updateCount() {
            // شمارش تمام آیتم‌های انتخاب شده (حتی اگر فیلتر شده باشند)
            const count = document.querySelectorAll('.yab-mig-item.selected').length;
            
            document.getElementById('selected-count').innerText = count;
            
            const topCounter = document.getElementById('top-counter');
            if(topCounter) {
                topCounter.innerText = count + ' Selected';
                topCounter.style.display = count > 0 ? 'inline-block' : 'none';
            }
            
            // Fix: استفاده از classList برای نمایش/مخفی کردن فوتر استیکی
            const footer = document.getElementById('sticky-footer');
            if(count > 0) {
                footer.classList.add('visible');
            } else {
                footer.classList.remove('visible');
            }
        }

        function handleFileSelect(input) {
            if(input.files && input.files[0]) {
                document.getElementById('file-name').innerText = 'File: ' + input.files[0].name;
                document.getElementById('btn-do-import').disabled = false;
            }
        }

        function filterItems() {
            const search = document.getElementById('yab-search').value.toLowerCase();
            const type = document.getElementById('yab-filter').value;
            
            document.querySelectorAll('.yab-mig-item').forEach(card => {
                const title = card.getAttribute('data-title');
                const cType = card.getAttribute('data-type');
                const matchS = title.includes(search);
                const matchT = (type === 'all' || cType === type);

                if(matchS && matchT) {
                    card.classList.remove('hidden');
                } else {
                    card.classList.add('hidden');
                }
            });
        }

        jQuery(document).ready(function($) {
            // Tabs
            $('.yab-mig-tab-btn').on('click', function() {
                $('.yab-mig-tab-btn').removeClass('active');
                $(this).addClass('active');
                $('.yab-view-section').addClass('hidden');
                $('#view-' + $(this).data('target')).removeClass('hidden');
            });

            // Filters
            $('#yab-search').on('keyup', filterItems);
            $('#yab-filter').on('change', filterItems);

            // Select All (Modified to toggle visible items properly)
            $('#btn-select-all').on('click', function() {
                const visible = $('.yab-mig-item:not(.hidden)');
                const allSel = visible.length === visible.filter('.selected').length;
                
                visible.each(function() {
                    const card = $(this);
                    if(allSel) { 
                        card.find('input').prop('checked', false); 
                        card.removeClass('selected'); 
                    } else { 
                        card.find('input').prop('checked', true); 
                        card.addClass('selected'); 
                    }
                });
                updateCount();
            });

            // Drag & Drop
            var $dropZone = $('#yab-drop-zone');
            var $fileInput = $('#import_file');

            $(document).on('dragover dragenter dragleave drop', function(e) {
                e.preventDefault(); e.stopPropagation();
            });

            $dropZone.on('dragover dragenter', function() {
                $(this).css('border-color', '#00baa4').css('background-color', '#2a3a38');
            });

            $dropZone.on('dragleave dragend drop', function() {
                $(this).css('border-color', '').css('background-color', '');
            });

            $dropZone.on('drop', function(e) {
                var files = e.originalEvent.dataTransfer.files;
                if(files.length > 0) {
                    $fileInput[0].files = files;
                    handleFileSelect($fileInput[0]);
                }
            });

            // Export AJAX
            $('#form-export').on('submit', function(e) {
                e.preventDefault();
                var ids = [];
                // Collect selected IDs
                $('.yab-mig-item.selected input').each(function() { ids.push($(this).val()); });
                if(ids.length === 0) return;

                var btn = $('#btn-do-export');
                var oldText = btn.html();
                btn.prop('disabled', true).html('<span class="yab-spinner"></span> Processing...');

                $.ajax({
                    url: ajaxurl, type: 'POST',
                    data: { action: 'yab_export_banners', nonce: '<?php echo wp_create_nonce("yab_nonce"); ?>', banner_ids: ids },
                    success: function(res) {
                        if(res.success && res.data.url) {
                            window.location.href = res.data.url;
                        } else {
                            alert('Error: ' + res.data.message);
                        }
                    },
                    error: function() { alert('Server Error'); },
                    complete: function() { btn.prop('disabled', false).html(oldText); }
                });
            });

            // Import AJAX
            $('#form-import').on('submit', function(e) {
                e.preventDefault();
                var fd = new FormData(this);
                fd.append('action', 'yab_import_banners');
                fd.append('nonce', '<?php echo wp_create_nonce("yab_nonce"); ?>');

                var btn = $('#btn-do-import');
                var msg = $('#import-msg');
                var oldText = btn.html();

                btn.prop('disabled', true).html('<span class="yab-spinner"></span> Importing...');
                msg.html('');

                $.ajax({
                    url: ajaxurl, type: 'POST', data: fd, contentType: false, processData: false,
                    success: function(res) {
                        if(res.success) {
                            msg.html('<div class="yab-msg-success">✅ ' + res.data.message + '</div>');
                            setTimeout(() => location.reload(), 2000);
                        } else {
                            msg.html('<div class="yab-msg-error">❌ ' + res.data.message + '</div>');
                            btn.prop('disabled', false).html(oldText);
                        }
                    },
                    error: function() {
                        msg.html('<div class="yab-msg-error">❌ Connection Failed</div>');
                        btn.prop('disabled', false).html(oldText);
                    }
                });
            });
        });
        </script>
        <?php
    }
}