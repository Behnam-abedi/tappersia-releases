<?php

if (!class_exists('Yab_Ajax_Handler')) {
    class Yab_Ajax_Handler {
        private $api_key;

        public function __construct() {
            if (!class_exists('Yab_License_Manager')) {
                require_once YAB_PLUGIN_DIR . 'includes/license/class-yab-license-manager.php';
            }
            $license_manager = new Yab_License_Manager();
            $this->api_key = $license_manager->get_api_key();

            $this->load_dependencies();
            $this->register_handlers();
            
            add_action('wp_ajax_yab_save_banner', array($this, 'handle_save_banner'));
            add_action('wp_ajax_yab_get_banner', array($this, 'handle_get_banner'));
            add_action('wp_ajax_yab_search_content', array($this, 'handle_search_content'));
        }

        private function load_dependencies() {
            require_once YAB_PLUGIN_DIR . 'admin/ajax/class-yab-ajax-api-handler.php';
            require_once YAB_PLUGIN_DIR . 'admin/ajax/class-yab-ajax-banner-handler.php';
            require_once YAB_PLUGIN_DIR . 'admin/ajax/class-yab-ajax-content-handler.php';
        }

        private function register_handlers() {
            $api_handler = new Yab_Ajax_Api_Handler($this->api_key);
            $api_handler->register_hooks();
            $banner_handler = new Yab_Ajax_Banner_Handler();
            $banner_handler->register_hooks();
            $content_handler = new Yab_Ajax_Content_Handler();
            $content_handler->register_hooks();
        }

        public function handle_save_banner() {
            check_ajax_referer('yab_nonce', 'nonce');

            if (!current_user_can('manage_options')) {
                wp_send_json_error(['message' => 'Permission denied']);
            }

            $raw_data = stripslashes($_POST['banner_data']);
            $data = json_decode($raw_data, true);
            
            if (empty($data)) {
                wp_send_json_error(['message' => 'Invalid data']);
            }

            $banner_id = !empty($data['id']) ? intval($data['id']) : 0;
            $display_method = $data['displayMethod'] ?? 'Fixed';
            $banner_type = $data['type'] ?? '';
            
            // Normalize isActive
            $is_active_raw = $data['isActive'] ?? false;
            $is_active = ($is_active_raw === true || $is_active_raw === 'true' || $is_active_raw === 1 || $is_active_raw === '1');

            // --- STRICT CONFLICT VALIDATION ---
            if ($is_active && in_array($display_method, ['FirstParagraph', 'LastParagraph'])) {
                
                $conflict = $this->check_conflicts($banner_id, $display_method, $banner_type, $data['displayOn'] ?? []);
                
                if ($conflict) {
                    wp_send_json_error(['message' => $conflict]);
                    return; 
                }
            }
            // ----------------------------------

            $post_data = array(
                'post_title'   => sanitize_text_field($data['name']),
                'post_status'  => 'publish',
                'post_type'    => 'yab_banner',
            );

            if ($banner_id > 0) {
                $post_data['ID'] = $banner_id;
                $post_id = wp_update_post($post_data);
            } else {
                $post_id = wp_insert_post($post_data);
            }

            if (is_wp_error($post_id)) {
                wp_send_json_error(['message' => 'Error saving banner']);
            }

            update_post_meta($post_id, '_yab_banner_data', $data);
            update_post_meta($post_id, '_yab_banner_type', $banner_type);
            update_post_meta($post_id, '_yab_display_method', $display_method);
            update_post_meta($post_id, '_yab_is_active', $is_active ? '1' : '0');

            wp_send_json_success(['message' => 'Banner saved successfully', 'id' => $post_id]);
        }

        private function check_conflicts($current_id, $new_method, $new_type, $new_conditions) {
            
            $new_posts = $this->normalize_ids($new_conditions['posts'] ?? []);
            $new_pages = $this->normalize_ids($new_conditions['pages'] ?? []);
            $new_cats  = $this->normalize_ids($new_conditions['categories'] ?? []);

            if (empty($new_posts) && empty($new_pages) && empty($new_cats)) {
                return null;
            }

            // Get ALL published banners to ensure we don't miss anything (even old ones)
            $all_banners = get_posts([
                'post_type' => 'yab_banner',
                'posts_per_page' => -1,
                'post_status' => 'publish',
                'exclude' => [$current_id]
            ]);

            foreach ($all_banners as $banner) {
                // Read from Source of Truth (JSON)
                $b_data = get_post_meta($banner->ID, '_yab_banner_data', true);
                if (!$b_data || !is_array($b_data)) continue;

                // 1. Check Active
                $b_active_raw = $b_data['isActive'] ?? false;
                $b_active = ($b_active_raw === true || $b_active_raw === 'true' || $b_active_raw === 1 || $b_active_raw === '1');
                if (!$b_active) continue;

                // 2. Check Method
                $b_method = $b_data['displayMethod'] ?? '';
                if ($b_method !== $new_method) continue;

                // 3. Check Type
                $b_type = $b_data['type'] ?? '';
                if ($b_type !== $new_type) continue;

                // Match Found! Check Targets
                $b_cond = $b_data['displayOn'] ?? [];
                $b_posts = $this->normalize_ids($b_cond['posts'] ?? []);
                $b_pages = $this->normalize_ids($b_cond['pages'] ?? []);
                $b_cats  = $this->normalize_ids($b_cond['categories'] ?? []);

                // A. Direct Overlaps
                if (!empty(array_intersect($new_posts, $b_posts))) return "Conflict! This post already has a '$new_type' assigned to '$new_method'.";
                if (!empty(array_intersect($new_pages, $b_pages))) return "Conflict! This page already has a '$new_type' assigned to '$new_method'.";
                if (!empty(array_intersect($new_cats, $b_cats))) return "Conflict! This category already has a '$new_type' assigned to '$new_method'.";

                // B. Deep Check
                if (!empty($new_posts) && !empty($b_cats)) {
                    foreach ($new_posts as $pid) {
                        if (has_category($b_cats, $pid)) return "Conflict! Post is inside a category that has a '$new_type' assigned.";
                    }
                }
                if (!empty($b_posts) && !empty($new_cats)) {
                    foreach ($b_posts as $pid) {
                        if (has_category($new_cats, $pid)) return "Conflict! Category contains a post that already has a '$new_type' assigned.";
                    }
                }
            }

            return null;
        }

        private function normalize_ids($input) {
            if (empty($input)) return [];
            $ids = [];
            if (is_array($input)) {
                foreach ($input as $item) {
                    if (is_numeric($item)) $ids[] = (int)$item;
                    elseif (is_array($item) && isset($item['ID'])) $ids[] = (int)$item['ID'];
                    elseif (is_object($item) && isset($item->ID)) $ids[] = (int)$item->ID;
                    elseif (is_array($item) && isset($item['term_id'])) $ids[] = (int)$item['term_id'];
                    elseif (is_object($item) && isset($item->term_id)) $ids[] = (int)$item->term_id;
                }
            }
            return array_unique(array_filter($ids));
        }

        public function handle_get_banner() {
            check_ajax_referer('yab_nonce', 'nonce');
            $id = intval($_GET['id']);
            $data = get_post_meta($id, '_yab_banner_data', true);
            if ($data) {
                wp_send_json_success($data);
            } else {
                wp_send_json_error(['message' => 'Banner not found']);
            }
        }

        public function handle_search_content() {
            check_ajax_referer('yab_nonce', 'nonce');
            $type = sanitize_text_field($_GET['type']);
            $term = sanitize_text_field($_GET['term']);
            $results = [];

            if ($type === 'posts') {
                $query = new WP_Query(['s' => $term, 'post_type' => 'post', 'posts_per_page' => 20]);
                foreach ($query->posts as $post) {
                    $results[] = ['ID' => $post->ID, 'post_title' => $post->post_title];
                }
            } elseif ($type === 'pages') {
                $query = new WP_Query(['s' => $term, 'post_type' => 'page', 'posts_per_page' => 20]);
                foreach ($query->posts as $post) {
                    $results[] = ['ID' => $post->ID, 'post_title' => $post->post_title];
                }
            } elseif ($type === 'categories') {
                $terms = get_terms(['taxonomy' => 'category', 'name__like' => $term, 'hide_empty' => false, 'number' => 20]);
                foreach ($terms as $t) {
                    $results[] = ['term_id' => $t->term_id, 'name' => $t->name];
                }
            }

            wp_send_json_success($results);
        }
    }
}