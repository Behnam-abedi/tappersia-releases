<?php
defined('ABSPATH') || exit;

class Yab_License_Page {

    private $license_manager;
    private $error_message = '';
    private $success_message = '';

    public function __construct(Yab_License_Manager $license_manager) {
        $this->license_manager = $license_manager;
    }

    public function process_activation_submission() {
        if (!isset($_POST['yab_activate_license'])) {
            return;
        }

        if (!isset($_POST['yab_nonce']) || !wp_verify_nonce(sanitize_text_field($_POST['yab_nonce']), 'yab_activate_license_nonce')) {
            wp_die('Security check failed. Please try again.');
        }

        if (!current_user_can('manage_options')) {
            wp_die('You do not have permission to do this.');
        }

        if (empty($_POST['yab_license_key'])) {
            wp_safe_redirect(admin_url('admin.php?page=tappersia-activate&message=error&code=empty_key'));
            exit;
        }

        $api_key = sanitize_text_field(trim($_POST['yab_license_key']));
        $result = $this->license_manager->activate_license($api_key);

        if ($result['success']) {
            wp_safe_redirect(admin_url('admin.php?page=tappersia'));
            exit;
        } else {
            $error_message = urlencode($result['message']);
            wp_safe_redirect(admin_url('admin.php?page=tappersia-activate&message=error&code=validation_failed&error_msg=' . $error_message));
            exit;
        }
    }

    public function render_page() {
        if (isset($_GET['message'])) {
            if ($_GET['message'] === 'deactivated') {
                $this->success_message = 'License deactivated successfully.';
            }
            if ($_GET['message'] === 'invalid') {
                $this->error_message = 'Your license is invalid or has expired. Please reactivate.';
            }
            if ($_GET['message'] === 'error') {
                if (isset($_GET['error_msg'])) {
                    $this->error_message = sanitize_text_field(urldecode($_GET['error_msg']));
                } elseif (isset($_GET['code']) && $_GET['code'] === 'empty_key') {
                    $this->error_message = 'Please enter an API key.';
                } else {
                    $this->error_message = 'An unknown activation error occurred.';
                }
            }
        }

        wp_enqueue_style(
            'yab-license-style',
            YAB_PLUGIN_URL . 'assets/css/yab-license-style.css',
            [],
            YAB_VERSION
        );

        require_once YAB_PLUGIN_DIR . 'admin/views/view-license-activation.php';
    }
}
