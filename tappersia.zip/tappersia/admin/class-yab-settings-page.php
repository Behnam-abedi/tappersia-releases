<?php
defined('ABSPATH') || exit;

class Yab_Settings_Page {

    private $license_manager;
    private $error_message = '';
    private $success_message = '';
    
    private $option_group = 'yab_global_settings_group';
    private $option_name = 'yab_global_settings';

    public function __construct(Yab_License_Manager $license_manager) {
        $this->license_manager = $license_manager;
    }

    public function init() {
        add_action('admin_init', [$this, 'register_settings']);
    }

    public function register_settings() {
        register_setting($this->option_group, $this->option_name, [
            'sanitize_callback' => [$this, 'sanitize_settings']
        ]);

        add_settings_section(
            'yab_general_section',
            'Content Injection Configuration',
            null,
            'yab-settings-page'
        );

        add_settings_field(
            'content_css_selector',
            'Content CSS Selector',
            [$this, 'render_css_selector_field'],
            'yab-settings-page',
            'yab_general_section'
        );
    }
    
    public function render_css_selector_field() {
        $options = get_option($this->option_name);
        $value = isset($options['content_css_selector']) ? esc_attr($options['content_css_selector']) : '.entry-content';
        echo "<input type='text' name='{$this->option_name}[content_css_selector]' value='{$value}' class='regular-text' />";
        echo "<p class='description'>Enter the CSS Class or ID of your post content wrapper (e.g., .entry-content). Used for safe injection.</p>";
    }

    public function sanitize_settings($input) {
        $new_input = [];
        if (isset($input['content_css_selector'])) {
            $new_input['content_css_selector'] = sanitize_text_field($input['content_css_selector']);
        }
        return $new_input;
    }

    public function process_activation_submission() {
        if (!isset($_POST['yab_activate_license'])) return;
        if (!isset($_POST['yab_nonce']) || !wp_verify_nonce(sanitize_text_field($_POST['yab_nonce']), 'yab_activate_license_nonce')) wp_die('Security check failed.');
        if (!current_user_can('manage_options')) wp_die('Permission denied.');

        $api_key = sanitize_text_field(trim($_POST['yab_license_key']));
        $result = $this->license_manager->activate_license($api_key);

        if ($result['success']) {
            wp_safe_redirect(admin_url('admin.php?page=tappersia'));
            exit;
        } else {
            wp_safe_redirect(admin_url('admin.php?page=tappersia-activate&message=error&error_msg=' . urlencode($result['message'])));
            exit;
        }
    }

    public function render_activation_page() {
        $this->render_general_settings_page(true); 
    }

    public function display_general_settings_page() {
        $this->render_general_settings_page(false);
    }

    private function render_general_settings_page($is_activation_mode = false) {
        if (isset($_GET['message'])) {
             if ($_GET['message'] === 'deactivated') $this->success_message = 'License deactivated successfully.';
             if ($_GET['message'] === 'invalid') $this->error_message = 'Your license is invalid or has expired.';
             if ($_GET['message'] === 'error' && isset($_GET['error_msg'])) $this->error_message = urldecode($_GET['error_msg']);
        }

        wp_enqueue_style('yab-license-style', YAB_PLUGIN_URL . 'assets/css/yab-license-style.css', [], YAB_VERSION);
        
        if ($is_activation_mode) {
             require_once YAB_PLUGIN_DIR . 'admin/views/view-license-activation.php'; 
        } else {
             require_once YAB_PLUGIN_DIR . 'admin/views/view-general-settings.php'; 
        }
    }
}