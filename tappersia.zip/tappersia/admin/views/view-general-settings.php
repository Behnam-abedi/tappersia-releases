<?php
defined('ABSPATH') || exit;

if (!class_exists('Yab_License_Manager')) {
    require_once YAB_PLUGIN_DIR . 'includes/license/class-yab-license-manager.php';
}
$license_manager = new Yab_License_Manager();
$license_key = $license_manager->get_api_key();
$license_status = $license_manager->get_license_status();
$masked_key = '****************' . esc_html(substr($license_key, -4));
$status_class = $license_status['status'] === 'valid' ? 'yab-status-valid' : 'yab-status-invalid';
$current_version = defined('YAB_VERSION') ? YAB_VERSION : '1.0.0';
?>

<div class="wrap yab-settings-wrapper pt-5 pb-5 px-20">
    <div class="yab-header mb-10 flex flex-col jusitfy-center items-center">
        <h1 class="wp-heading-inline">Tappersia Settings</h1>
    </div>

    <div class="yab-row-split">
        
        <div class="yab-card">
            <h2 class="yab-card-title">
                <span class="dashicons dashicons-awards"></span> License Status
            </h2>
            <div class="yab-card-body">
                <div class="yab-status-row">
                    <span class="yab-label">Status:</span>
                    <span class="yab-status-badge <?php echo esc_attr($status_class); ?>">
                        <?php echo esc_html($license_status['status'] === 'valid' ? 'Active' : 'Inactive'); ?>
                    </span>
                </div>
                
                <div class="yab-api-key-wrapper mb-5">
                    <label class="yab-label-block">API Key</label>
                    <code class="yab-code-display"><?php echo $masked_key; ?></code>
                </div>
                
                <div class="yab-actions w-full mt-5">
                    <form method="POST" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <input type="hidden" name="action" value="yab_deactivate_license">
                        <?php wp_nonce_field('yab_deactivate_license_nonce', 'yab_nonce'); ?>
                        <button type="submit" class="button yab-btn-outline-danger w-full ">Deactivate License</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="yab-card">
            <h2 class="yab-card-title">
                <span class="dashicons dashicons-update"></span> Updates
            </h2>
            <div class="yab-card-body">
                <div class="yab-status-row">
                    <span class="yab-label">Current Version:</span>
                    <span class="yab-version-pill"><?php echo esc_html($current_version); ?></span>
                </div>
                
                <div id="yab-auto-check-status" class="yab-update-status-container">
                    <div class="yab-checking-animation">
                        <span class="yab-dot"></span>
                        <span class="yab-dot"></span>
                        <span class="yab-dot"></span>
                    </div>
                    <span class="yab-checking-text">Checking for updates...</span>
                </div>
                
                <div id="yab-update-messages" class="yab-update-msg" style="display:none;"></div>
            </div>
        </div>

    </div>

</div>

<script type="text/javascript">
jQuery(document).ready(function($) {
    var statusArea = $('#yab-auto-check-status');
    var messageBox = $('#yab-update-messages');
    var updateNonce = '<?php echo wp_create_nonce('yab_update_nonce'); ?>';

    performAutoCheck();

    function performAutoCheck() {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: { action: 'yab_ajax_check_for_updates', nonce: updateNonce },
            success: function(response) {
                if (response.success && response.data.update_available) {
                    statusArea.html('<div class="yab-update-avail"><span class="dashicons dashicons-warning"></span> New version <strong>v' + response.data.new_version + '</strong> available.</div><button type="button" class="button button-primary yab-btn-update" id="yab-install-update-btn">Update Now</button>');
                } else {
                    statusArea.html('<div class="yab-uptodate"><span class="dashicons dashicons-yes-alt"></span> Plugin is up to date.</div>');
                }
            },
            error: function() {
                 statusArea.html('<span style="color:#ef4444">Connection Failed.</span>');
            }
        });
    }

    $(document).on('click', '#yab-install-update-btn', function(e) {
        e.preventDefault();
        $(this).text('Installing...').prop('disabled', true);
        $.ajax({
            url: ajaxurl, type: 'POST',
            data: { action: 'yab_ajax_install_update', nonce: updateNonce },
            success: function(response) {
                if (response.success) location.reload();
                else alert(response.data.message);
            }
        });
    });
});
</script>