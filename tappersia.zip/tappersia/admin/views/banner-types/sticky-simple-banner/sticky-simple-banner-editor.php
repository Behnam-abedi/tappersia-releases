<header class="sticky top-7 bg-[#434343]/90 backdrop-blur-md p-3 z-20 flex items-center justify-between shadow-xl ltr border-b border-white/5 rounded-b-xl">
    
    <div class="flex items-center gap-4">
        <button @click="goBackToSelection" class="text-gray-400 hover:text-white bg-transparent border-none p-0 cursor-pointer flex items-center transition-colors group">
            <div class="bg-white/5 p-1.5 rounded-full group-hover:bg-white/10 transition-all">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2.5" stroke="currentColor" class="w-4 h-4 group-hover:-translate-x-0.5 transition-transform">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18" />
                </svg>
            </div>
        </button>
        
        <div class="h-8 w-px bg-gray-600/50"></div>

        <div class="relative group">
            <input type="text" v-model="banner.name" placeholder="Enter Banner Name..." 
                class="bg-transparent text-white border-b border-gray-600 focus:border-[#00baa4] px-1 py-1.5 focus:outline-none w-80 text-base font-medium placeholder-gray-500 transition-all">
            <span class="absolute -top-2.5 left-0 text-[10px] text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity bg-[#434343] px-1">Banner Title</span>
        </div>
    </div>
    
    <div class="flex items-center gap-5">
        
        <div class="flex items-center bg-[#292929] rounded-lg p-1 border border-gray-700 shadow-inner">
            <div class="flex flex-col items-center justify-center py-1.5 px-4 rounded-md bg-[#3e3e3e] text-[#00baa4] shadow-md ring-1 ring-[#00baa4]/50 min-w-[70px] gap-1 cursor-default">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="w-5 h-5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 17.25v1.007a3 3 0 01-.879 2.122L7.5 21h9l-.621-.621A3 3 0 0115 18.257V17.25m6-12V15a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 15V5.25m18 0A2.25 2.25 0 0018.75 3H5.25A2.25 2.25 0 003 5.25m18 0V12a2.25 2.25 0 01-2.25 2.25H5.25" />
                </svg>
                <span class="text-[9px] font-semibold uppercase tracking-wider">Fixed</span>
            </div>
        </div>

        <div class="h-8 w-px bg-gray-600/50"></div>

        <div class="flex flex-col items-center gap-1">
             <span class="text-[9px] text-gray-400 font-bold uppercase">Status</span>
             <label class="relative inline-flex items-center cursor-pointer group" title="Toggle Active Status">
                <input type="checkbox" v-model="banner.isActive" class="sr-only peer">
                <div class="w-10 h-5 bg-gray-700 rounded-full peer peer-focus:ring-2 peer-focus:ring-[#00baa4]/50 peer-checked:after:translate-x-5 peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#00baa4]"></div>
            </label>
        </div>

        <button @click="saveBanner" :disabled="isSaving" class="ml-2 bg-gradient-to-r from-[#00baa4] to-[#00a08d] text-white text-xs font-bold px-6 py-2.5 rounded-lg shadow-lg hover:shadow-[#00baa4]/30 hover:from-[#00a08d] hover:to-[#008f7e] transition-all flex items-center gap-2 disabled:bg-none disabled:bg-gray-600 disabled:cursor-not-allowed transform active:scale-95 border border-white/10">
            <span v-if="isSaving" class="dashicons dashicons-update animate-spin text-xs"></span>
            {{ isSaving ? 'SAVING...' : 'SAVE' }}
        </button>
    </div>
</header>

<main class="grid grid-cols-12 gap-2 p-6 ltr">
    <div class="col-span-4 overflow-y-auto flex flex-col gap-6 [&>*:last-child]:mb-[40px] mr-2" style="max-height: calc(100vh - 120px);">
        <div class="bg-[#434343] p-5 rounded-lg shadow-xl mr-2">
            <h3 class="font-bold text-xl text-white tracking-wide mb-4 capitalize">Device</h3>
            <div class="flex  bg-[#292929] rounded-lg p-1">
                <button @click="currentView = 'desktop'" :class="{'active-tab': currentView === 'desktop'}" class="flex-1 tab-button rounded-md">Desktop</button>
                <button @click="currentView = 'mobile'" :class="{'active-tab': currentView === 'mobile'}" class="flex-1 tab-button rounded-md">Mobile</button>
            </div>
        </div>
        <div class="bg-[#434343] p-5 rounded-lg shadow-xl mr-2"v-if="currentView === 'desktop'">
            <div >
                <h3 class="font-bold text-xl text-white tracking-wide mb-4 capitalize">Alignment</h3>
                <div class="flex  bg-[#292929] rounded-lg p-1">
                    <button @click="settings.direction = 'ltr'" :class="settings.direction === 'ltr' ? 'active-tab' : ''" class="flex-1 tab-button rounded-md">Left</button>
                    <button @click="settings.direction = 'rtl'" :class="settings.direction === 'rtl' ? 'active-tab' : ''" class="flex-1 tab-button rounded-md">Right</button>
                </div>
            </div>
        </div>
        <div class="bg-[#434343] p-5 rounded-lg shadow-xl mr-2">


            <div v-if="banner.sticky_simple && banner.sticky_simple_mobile" :key="currentView">
                <h3 class="font-bold text-xl text-white tracking-wide mb-4 capitalize">{{ currentView }} Settings</h3>
            
                <div class="flex flex-col gap-5">
                    <?php require 'sticky-simple-banner-settings.php'; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="col-span-8 sticky top-[120px] space-y-4">
        <?php require YAB_PLUGIN_DIR . 'admin/views/banner-types/sticky-simple-banner/sticky-simple-banner-preview.php'; ?>
        
        <transition name="fade">
<div v-if="['Fixed', 'FirstParagraph', 'LastParagraph'].includes(banner.displayMethod)" class="mt-5 transition-all duration-300">
    <?php include YAB_PLUGIN_DIR . 'admin/views/components/display-conditions.php'; ?>
</div>
        </transition>
    </div>
</main>