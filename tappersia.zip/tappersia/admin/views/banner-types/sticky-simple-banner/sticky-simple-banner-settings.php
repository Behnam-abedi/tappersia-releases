<div  class="flex flex-col gap-3">
    <div>
        <h4 class="section-title">Layout</h4>
        <div class="grid grid-cols-1 gap-2">
            <div>
                <label class="setting-label-sm">Content Width</label>
                <div class="flex items-center gap-1">
                    <input type="number" v-model.number="settings.contentWidth" class="yab-form-input" placeholder="100">
                    <select v-model="settings.contentWidthUnit" class="yab-form-input w-20"><option>%</option><option>px</option></select>
                </div>
            </div>
            <div>
                <label class="setting-label-sm">Min Height (px)</label>
                <input type="number" v-model.number="settings.minHeight" class="yab-form-input" placeholder="e.g., 74">
             </div>
        </div>

    </div>
    <hr class="section-divider">
    <div>
         <h4 class="section-title">Content Padding</h4>
         <div class="grid grid-cols-2 gap-2">
             <div>
                <label class="setting-label-sm">Top/Bottom (px)</label>
                <input type="number" v-model.number="settings.paddingY" class="yab-form-input" placeholder="e.g., 26">
             </div>
             <div>
                <label class="setting-label-sm">Left/Right</label>
                <div class="flex items-center gap-1">
                    <input type="number" v-model.number="settings.paddingX" class="yab-form-input" placeholder="e.g., 40">
                    <select v-model="settings.paddingXUnit" class="yab-form-input w-20"><option>px</option><option>%</option></select>
                </div>
            </div>
         </div>
    </div>
    <hr class="section-divider">
        <div>
        <h4 class="section-title">Border</h4>
         <div class="flex items-center justify-between bg-[#292929] p-2 rounded-md mb-2">
            <label class="setting-label-sm">Enable Border</label>
            <label class="relative inline-flex items-center cursor-pointer" title="Toggle banner border">
                <input type="checkbox" v-model="settings.enableBorder" class="sr-only peer">
                <div class="w-11 h-6 bg-gray-600 rounded-full peer peer-focus:ring-2 peer-focus:ring-blue-500 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-500"></div>
            </label>
        </div>
        <div v-if="settings.enableBorder" class="grid grid-cols-3 gap-2">
             <div v-if="currentView === 'desktop'">
                <label class="setting-label-sm">Color</label>
                <div class="flex items-center gap-1">
                    <div
                        :style="{ backgroundColor: settings.borderColor }"
                        class="w-8 h-[40px] rounded border border-gray-500 flex-shrink-0"
                        title="Selected color preview">
                    </div>
                    <input
                        aria-label="Border color input"
                        type="text"
                        :value="settings.borderColor"
                        @input="event => settings.borderColor = event.target.value"
                        data-coloris
                        class="yab-form-input clr-field flex-grow"
                        placeholder="Select color...">
                </div>
            </div>
            <div :class="{'col-span-3': currentView === 'mobile', 'col-span-2': currentView === 'desktop'}">
                <div class="grid grid-cols-2 gap-2">
                    <div>
                        <label class="setting-label-sm">Width (px)</label>
                        <input type="number" v-model.number="settings.borderWidth" class="yab-form-input" placeholder="e.g., 1">
                    </div>
                    <div>
                        <label class="setting-label-sm">Radius (px)</label>
                        <input type="number" v-model.number="settings.borderRadius" class="yab-form-input" placeholder="e.g., 8">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <hr class="section-divider">
    <div>
        <h4 class="section-title">Background</h4>
        <div class="flex gap-2 mb-2 bg-[#292929] rounded-lg p-1">
            <button @click="settings.backgroundType = 'solid'" :class="{'active-tab': settings.backgroundType === 'solid'}" class="flex-1 tab-button rounded-md border-none">Solid Color</button>
            <button @click="settings.backgroundType = 'gradient'" :class="{'active-tab': settings.backgroundType === 'gradient'}" class="flex-1 tab-button rounded-md border-none">Gradient</button>
        </div>
        <div v-if="settings.backgroundType === 'solid'" class="space-y-2">
            <label class="setting-label-sm">Background Color</label>
            <div class="flex items-center gap-1">
                <div
                    :style="{ backgroundColor: settings.bgColor }"
                    class="w-8 h-[40px] rounded border border-gray-500 flex-shrink-0"
                    title="Selected color preview">
                </div>
                <input
                    aria-label="Background color input"
                    type="text"
                    :value="settings.bgColor"
                    @input="event => settings.bgColor = event.target.value"
                    data-coloris
                    class="yab-form-input clr-field flex-grow"
                    placeholder="Select color...">
            </div>
        </div>
        <div v-else class="space-y-4">
            <div>
                <label class="setting-label-sm">Gradient Angle: {{ settings.gradientAngle }}deg</label>
                <div class="flex items-center gap-2">
                    <input type="range" v-model.number="settings.gradientAngle" min="0" max="360" class="w-full">
                    <input type="number" v-model.number="settings.gradientAngle" class="yab-form-input w-20 text-center">
                </div>
            </div>
            <div>
                <label class="setting-label-sm">Gradient Colors</label>
                <div v-for="(stop, index) in settings.gradientStops" :key="index" class="bg-[#292929] p-3 rounded-lg mb-2 space-y-2">
                    <div class="flex items-center justify-between">
                         <span class="text-xs font-bold text-gray-300">Color Stop #{{ index + 1 }}</span>
                         <button v-if="settings.gradientStops.length > 1" @click="removeGradientStop(settings, index)" class="text-red-500 hover:text-red-400 text-xs">Remove</button>
                    </div>
                    <div class="grid grid-cols-2 gap-2">
                        <div class="flex items-center gap-1">
                            <div
                                :style="{ backgroundColor: stop.color }"
                                class="w-8 h-[40px] rounded border border-gray-500 flex-shrink-0"
                                title="Selected color preview">
                            </div>
                            <input
                                aria-label="Gradient color input"
                                type="text"
                                :value="stop.color"
                                @input="event => stop.color = event.target.value"
                                data-coloris
                                class="yab-form-input clr-field flex-grow"
                                placeholder="Select color...">
                        </div>
                        <button @click="stop.color = 'transparent'" class="bg-gray-600 text-white text-xs rounded-md hover:bg-gray-500">Set Transparent</button>
                    </div>
                    <div>
                        <label class="setting-label-sm">Position: {{ stop.stop }}%</label>
                        <input type="range" v-model.number="stop.stop" min="0" max="100" class="w-full">
                    </div>
                </div>
                 <button @click="addGradientStop(settings.gradientStops)" class="w-full bg-blue-600 text-white text-sm py-2 rounded-md hover:bg-blue-700 mt-2">Add Color Stop</button>
            </div>
        </div>
    </div>
    <hr class="section-divider">

    


    <div class="space-y-2">
        <h4 class="section-title">Text</h4>
        <div v-if="currentView === 'desktop'">
            <label class="setting-label-sm">Text</label>
            <input type="text" v-model="settings.text" class="yab-form-input mb-2" placeholder="Banner Text">
        </div>
        <div class="grid grid-cols-2 gap-2">
            <div v-if="currentView === 'desktop'">
                <label class="setting-label-sm">Color</label>
                <div class="flex items-center gap-1">
                    <div
                        :style="{ backgroundColor: settings.textColor }"
                        class="w-8 h-[40px] rounded border border-gray-500 flex-shrink-0"
                        title="Selected color preview">
                    </div>
                    <input
                        aria-label="Text color input"
                        type="text"
                        :value="settings.textColor"
                        @input="event => settings.textColor = event.target.value"
                        data-coloris
                        class="yab-form-input clr-field flex-grow"
                        placeholder="Select color...">
                </div>
            </div>
            <div class="grid grid-cols-2 gap-2" :class="{'col-span-2': currentView === 'mobile'}">
                <div>
                    <label class="setting-label-sm">Font Size (px)</label>
                    <input type="number" v-model.number="settings.textSize" class="yab-form-input" placeholder="e.g., 17">
                </div>
                <div>
                    <label class="setting-label-sm">Font Weight</label>
                    <select v-model="settings.textWeight" class="yab-form-input">
                        <option value="400">Normal</option><option value="500">Medium</option><option value="600">Semi-Bold</option><option value="700">Bold</option><option value="800">Extra Bold</option>
                    </select>
                </div>
            </div>
        </div>
    </div>
    <hr class="section-divider">
    <div class="space-y-2">
        <h4 class="section-title">Button</h4>
        <div v-if="currentView === 'desktop'">
            <label class="setting-label-sm">Button Text</label>
            <input type="text" v-model="settings.buttonText" class="yab-form-input mb-2" placeholder="Button Text">
            <label class="setting-label-sm">Button Link (URL)</label>
            <input type="text" v-model="settings.buttonLink" class="yab-form-input mb-4" placeholder="https://example.com">
        </div>
        
        <div class="grid grid-cols-2 gap-2 mb-2" v-if="currentView === 'desktop'">
            <div>
                <label class="setting-label-sm">Background Color</label>
                <div class="flex items-center gap-1">
                    <div
                        :style="{ backgroundColor: settings.buttonBgColor }"
                        class="w-8 h-[40px] rounded border border-gray-500 flex-shrink-0"
                        title="Selected color preview">
                    </div>
                    <input
                        aria-label="Button background color input"
                        type="text"
                        :value="settings.buttonBgColor"
                        @input="event => settings.buttonBgColor = event.target.value"
                        data-coloris
                        class="yab-form-input clr-field flex-grow"
                        placeholder="Select color...">
                </div>
            </div>
            <div>
                <label class="setting-label-sm">Text Color</label>
                <div class="flex items-center gap-1">
                    <div
                        :style="{ backgroundColor: settings.buttonTextColor }"
                        class="w-8 h-[40px] rounded border border-gray-500 flex-shrink-0"
                        title="Selected color preview">
                    </div>
                    <input
                        aria-label="Button text color input"
                        type="text"
                        :value="settings.buttonTextColor"
                        @input="event => settings.buttonTextColor = event.target.value"
                        data-coloris
                        class="yab-form-input clr-field flex-grow"
                        placeholder="Select color...">
                </div>
            </div>
            <div class="col-span-2">
                <label class="setting-label-sm">Background Hover Color</label>
                <div class="flex items-center gap-1">
                    <div
                        :style="{ backgroundColor: settings.buttonBgHoverColor }"
                        class="w-8 h-[40px] rounded border border-gray-500 flex-shrink-0"
                        title="Selected color preview">
                    </div>
                    <input
                        aria-label="Button background hover color input"
                        type="text"
                        :value="settings.buttonBgHoverColor"
                        @input="event => settings.buttonBgHoverColor = event.target.value"
                        data-coloris
                        class="yab-form-input clr-field flex-grow"
                        placeholder="Select hover color...">
                </div>
            </div>
        </div>
        <div class="grid grid-cols-2 gap-2">
             <div>
               <label class="setting-label-sm">Border Radius (px)</label>
               <input type="number" v-model.number="settings.buttonBorderRadius" class="yab-form-input" placeholder="e.g., 3">
            </div>
            <div>
                <label class="setting-label-sm">Font Size (px)</label>
                <input type="number" v-model.number="settings.buttonFontSize" class="yab-form-input" placeholder="e.g., 8">
            </div>
            <div>
                <label class="setting-label-sm">Font Weight</label>
                 <select v-model="settings.buttonFontWeight" class="yab-form-input">
                    <option value="400">Normal</option><option value="500">Medium</option><option value="600">Semi-Bold</option><option value="700">Bold</option>
                </select>
            </div>
             <div>
                <label class="setting-label-sm">Min Width (px)</label>
                <input type="number" v-model.number="settings.buttonMinWidth" class="yab-form-input" placeholder="e.g., 72">
            </div>
        </div>
        <div>
            <div class="grid grid-cols-2 gap-2">
                <div>
                    <label class="setting-label-sm">Top/Bottom</label>
                    <input type="number" v-model.number="settings.buttonPaddingY" class="yab-form-input" placeholder="e.g., 7">
                 </div>
                 <div>
                    <label class="setting-label-sm">Left/Right</label>
                    <input type="number" v-model.number="settings.buttonPaddingX" class="yab-form-input" placeholder="e.g., 15">
                </div>
            </div>
        </div>
    </div>
</div>