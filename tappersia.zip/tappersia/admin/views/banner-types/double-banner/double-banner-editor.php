<?php
require YAB_PLUGIN_DIR . 'admin/views/components/banner-editor-header.php'; 
?>

<main class="grid grid-cols-12 gap-2 p-6 ltr">
    <div class="col-span-4 overflow-y-auto flex flex-col gap-3 [&>*:last-child]:mb-[40px] mr-2" style="max-height: calc(100vh - 120px);">
        <?php require YAB_PLUGIN_DIR . 'admin/views/banner-types/double-banner/double-banner-settings.php'; ?>
    </div>

    <div class="col-span-8 sticky top-[120px] space-y-4">
        <?php require YAB_PLUGIN_DIR . 'admin/views/banner-types/double-banner/double-banner-preview.php'; ?>
        
        <transition name="fade">
<div v-if="['Fixed', 'FirstParagraph', 'LastParagraph'].includes(banner.displayMethod)" class="mt-5 transition-all duration-300">
    <?php include YAB_PLUGIN_DIR . 'admin/views/components/display-conditions.php'; ?>
</div>
        </transition>
    </div>
</main>