<header class="sticky top-7 bg-[#434343]/90 backdrop-blur-md p-3 z-20 flex items-center justify-between shadow-xl ltr border-b border-white/5 rounded-b-xl">
    
    <div class="flex items-center gap-4">
        <button @click="goBackToSelection" class="text-gray-400 hover:text-white bg-transparent border-none p-0 cursor-pointer flex items-center transition-colors group">
            <div class="bg-white/5 p-1.5 rounded-full group-hover:bg-white/10 transition-all">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2.5" stroke="currentColor" class="w-4 h-4 group-hover:-translate-x-0.5 transition-transform">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18" />
                </svg>
            </div>
        </button>
        
        <div class="h-8 w-px bg-gray-600/50"></div>

        <div class="relative group">
            <input type="text" v-model="banner.name" placeholder="Enter Banner Name..." 
                class="bg-transparent text-white border-b border-gray-600 focus:border-[#00baa4] px-1 py-1.5 focus:outline-none w-80 text-base font-medium placeholder-gray-500 transition-all">
            <span class="absolute -top-2.5 left-0 text-[10px] text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity bg-[#434343] px-1">Banner Title</span>
        </div>
    </div>
    
    <div class="flex items-center gap-5">
        
        <div class="flex items-center bg-[#292929] rounded-lg p-1 border border-gray-700 shadow-inner gap-1">
            
            <button @click="banner.displayMethod = 'Fixed'" 
                :class="banner.displayMethod === 'Fixed' ? 'bg-[#3e3e3e] text-[#00baa4] shadow-md ring-1 ring-[#00baa4]/50' : 'text-gray-500 hover:text-gray-300 hover:bg-white/5'" 
                class="flex flex-col items-center justify-center py-1.5 px-3 rounded-md transition-all duration-200 min-w-[70px] gap-1 relative group/btn">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="w-5 h-5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 17.25v1.007a3 3 0 01-.879 2.122L7.5 21h9l-.621-.621A3 3 0 0115 18.257V17.25m6-12V15a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 15V5.25m18 0A2.25 2.25 0 0018.75 3H5.25A2.25 2.25 0 003 5.25m18 0V12a2.25 2.25 0 01-2.25 2.25H5.25" />
                </svg>
                <span class="text-[9px] font-semibold uppercase tracking-wider">Fixed</span>
            </button>

            <button @click="banner.displayMethod = 'Embeddable'" 
                :class="banner.displayMethod === 'Embeddable' ? 'bg-[#3e3e3e] text-[#00baa4] shadow-md ring-1 ring-[#00baa4]/50' : 'text-gray-500 hover:text-gray-300 hover:bg-white/5'" 
                class="flex flex-col items-center justify-center py-1.5 px-3 rounded-md transition-all duration-200 min-w-[70px] gap-1 relative group/btn">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="w-5 h-5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M17.25 6.75L22.5 12l-5.25 5.25m-10.5 0L1.5 12l5.25-5.25m7.5-3l-4.5 16.5" />
                </svg>
                <span class="text-[9px] font-semibold uppercase tracking-wider">Shortcode</span>
            </button>

            <div class="w-px h-6 bg-gray-700/50 mx-0.5"></div>

            <button @click="banner.displayMethod = 'FirstParagraph'" 
                :class="banner.displayMethod === 'FirstParagraph' ? 'bg-[#3e3e3e] text-[#00baa4] shadow-md ring-1 ring-[#00baa4]/50' : 'text-gray-500 hover:text-gray-300 hover:bg-white/5'" 
                class="flex flex-col items-center justify-center py-1.5 px-3 rounded-md transition-all duration-200 min-w-[70px] gap-1 relative group/btn">
                 <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="w-5 h-5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M3 10.5h18M3 15h18M3 19.5h18m-9-9v9m0 0l-3-3m3 3l3-3" style="transform: scaleY(-1); transform-origin: center;" />
                </svg>
                <span class="text-[9px] font-semibold uppercase tracking-wider">Top Inject</span>
            </button>

            <button @click="banner.displayMethod = 'LastParagraph'" 
                :class="banner.displayMethod === 'LastParagraph' ? 'bg-[#3e3e3e] text-[#00baa4] shadow-md ring-1 ring-[#00baa4]/50' : 'text-gray-500 hover:text-gray-300 hover:bg-white/5'" 
                class="flex flex-col items-center justify-center py-1.5 px-3 rounded-md transition-all duration-200 min-w-[70px] gap-1 relative group/btn">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="w-5 h-5">
                   <path stroke-linecap="round" stroke-linejoin="round" d="M3 4.5h18M3 9h18M3 13.5h18m-9-9v9m0 0l-3-3m3 3l3-3" />
                </svg>
                <span class="text-[9px] font-semibold uppercase tracking-wider">Bot Inject</span>
            </button>
        </div>

        <div v-if="banner.displayMethod === 'Embeddable' || banner.displayMethod === 'Fixed'" class="relative group">
            <div class="flex items-center bg-[#292929] rounded-lg px-3 py-2 border border-gray-700 hover:border-gray-500 transition-colors cursor-pointer" @click="copyShortcode(shortcode)" title="Click to copy">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5 text-[#00baa4] mr-2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M17.25 6.75L22.5 12l-5.25 5.25m-10.5 0L1.5 12l5.25-5.25m7.5-3l-4.5 16.5" />
                </svg>
                <div class="flex flex-col">
                    <span class="text-[9px] text-gray-400 leading-none mb-0.5">SHORTCODE</span>
                    <span class="text-[11px] font-mono text-white font-medium truncate w-32 select-all">{{ shortcode }}</span>
                </div>
            </div>
        </div>
        <div v-else class="flex items-center justify-center px-4 py-2 bg-[#292929] rounded-lg border border-gray-700 border-dashed">
             <div class="flex flex-col items-center">
                 <span class="text-[9px] text-gray-400 uppercase tracking-widest font-bold flex items-center gap-1.5">
                    <span class="relative flex h-2 w-2">
                      <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                      <span class="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
                    </span>
                    Automatic Injection
                 </span>
             </div>
        </div>

        <div class="h-8 w-px bg-gray-600/50"></div>

        <div class="flex flex-col items-center gap-1">
             <span class="text-[9px] text-gray-400 font-bold uppercase">Status</span>
            <label class="relative inline-flex items-center cursor-pointer group" title="Toggle Active Status">
                <input type="checkbox" v-model="banner.isActive" class="sr-only peer">
                <div class="w-10 h-5 bg-gray-700 rounded-full peer peer-focus:ring-2 peer-focus:ring-[#00baa4]/50 peer-checked:after:translate-x-5 peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#00baa4]"></div>
            </label>
        </div>

        <button @click="saveBanner" :disabled="isSaving" class="ml-2 bg-gradient-to-r from-[#00baa4] to-[#00a08d] text-white text-xs font-bold px-6 py-2.5 rounded-lg shadow-lg hover:shadow-[#00baa4]/30 hover:from-[#00a08d] hover:to-[#008f7e] transition-all flex items-center gap-2 disabled:bg-none disabled:bg-gray-600 disabled:cursor-not-allowed transform active:scale-95 border border-white/10">
            <span v-if="isSaving" class="dashicons dashicons-update animate-spin text-xs"></span>
            {{ isSaving ? 'SAVING...' : 'SAVE CHANGES' }}
        </button>
    </div>
</header>